BEARD'S CLASSROOM — ADD YOUR OWN FLUENCY PASSAGES

ONE-TIME SETUP

The site cannot list arbitrary new server files on its own. The supplied GitHub publishing workflow scans the passages folder whenever you upload a ZIP or passage text file, then builds the list automatically.

1. Upload the new site.zip to your GitHub repository's MAIN folder, still zipped and named site.zip.
2. Upload the supplied passages folder to the same MAIN folder, alongside site.zip. You can open this folder directly in GitHub when adding new text files.
3. LAST, replace the existing ZIP publisher at .github/workflows/publish-site.yml with the supplied publish-site.yml and commit it on your default branch (usually main). If it does not exist, choose Add file > Create new file, enter .github/workflows/publish-site.yml as the filename, and paste the supplied workflow text. Use this instead of the old ZIP publisher. The workflow itself stays OUTSIDE site.zip.
4. In Settings > Pages, the source must be GitHub Actions. If you already use the ZIP publisher, this is normally already set.
5. In Actions, wait for the latest Publish Beard's Classroom run to finish successfully, then refresh your site.

EVERY NEW PASSAGE AFTER THAT

1. Copy passages/_TEMPLATE.txt on your computer.
2. Rename the copy with the title you want students and teachers to see, for example A Walk to the Pond.txt.
3. Open it in Notepad. Replace all of the sample text with your passage only. The filename becomes the title; do not include a separate title in the passage body.
4. Save as UTF-8 plain text (.txt). Make sure the final filename has only one .txt extension.
5. In the repository, open or create the passages folder. Upload the file there and commit it. On GitHub's Create new file screen, you can enter passages/A Walk to the Pond.txt directly.
6. When the publishing action finishes, open Reading Fluency > Custom Passages on the homepage and choose your title from the dropdown.

You do not need to edit HTML, JavaScript, or a list of passage titles. Optional subfolders such as passages/Grade 2 and passages/Grade 3 become collection labels.

OPTIONAL ADVANCED METHOD: ONLY ZIP UPLOADS

This option applies ONLY when your GitHub repository has no top-level passages folder. Extract site.zip on your computer. Add the .txt files to its passages folder. Zip the contents again, with index.html at the ZIP root, and upload it as site.zip.

The recommended repository passages folder is kept separate from site.zip, so a later website ZIP update does not remove its text files. Whenever that top-level folder exists, it is the COMPLETE collection: the workflow replaces any bundled ZIP passages with the repository folder. Deleting a .txt file from the repository folder therefore removes it from the dropdown after the next successful publish, even if an old website ZIP still contains a copy.

USING YOUR ASSESSMENT TOOLS

Teacher-added passages use the same timer, student names/codes, weekday marks, error marking, accuracy/WCPM calculations, summary printing, and Export/Import save-string controls as the existing passages. New passage files do not contain student progress. Continue using Export save string to keep your results.

If a student finishes the whole passage before time is up, choose Full passage completed, then have the student begin again at the top. Click the last word reached on the next read-through as usual. For example, one 100-word passage plus 25 more words gives 125 total words. Errors are recorded separately for each read-through, and the timer keeps running. Undo last completed passage is available immediately after a completion click, before making any marks on the next read-through.

The report and save string include completed passages, additional words, and errors for every student and every day from Monday through Friday. Existing save strings still import; new multi-pass records should be used with v01.0017 or later.

Keep student save-string files in your student records, outside the passages folder. That folder is only for the reading text that should appear publicly on your site.

A save string belongs to the original passage text and filename. If you want to revise words after collecting data, make a new file with a new name. Harmless whitespace or line-ending changes do not change word positions, but changed words or punctuation create a new save-code identity.

FILE RULES

- Use ordinary UTF-8 .txt files. Word documents and PDFs are not scanned.
- Files or folders whose names begin with _ or . are ignored. The template and these instructions therefore do not appear as student passages.
- Blank files are not listed.
- Avoid two filenames that differ only by capitalization, such as Pond.txt and pond.txt.
- Keep each passage below 100,000 characters and 10,000 words. These limits are far above a normal fluency passage.
- If a file cannot be read as UTF-8, the publishing action explains which file needs attention; the previous live site stays in place.

Official reference: https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages
