#!/usr/bin/env python3
"""Build the teacher-added fluency catalog from ordinary UTF-8 text files."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import unicodedata

MAX_FILE_BYTES = 512_000
MAX_PASSAGE_CHARACTERS = 100_000
MAX_PASSAGE_WORDS = 10_000
MAX_PASSAGES = 500
MAX_CATALOG_CHARACTERS = 5_000_000


class PassageBuildError(ValueError):
    """A passage cannot safely or clearly be published."""


def collect_passages(site_root: Path) -> list[dict[str, str]]:
    folder = site_root / "passages"
    if folder.is_symlink():
        raise PassageBuildError("The passages folder must be a normal folder, not a shortcut or symbolic link.")
    if not folder.exists():
        return []
    if not folder.is_dir():
        raise PassageBuildError("The passages path must be a normal folder.")

    candidates: list[tuple[str, Path]] = []
    seen: dict[str, str] = {}
    for current, directories, files in os.walk(folder, followlinks=False):
        current_path = Path(current)
        for name in directories + files:
            path = current_path / name
            if path.is_symlink():
                raise PassageBuildError(f"Symbolic links are not supported: {path.relative_to(folder)}")
        directories[:] = [name for name in directories if not name.startswith(("_", "."))]
        for name in files:
            path = current_path / name
            relative = path.relative_to(folder)
            if any(part.startswith(("_", ".")) for part in relative.parts) or path.suffix.lower() != ".txt":
                continue
            if not path.is_file():
                raise PassageBuildError(f"Not an ordinary text file: {relative}")
            parts = [unicodedata.normalize("NFC", part) for part in relative.parts]
            if any(not part.strip() or "\\" in part for part in parts):
                raise PassageBuildError(f"Use ordinary folder and file names: {relative}")
            normalized = "/".join(parts)
            duplicate_key = normalized.casefold()
            if duplicate_key in seen:
                raise PassageBuildError(
                    f"Two passage names differ only by capitalization or Unicode spelling: "
                    f"{seen[duplicate_key]} and {relative}. Rename one of them."
                )
            seen[duplicate_key] = str(relative)
            candidates.append((normalized, path))

    passages: list[dict[str, str]] = []
    total_characters = 0
    for relative, path in sorted(candidates, key=lambda item: (item[0].casefold(), item[0])):
        if path.stat().st_size > MAX_FILE_BYTES:
            raise PassageBuildError(f"{relative} is too large. Keep each passage below {MAX_FILE_BYTES:,} bytes.")
        try:
            text = path.read_text(encoding="utf-8-sig")
        except UnicodeError as error:
            raise PassageBuildError(f"{relative} is not UTF-8 text. Save it as UTF-8 in Notepad.") from error
        text = text.replace("\r\n", "\n").replace("\r", "\n").strip()
        if not text:
            continue
        if text.startswith("BEARDFLUENCY1:"):
            raise PassageBuildError(
                f"{relative} contains a fluency save string, not a reading passage. "
                "Keep student progress files in your student records, outside the passages folder."
            )
        if any(unicodedata.category(character) == "Cc" and character not in "\n\t" for character in text):
            raise PassageBuildError(f"{relative} contains non-text control characters. Paste plain text into a new .txt file.")
        if len(text) > MAX_PASSAGE_CHARACTERS or len(text.split()) > MAX_PASSAGE_WORDS:
            raise PassageBuildError(
                f"{relative} is too long. Keep each passage below {MAX_PASSAGE_CHARACTERS:,} characters "
                f"and {MAX_PASSAGE_WORDS:,} words."
            )
        title = Path(relative).stem.strip()
        if not title:
            raise PassageBuildError(f"Give the passage a title before .txt: {relative}")
        parent = relative.rsplit("/", 1)[0] if "/" in relative else ""
        word_sequence = " ".join(text.split())
        revision = hashlib.sha256(word_sequence.encode("utf-8")).hexdigest()[:16]
        passages.append({
            "id": "custom:" + relative,
            "title": title,
            "group": parent.replace("/", " / ") if parent else "Teacher-added",
            "source": "passages/" + relative,
            "revision": revision,
            "text": text,
        })
        total_characters += len(text)
        if len(passages) > MAX_PASSAGES or total_characters > MAX_CATALOG_CHARACTERS:
            raise PassageBuildError("The teacher-added collection is too large. Keep it below 500 passages and 5 million characters.")
    return passages


def build_catalog(site_root: Path) -> list[dict[str, str]]:
    site_root = site_root.resolve()
    passages = collect_passages(site_root)
    payload = json.dumps({"version": 1, "passages": passages}, ensure_ascii=False, indent=2)
    for character, escaped in [("<", "\\u003c"), (">", "\\u003e"), ("&", "\\u0026"), ("\u2028", "\\u2028"), ("\u2029", "\\u2029")]:
        payload = payload.replace(character, escaped)
    javascript = (
        "/* Generated from passages/*.txt. Edit the text files, not this catalog. */\n"
        "window.BeardCustomFluencyBank = Object.freeze(" + payload + ");\n"
    )
    output = site_root / "assets" / "js" / "custom-fluency-bank.js"
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(output.name + ".tmp")
    try:
        temporary.write_text(javascript, encoding="utf-8", newline="\n")
        temporary.replace(output)
    finally:
        temporary.unlink(missing_ok=True)
    catalog_hash = hashlib.sha256(javascript.encode("utf-8")).hexdigest()[:16]
    script_reference = re.compile(
        r"(<script\b[^>]*\bsrc\s*=\s*)([\"'])([^\"'?#]*custom-fluency-bank\.js)(?:[?#][^\"']*)?\2",
        re.IGNORECASE,
    )
    for page in [
        site_root / "HTMLs" / "Reading Fluency" / "Fluency Passages.html",
        site_root / "HTMLs" / "Reading Fluency" / "Custom_Fluency_Passage.html",
    ]:
        if not page.is_file():
            continue
        original = page.read_text(encoding="utf-8")
        updated = script_reference.sub(
            lambda match: match[1] + match[2] + match[3] + "?catalog=" + catalog_hash + match[2],
            original,
        )
        if updated != original:
            page.write_text(updated, encoding="utf-8", newline="\n")
    return passages


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--site-root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    try:
        passages = build_catalog(args.site_root)
    except (PassageBuildError, OSError) as error:
        print(f"Custom fluency passages were not published: {error}", file=sys.stderr)
        return 1
    print(f"Built teacher-added fluency catalog: {len(passages)} passage(s).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
