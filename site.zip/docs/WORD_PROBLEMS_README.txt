BEARD'S CLASSROOM — WORD PROBLEMS
Revision v01.0026

Choose one step or two steps, a number range through 20, 100, or 1,000, and any nonempty combination of addition, subtraction, multiplication, and division. The last selected operation cannot be turned off.

Two-step problems use only the operations selected. With addition and multiplication selected, for example, the assessment includes addition/addition, addition/multiplication, multiplication/addition, and multiplication/multiplication. Selecting just division makes both steps division. A shuffled bag covers each permitted operation or ordered pair once before repeating that set.

The bank has 24 original one-step story structures and 48 original two-step story structures, with varied numbers and names. Sharing and grouping division are both included. Every problem has positive whole-number operands, intermediate quantities and answers within the selected range. Division is exact and never uses a zero divisor. Multiplication and division do not use a factor or divisor of one. The two-step stories require both stated changes or grouping relationships; their intermediate totals are not supplied in the story.

The assessment starts automatically when opened from the homepage. Changing steps, range, or selected operations starts a fresh assessment, including time, scores, and responses. Check answer or Enter submits once. Next problem can advance immediately after feedback; otherwise the next problem appears automatically. The one-minute teacher timer allows overtime. Stop freezes the total time and ends the assessment.

The compact results and printout keep each complete story, the student's actual answer, its green/red outcome, and the response time together. Expected answers are also shown for review. A right-click correction through the teacher report changes the outcome without adding another attempt. The report includes the selected steps, range, and operations.

The four older word-problem URLs still work and retain their starting step/range/addition-and-subtraction settings. They use this same improved bank and can be adjusted using the settings on the page. The general Word_Problems.html page starts with all four operations and accepts links such as ?steps=2&max=100&operations=add,multiply.

Read-aloud and click-to-hear controls are provided by the shared teacher bar. This update does not change their gestures or selection behavior.
