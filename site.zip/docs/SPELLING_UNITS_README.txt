BEARD'S CLASSROOM — GRADE 2 AND GRADE 3 SPELLING
Revision v01.0022

INDEPENDENT STUDENT PRACTICE

On the homepage, open Spelling and choose Student Spelling Practice. This is a separate page with its own randomly shuffled list. Students choose 2nd or 3rd grade, Unit 1–6, and Week 1–5. Week numbers restart inside each unit: Unit 2 Week 1 uses the PDF's Lesson 6, for example.

No name, account, roster, or teacher test is needed. Choose typing or writing on paper, press Hear word for the word alone or Hear sentence for an example, and use Next word to continue. Spellings stay hidden while the assessment is running. Stopping or finishing displays a graded report, including the expected word and the student's actual typed spelling. There is no Back to teacher button or named-student roster on this separate page.

Choosing another grade, unit, or week, New random order, or New assessment after finishing makes a fresh random order. Listening again or moving between words keeps the current order. The circular arrow next to the countdown restarts time, scores and responses using the SAME word order. Typed responses are only kept in memory while the page is open; this independent page does not connect to the teacher's named students.

ALL GRADES: PHONICS SPELLING

Choose All in the Grade selector to choose a phonics skill instead of a unit and week. The eight word-based skills reuse the existing phonics goal-check lists: CVC Words (207), Consonant Digraphs (230), Consonant Blends (258), VCe (197), Common Vowel Teams (197), R-Controlled Vowels (150), Other Vowel Patterns (120), and Multisyllable Words (240). Letter naming and oral sound tasks are not spelling-word lists and are not included here.

The final choice, Mixed Phonics · All Skills, combines all eight skills into 1,570 distinct words. Shared words appear once in the mixed list. Each selected list is shuffled once; replaying audio or moving between words keeps that order. New random order reshuffles, while the timer arrow restarts the same order. Every word has an original example sentence, including context for homophones. This adds listening/spelling practice without changing the existing phonics goal checks.

Hear word and Hear sentence are separate buttons in both independent practice and the teacher's student listening view. Neither automatically plays the other. The existing device read-aloud voice is reused. The teacher scoring pages remain separately labeled on the homepage.

TIMING, STOPPING AND PRINTING THE INDEPENDENT ASSESSMENT

The usual top bar shows the one-minute countdown, total elapsed time, percentage, attempts and errors. The clock starts automatically when a list is selected. It chimes once at one minute and allows overtime. Stop assessment ends the run and freezes the total time. Pressing 3 also stops when focus is outside an answer field or selector. Finishing the last word automatically shows the report.

Each submitted word is one attempt. Returning to edit a spelling changes that word's result without adding another attempt. A blank typed answer submitted with Next is incorrect; words not reached before Stop are not counted as incorrect. Stop includes an unfinished nonblank typed answer.

The report shows the date, selected spelling list or phonics skill, percentage, attempts, errors, total time, first-minute breakdown, and compact answer boxes. Each box keeps the expected word, actual typed answer and seconds together; student answers appear green for correct or red for incorrect. Right-click a graded box (or focus it and press Enter) to correct an outcome.

Paper responses cannot be graded from the audio player. They are marked Pending until an adult uses Correct/Incorrect in the report. The overall percentage remains Pending while any submitted paper responses await grading. This avoids treating unknown handwritten answers as wrong or inventing a score.

Print / Save PDF uses the same compact report format. Browser printing after Stop also prints that report. Printing while the assessment is running does not expose the answer key. Keep a screenshot or saved PDF before leaving the page or starting a new assessment.


OPEN A SPELLING TEST

On the homepage, open Spelling and choose Teacher Scoring: 2nd Grade Spelling or Teacher Scoring: 3rd Grade Spelling. Select Unit 1–6, then either the whole unit or a single lesson. The source has five lessons per unit and 30 lessons per grade. Lesson numbers follow the PDF: Unit 2 begins with Lesson 6, for example.

The word order is randomized once when the test is created. Adding students, switching students, grading, viewing reports, printing, and exporting or importing the same test do not change that order. Changing the grade, unit, or lesson, or explicitly choosing a new shuffle, creates a new test.

ASSESS AND RECORD RESULTS

This is a teacher scoring page. Keep the answer-key words out of students' view. Read a word, use it in a sentence to make its meaning clear, then repeat it. Students can write their responses on paper while the teacher uses the same numbered list for the group.

Add up to ten student names or codes. Select a student to enter that student's results. Mark each word Correct or Incorrect; leave words that were not assessed unscored. A student's exact spelling can also be entered so the report shows the error. Typed spellings are checked without case sensitivity and accept straight or curly apostrophes. The teacher can override a result, including capitalization errors, using the scoring controls.

Each student's report includes the test date, grade, unit/lesson, the shared word order, recorded spellings and outcomes, correct and incorrect counts, the percentage of scored words, and the number of unscored words. A partial test is labeled as partial; unscored words are not silently counted as incorrect. Group data entry does not claim to measure each child's response time.

Print or save the selected student's report, or print the whole group's individual reports. The report boxes keep the expected word and the student's entered spelling together, with green/red text for the result.

STUDENT LISTENING VIEW

Select a student, then choose Student view · Hear words. This hides the teacher's answer-key list and reports. The student sees only their name, the current word number, listening controls, and their own typed response.

Hear word reads only the word. Hear sentence reads only a short original context sentence. Students choose the pause between them. The context distinguishes homophones such as meet/meat and there/their without displaying the spelling. Each of the 547 distinct source words has a context sentence. Audio uses the device/browser's available read-aloud voice; no Google audio downloads, paid API account or teacher MP3 recordings are needed for this version. Voice availability and sound vary by device.

Choose typing for an answer box, or paper when the student writes by hand. Next word saves a typed spelling and advances through the same fixed test order. A blank skipped answer remains unscored. Paper mode advances without inventing scores; the teacher enters the paper results afterward. Correct spellings and correctness feedback remain hidden until returning to teacher controls.

Back to teacher returns to the student's scoring cards. The teacher can review typed errors and override results. Changing students still keeps the same test order, and each student's results remain independent.

KEEP A TEST FOR LATER

Export the spelling save code before leaving or closing the page. It preserves the test date, grade/unit/lesson, exact shuffled word order, all student names and all results. Copy the code to a text file or download it, then import it on the spelling page to continue the same test later.

Spelling save codes begin with BEARDSPELLING1: and are separate from fluency passage save codes. Nothing is automatically uploaded or stored in a student account. Keep exported codes with the student's records; do not put them in the public passages folder or upload them to GitHub.

SOURCE WORD LISTS

All 60 lesson lists and 559 numbered word entries were transcribed and independently checked against the supplied Spelling List.pdf. List lengths vary; no words were added to make the lists the same size. Original word spellings, contractions and capital letters are preserved. Display skill headings only have minor spacing/heading-typo corrections.

The PDF does not explicitly label its columns by grade. The simpler left column is assigned to Grade 2, and the right column to Grade 3. This assignment is also documented in the word-bank metadata.

Whole-unit lists include each spelling word once. Grade 2 Unit 1 repeats grape across two source lessons, and Grade 2 Unit 5 repeats water. Those repetitions remain in their individual lessons but are combined in a whole-unit test.

Unique whole-unit counts:
Grade 2, Units 1–6: 57, 60, 59, 63, 74, 66 words.
Grade 3, Units 1–6: 29, 30, 28, 30, 31, 30 words.

Website updates are uploaded as site.zip at the repository root. The spelling feature does not need a new publishing workflow or any changes to the existing passages folder.
