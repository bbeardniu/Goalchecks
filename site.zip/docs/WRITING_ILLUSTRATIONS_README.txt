BEARD'S CLASSROOM — WRITING ILLUSTRATIONS
Revision v01.0026

Show illustrations / Hide illustrations is available in Independent Sentence Writing, open sentence fill, grade 2 and grade 3 sentence completion, both sentence-order activities, and the two parts-of-speech checks. The choice stays selected while moving between prompts and when resetting that page. Changing the picture setting does not restart the assessment, change its word order, erase writing, or change its score.

Reports identify Illustrations: On, Off, or On and off. Individual recorded responses also retain the support setting used for that prompt. Choose the same support setting for progress checks when the student's goal calls for comparable conditions. Turning pictures off removes the image from the accessible display and collapses its unused space.

The picture-sentence and grade-level completion activities retain their original exact question-to-picture mappings. The new independent writing pictures offer ideas without dictating a student's sentence. In the advanced word-order and open-fill activities, a caption distinguishes Picture support from Subject illustration. A subject illustration may show the relevant person, animal, object or setting without illustrating every action or detail.

A Writing illustration caption identifies decorative notebook artwork instead of a picture clue. This is also used in parts-of-speech checks so it does not reveal whether the highlighted word is a noun, verb, adjective or adverb. No word bank or question was rewritten to fit an unrelated picture.

All artwork is local to the website; the feature does not need an account, additional recordings, or an external image service while assessing. The original source art and mappings remain in assets/illustrations; writing-illustrations-bank.js holds the new reviewed picture choices. If an illustration cannot load, a brief message appears and the task still works.

ARTWORK STATUS

Original sheets 01,02,03,04,05,07,08,11,13 and the three new writing-scene sheets are dry colored-pencil illustrations. Sheets06,09,10,12,14 retain the previous children's-book mixture of watercolor and pencil because image generation reached its limit. Their original scenes and mappings remain intact. No scene was replaced with a misleading substitute to claim completion.
