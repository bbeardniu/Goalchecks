/* Reviewed visual support mappings. Exact prompt text remains in each assessment. */
window.BeardWritingArt = {
  "version": 1,
  "revision": "01.0026",
  "notes": [
    "Pictures marked Subject illustration show a relevant subject, action, or setting; they are not an answer key.",
    "The original assessment prompts and existing picture question mappings are preserved.",
    "All16 independent topics,10 open-fill prompts, and200 advanced sentences have reviewed colored-pencil scene or subject illustrations. Grammar pictures remain decorative to avoid identifying the word class for the student."
  ],
  "fallback": {
    "decorative": true,
    "alt": "A colored-pencil notebook and pencil."
  },
  "independent": {
    "a game you enjoy": {
      "file": "storybook-02.webp",
      "index": 14,
      "columns": 4,
      "alt": "A boy kicking balls.",
      "kind": "topic"
    },
    "an animal you like": {
      "file": "storybook-05.webp",
      "index": 0,
      "columns": 4,
      "alt": "A girl petting a puppy.",
      "kind": "topic"
    },
    "something you do at school": {
      "file": "storybook-07.webp",
      "index": 3,
      "columns": 4,
      "alt": "A child reading stories.",
      "kind": "topic"
    },
    "a food you enjoy": {
      "file": "storybook-11.webp",
      "index": 14,
      "columns": 4,
      "alt": "A peanut-butter-and-jelly sandwich cut in half on a small plate.",
      "kind": "topic"
    },
    "a place you like to visit": {
      "file": "storybook-11.webp",
      "index": 5,
      "columns": 4,
      "alt": "A cheerful playground with a child sliding down a slide.",
      "kind": "topic"
    },
    "something you do outside": {
      "file": "storybook-05.webp",
      "index": 5,
      "columns": 4,
      "alt": "A girl skipping rope.",
      "kind": "topic"
    },
    "a helpful thing you can do": {
      "file": "storybook-06.webp",
      "index": 15,
      "columns": 4,
      "rows": 4,
      "alt": "A boy sweeping floors.",
      "kind": "topic"
    },
    "something you do in the morning": {
      "file": "storybook-05.webp",
      "index": 9,
      "columns": 4,
      "alt": "A boy drinking milk.",
      "kind": "topic"
    },
    "a book or story you enjoy": {
      "file": "storybook-07.webp",
      "index": 3,
      "columns": 4,
      "alt": "A child reading stories.",
      "kind": "topic"
    },
    "something you make or build": {
      "file": "storybook-05.webp",
      "index": 3,
      "columns": 4,
      "alt": "A baby holding blocks.",
      "kind": "topic"
    },
    "a time you felt happy": {
      "file": "storybook-01.webp",
      "index": 10,
      "columns": 4,
      "alt": "A smiling boy.",
      "kind": "topic"
    },
    "something you want to learn": {
      "file": "storybook-11.webp",
      "index": 8,
      "columns": 4,
      "alt": "A curious child raising a hand to ask a teacher a question, no text.",
      "kind": "topic"
    },
    "a way to help a friend": {
      "file": "storybook-05.webp",
      "index": 14,
      "columns": 4,
      "rows": 4,
      "alt": "A boy carrying boxes.",
      "kind": "topic"
    },
    "a favorite season": {
      "file": "storybook-13.webp",
      "index": 15,
      "columns": 4,
      "alt": "Autumn leaves blowing across a sidewalk on a breezy day.",
      "kind": "topic"
    },
    "something you notice in nature": {
      "file": "storybook-13.webp",
      "index": 11,
      "columns": 4,
      "alt": "A child looking carefully with open eyes at a butterfly nearby.",
      "kind": "topic"
    },
    "a place where you feel comfortable": {
      "file": "storybook-13.webp",
      "index": 4,
      "columns": 4,
      "alt": "A small kitten curled up asleep in a cozy woven basket.",
      "kind": "topic"
    }
  },
  "fill": {
    "The cat ____ up the tree.": {
      "file": "storybook-13.webp",
      "index": 6,
      "columns": 4,
      "rows": 4,
      "alt": "A playful kitten chasing a ball of yarn.",
      "kind": "topic"
    },
    "She ____ her lunch at the park.": {
      "file": "storybook-11.webp",
      "index": 3,
      "columns": 4,
      "rows": 4,
      "alt": "An open picnic basket containing sandwiches and apples on a checkered picnic blanket.",
      "kind": "topic"
    },
    "The rain ____ falling all day.": {
      "file": "storybook-02.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "Rain falling.",
      "kind": "exact"
    },
    "He ____ the ball over the fence.": {
      "file": "storybook-06.webp",
      "index": 11,
      "columns": 4,
      "rows": 4,
      "alt": "A girl throwing a ball.",
      "kind": "topic"
    },
    "The baby ____ when she saw the clown.": {
      "file": "storybook-03.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A laughing baby.",
      "kind": "topic"
    },
    "They ____ a movie together last night.": {
      "file": "storybook-10.webp",
      "index": 12,
      "columns": 4,
      "rows": 4,
      "alt": "A family sharing a bowl of popcorn while watching a movie at home.",
      "kind": "topic"
    },
    "The wind ____ through the tall trees.": {
      "file": "storybook-13.webp",
      "index": 15,
      "columns": 4,
      "rows": 4,
      "alt": "Autumn leaves blowing across a sidewalk on a breezy day.",
      "kind": "topic"
    },
    "Mom ____ cookies for the bake sale.": {
      "file": "writing-scenes-01.webp",
      "index": 0,
      "columns": 4,
      "alt": "A mother, a cookie tray, and a kitchen.",
      "kind": "exact"
    },
    "The sun ____ behind the clouds.": {
      "file": "storybook-01.webp",
      "index": 15,
      "columns": 4,
      "rows": 4,
      "alt": "A shining sun.",
      "kind": "topic"
    },
    "The dog ____ loudly at the mailman.": {
      "file": "storybook-01.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A dog running.",
      "kind": "topic"
    }
  },
  "scramble": {
    "The puppy chased a red ball.": {
      "file": "storybook-13.webp",
      "index": 8,
      "columns": 4,
      "rows": 4,
      "alt": "A bright red ball resting on green grass.",
      "kind": "topic"
    },
    "Our class planted yellow seeds.": {
      "file": "storybook-07.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A child planting seeds.",
      "kind": "topic"
    },
    "The rabbit nibbled crunchy carrots.": {
      "file": "storybook-11.webp",
      "index": 9,
      "columns": 4,
      "rows": 4,
      "alt": "A soft brown rabbit eating a crunchy orange carrot.",
      "kind": "exact"
    },
    "Bright stars filled the sky.": {
      "file": "storybook-02.webp",
      "index": 3,
      "columns": 4,
      "rows": 4,
      "alt": "Stars twinkling at night.",
      "kind": "exact"
    },
    "A mechanic fixed the broken chair.": {
      "file": "writing-scenes-01.webp",
      "index": 1,
      "columns": 4,
      "alt": "Mechanic, tools, and a wooden chair.",
      "kind": "exact"
    },
    "The baker mixed sweet batter.": {
      "file": "storybook-03.webp",
      "index": 4,
      "columns": 4,
      "rows": 4,
      "alt": "A baker stirring batter.",
      "kind": "topic"
    },
    "Three ducks crossed the quiet pond.": {
      "file": "writing-scenes-01.webp",
      "index": 2,
      "columns": 4,
      "alt": "Three ducks and a quiet pond.",
      "kind": "exact"
    },
    "A small turtle climbed nearby rocks.": {
      "file": "storybook-03.webp",
      "index": 12,
      "columns": 4,
      "rows": 4,
      "alt": "A turtle walking.",
      "kind": "topic"
    },
    "The bus carried students home.": {
      "file": "storybook-02.webp",
      "index": 5,
      "columns": 4,
      "rows": 4,
      "alt": "A bus stopping.",
      "kind": "topic"
    },
    "Fresh snow covered every sidewalk.": {
      "file": "storybook-02.webp",
      "index": 1,
      "columns": 4,
      "rows": 4,
      "alt": "Snow covering grass.",
      "kind": "topic"
    },
    "Our teacher opened a storybook.": {
      "file": "storybook-14.webp",
      "index": 9,
      "columns": 4,
      "rows": 4,
      "alt": "A teacher reading a picture book aloud to a small group of listening children.",
      "kind": "topic"
    },
    "The baby hugged her teddy.": {
      "file": "storybook-04.webp",
      "index": 15,
      "columns": 4,
      "rows": 4,
      "alt": "A child hugging a teddy bear.",
      "kind": "topic"
    },
    "Green leaves covered the path.": {
      "file": "storybook-13.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A tall spreading oak tree in a green park.",
      "kind": "topic"
    },
    "A fox watched nearby squirrels.": {
      "file": "storybook-03.webp",
      "index": 15,
      "columns": 4,
      "rows": 4,
      "alt": "A fox running.",
      "kind": "topic"
    },
    "The farmer watered thirsty plants.": {
      "file": "storybook-14.webp",
      "index": 2,
      "columns": 4,
      "rows": 4,
      "alt": "A gardener watering rosebushes with a small watering can.",
      "kind": "topic"
    },
    "Five candles glowed brightly.": {
      "file": "storybook-07.webp",
      "index": 10,
      "columns": 4,
      "rows": 4,
      "alt": "A birthday cake with small lit candles on a table.",
      "kind": "topic"
    },
    "The wind rattled loose shutters.": {
      "file": "storybook-13.webp",
      "index": 15,
      "columns": 4,
      "rows": 4,
      "alt": "Autumn leaves blowing across a sidewalk on a breezy day.",
      "kind": "topic"
    },
    "A blue kite floated overhead.": {
      "file": "storybook-02.webp",
      "index": 4,
      "columns": 4,
      "rows": 4,
      "alt": "A kite rising.",
      "kind": "topic"
    },
    "The chef sliced ripe tomatoes.": {
      "file": "storybook-03.webp",
      "index": 5,
      "columns": 4,
      "rows": 4,
      "alt": "A chef chopping carrots.",
      "kind": "topic"
    },
    "Tiny ants carried crumbs home.": {
      "file": "storybook-03.webp",
      "index": 10,
      "columns": 4,
      "rows": 4,
      "alt": "An ant carrying crumbs.",
      "kind": "topic"
    },
    "The artist painted a rainbow.": {
      "file": "storybook-02.webp",
      "index": 12,
      "columns": 4,
      "rows": 4,
      "alt": "A child painting.",
      "kind": "topic"
    },
    "A drummer played steady rhythms.": {
      "file": "storybook-09.webp",
      "index": 1,
      "columns": 4,
      "rows": 4,
      "alt": "A young drummer playing a large drum with two drumsticks.",
      "kind": "exact"
    },
    "The train passed empty fields.": {
      "file": "storybook-02.webp",
      "index": 7,
      "columns": 4,
      "rows": 4,
      "alt": "A train rolling.",
      "kind": "topic"
    },
    "Happy children built a fort.": {
      "file": "storybook-04.webp",
      "index": 13,
      "columns": 4,
      "rows": 4,
      "alt": "A child building towers.",
      "kind": "topic"
    },
    "The moon lit dark clouds.": {
      "file": "storybook-02.webp",
      "index": 2,
      "columns": 4,
      "rows": 4,
      "alt": "A glowing moon.",
      "kind": "topic"
    },
    "A squirrel buried one acorn.": {
      "file": "storybook-14.webp",
      "index": 6,
      "columns": 4,
      "rows": 4,
      "alt": "A bushy-tailed squirrel carrying an acorn toward its nest in a tree.",
      "kind": "topic"
    },
    "The librarian shelved new books.": {
      "file": "storybook-07.webp",
      "index": 12,
      "columns": 4,
      "rows": 4,
      "alt": "A librarian gently shelving books on a low wooden bookshelf.",
      "kind": "exact"
    },
    "Warm soup filled hungry bellies.": {
      "file": "storybook-14.webp",
      "index": 14,
      "columns": 4,
      "rows": 4,
      "alt": "A chef stirring a pot of soup with a wooden spoon.",
      "kind": "topic"
    },
    "A robin gathered soft grass.": {
      "file": "storybook-07.webp",
      "index": 9,
      "columns": 4,
      "rows": 4,
      "alt": "Baby birds sitting in a twig nest high in a leafy tree.",
      "kind": "topic"
    },
    "The storm bent tall trees.": {
      "file": "storybook-12.webp",
      "index": 7,
      "columns": 4,
      "rows": 4,
      "alt": "Dark gray rain clouds over a small landscape, a distant gentle lightning flash.",
      "kind": "topic"
    },
    "Two hikers followed blue markers.": {
      "file": "storybook-10.webp",
      "index": 9,
      "columns": 4,
      "rows": 4,
      "alt": "Two children examining a simple trail map before a forest walk, no legible text.",
      "kind": "topic"
    },
    "The janitor swept muddy footprints.": {
      "file": "writing-scenes-01.webp",
      "index": 3,
      "columns": 4,
      "alt": "Janitor, broom, and muddy footprints.",
      "kind": "exact"
    },
    "A dolphin chased silver fish.": {
      "file": "writing-scenes-01.webp",
      "index": 4,
      "columns": 4,
      "alt": "Dolphin and silver fish.",
      "kind": "exact"
    },
    "The gardener trimmed thorny bushes.": {
      "file": "storybook-14.webp",
      "index": 2,
      "columns": 4,
      "rows": 4,
      "alt": "A gardener watering rosebushes with a small watering can.",
      "kind": "topic"
    },
    "Brown bears ate ripe berries.": {
      "file": "storybook-04.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A bear climbing a tree.",
      "kind": "topic"
    },
    "The pilot landed safely.": {
      "file": "storybook-02.webp",
      "index": 9,
      "columns": 4,
      "rows": 4,
      "alt": "A plane landing.",
      "kind": "exact"
    },
    "A spider spun silver threads.": {
      "file": "storybook-12.webp",
      "index": 5,
      "columns": 4,
      "rows": 4,
      "alt": "A small friendly spider sitting in a delicate web between two branches.",
      "kind": "topic"
    },
    "The parade marched downtown.": {
      "file": "storybook-11.webp",
      "index": 1,
      "columns": 4,
      "rows": 4,
      "alt": "A cheerful small street parade with musicians and people waving.",
      "kind": "exact"
    },
    "Our team solved tricky puzzles.": {
      "file": "storybook-11.webp",
      "index": 7,
      "columns": 4,
      "rows": 4,
      "alt": "Two siblings fitting pieces into a colorful simple jigsaw puzzle.",
      "kind": "exact"
    },
    "The puppy found a hidden bone.": {
      "file": "storybook-05.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A girl petting a puppy.",
      "kind": "topic"
    },
    "A volcano released gray smoke.": {
      "file": "writing-scenes-01.webp",
      "index": 5,
      "columns": 4,
      "alt": "Volcano and gray smoke.",
      "kind": "exact"
    },
    "The cashier counted each coin.": {
      "file": "writing-scenes-01.webp",
      "index": 6,
      "columns": 4,
      "alt": "Cashier and coins.",
      "kind": "exact"
    },
    "Purple flowers attracted busy bees.": {
      "file": "storybook-03.webp",
      "index": 8,
      "columns": 4,
      "rows": 4,
      "alt": "A buzzing bee.",
      "kind": "topic"
    },
    "A sailor raised the anchor.": {
      "file": "storybook-08.webp",
      "index": 2,
      "columns": 4,
      "rows": 4,
      "alt": "A friendly ship captain giving directions to two attentive crew members.",
      "kind": "topic"
    },
    "A doctor checked the patient.": {
      "file": "storybook-03.webp",
      "index": 7,
      "columns": 4,
      "rows": 4,
      "alt": "A doctor checking a heart.",
      "kind": "topic"
    },
    "The musician tuned her violin.": {
      "file": "storybook-11.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A small children's orchestra tuning violins, a cello and a flute before a concert.",
      "kind": "exact"
    },
    "The rooster woke sleepy campers.": {
      "file": "writing-scenes-01.webp",
      "index": 7,
      "columns": 4,
      "alt": "Rooster, tents, and sleepy campers.",
      "kind": "exact"
    },
    "Yellow buses carried students home.": {
      "file": "storybook-02.webp",
      "index": 5,
      "columns": 4,
      "rows": 4,
      "alt": "A bus stopping.",
      "kind": "topic"
    },
    "A painter washed dusty brushes.": {
      "file": "storybook-02.webp",
      "index": 12,
      "columns": 4,
      "rows": 4,
      "alt": "A child painting.",
      "kind": "topic"
    },
    "The river carried fallen branches.": {
      "file": "storybook-11.webp",
      "index": 11,
      "columns": 4,
      "rows": 4,
      "alt": "A winding blue river flowing through a green valley.",
      "kind": "topic"
    },
    "A dragonfly hovered near reeds.": {
      "file": "writing-scenes-01.webp",
      "index": 8,
      "columns": 4,
      "alt": "Dragonfly and reeds.",
      "kind": "exact"
    },
    "The librarian stamped returned books.": {
      "file": "storybook-07.webp",
      "index": 12,
      "columns": 4,
      "rows": 4,
      "alt": "A librarian gently shelving books on a low wooden bookshelf.",
      "kind": "topic"
    },
    "Frost covered the playground slide.": {
      "file": "writing-scenes-01.webp",
      "index": 9,
      "columns": 4,
      "alt": "Frost on a playground slide.",
      "kind": "exact"
    },
    "A firefighter climbed the ladder.": {
      "file": "storybook-09.webp",
      "index": 7,
      "columns": 4,
      "rows": 4,
      "alt": "A friendly firefighter in a red helmet spraying water from a hose beside a fire engine.",
      "kind": "topic"
    },
    "A captain steered the ship.": {
      "file": "storybook-08.webp",
      "index": 2,
      "columns": 4,
      "rows": 4,
      "alt": "A friendly ship captain giving directions to two attentive crew members.",
      "kind": "topic"
    },
    "Young otters splashed happily.": {
      "file": "writing-scenes-01.webp",
      "index": 10,
      "columns": 4,
      "alt": "Young otters and splashing water.",
      "kind": "exact"
    },
    "A baker frosted vanilla cupcakes.": {
      "file": "storybook-07.webp",
      "index": 14,
      "columns": 4,
      "rows": 4,
      "alt": "A baker carefully placing a round cake into an oven.",
      "kind": "topic"
    },
    "The puppy wagged its tail.": {
      "file": "storybook-05.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A girl petting a puppy.",
      "kind": "topic"
    },
    "Little chicks pecked cracked corn.": {
      "file": "writing-scenes-01.webp",
      "index": 11,
      "columns": 4,
      "alt": "Little chicks and cracked corn.",
      "kind": "exact"
    },
    "A camper packed warm socks.": {
      "file": "storybook-08.webp",
      "index": 1,
      "columns": 4,
      "rows": 4,
      "alt": "Children camping in a cozy canvas tent under a clear night sky.",
      "kind": "topic"
    },
    "The dentist cleaned shiny teeth.": {
      "file": "storybook-08.webp",
      "index": 13,
      "columns": 4,
      "rows": 4,
      "alt": "A kind dentist checking a child's teeth in a bright friendly dental room.",
      "kind": "topic"
    },
    "A dancer practiced new steps.": {
      "file": "storybook-02.webp",
      "index": 13,
      "columns": 4,
      "rows": 4,
      "alt": "A girl dancing.",
      "kind": "exact"
    },
    "City leaders opened the festival.": {
      "file": "storybook-11.webp",
      "index": 1,
      "columns": 4,
      "rows": 4,
      "alt": "A cheerful small street parade with musicians and people waving.",
      "kind": "topic"
    },
    "A mouse explored the pantry.": {
      "file": "storybook-03.webp",
      "index": 14,
      "columns": 4,
      "rows": 4,
      "alt": "A mouse hiding.",
      "kind": "topic"
    },
    "The coach blew a whistle.": {
      "file": "storybook-08.webp",
      "index": 5,
      "columns": 4,
      "rows": 4,
      "alt": "A friendly coach explaining a soccer play to attentive children.",
      "kind": "topic"
    },
    "Bright lanterns lined the walkway.": {
      "file": "writing-scenes-01.webp",
      "index": 12,
      "columns": 4,
      "alt": "Bright lanterns along a walkway.",
      "kind": "exact"
    },
    "A beaver carried thick sticks.": {
      "file": "writing-scenes-01.webp",
      "index": 13,
      "columns": 4,
      "alt": "Beaver and thick sticks.",
      "kind": "exact"
    },
    "The boy gathered smooth stones.": {
      "file": "storybook-06.webp",
      "index": 9,
      "columns": 4,
      "rows": 4,
      "alt": "A boy collecting rocks.",
      "kind": "topic"
    },
    "A scientist measured clear water.": {
      "file": "storybook-12.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A friendly scientist recording an experiment in a notebook at a simple laboratory table.",
      "kind": "topic"
    },
    "The bell rang sharply.": {
      "file": "writing-scenes-01.webp",
      "index": 14,
      "columns": 4,
      "alt": "School bell with motion lines.",
      "kind": "exact"
    },
    "Small boats crossed the harbor.": {
      "file": "ship-harbor.webp",
      "index": 0,
      "columns": 1,
      "rows": 1,
      "alt": "A ship docked safely beside a harbor pier.",
      "kind": "topic"
    },
    "A musician played cheerful songs.": {
      "file": "storybook-11.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A small children's orchestra tuning violins, a cello and a flute before a concert.",
      "kind": "topic"
    },
    "The astronaut floated inside a spacecraft.": {
      "file": "storybook-12.webp",
      "index": 4,
      "columns": 4,
      "rows": 4,
      "alt": "A small rocket spaceship traveling through a starry sky.",
      "kind": "topic"
    },
    "A porcupine raised its quills.": {
      "file": "writing-scenes-01.webp",
      "index": 15,
      "columns": 4,
      "alt": "Porcupine with raised quills.",
      "kind": "exact"
    },
    "The bakery smelled delicious.": {
      "file": "storybook-07.webp",
      "index": 7,
      "columns": 4,
      "rows": 4,
      "alt": "A baker placing two golden bread loaves into an oven.",
      "kind": "exact"
    },
    "Four puppies shared one blanket.": {
      "file": "writing-scenes-02.webp",
      "index": 0,
      "columns": 4,
      "alt": "Four puppies under one blanket.",
      "kind": "exact"
    },
    "A ranger spotted fresh tracks.": {
      "file": "storybook-12.webp",
      "index": 13,
      "columns": 4,
      "rows": 4,
      "alt": "A winding walking trail through a calm leafy forest.",
      "kind": "topic"
    },
    "The crowd cheered loudly.": {
      "file": "storybook-09.webp",
      "index": 11,
      "columns": 4,
      "rows": 4,
      "alt": "A children's soccer team cheering together after a goal, with a goal net behind them.",
      "kind": "topic"
    },
    "A penguin slid across ice.": {
      "file": "storybook-04.webp",
      "index": 7,
      "columns": 4,
      "rows": 4,
      "alt": "A penguin sliding on ice.",
      "kind": "topic"
    },
    "The carpenter sanded rough wood.": {
      "file": "storybook-09.webp",
      "index": 12,
      "columns": 4,
      "rows": 4,
      "alt": "An adult using a hammer to tap a nail into a wooden board.",
      "kind": "topic"
    },
    "A butterfly rested on clover.": {
      "file": "storybook-03.webp",
      "index": 9,
      "columns": 4,
      "rows": 4,
      "alt": "A butterfly landing on a flower.",
      "kind": "topic"
    },
    "An officer directed busy traffic.": {
      "file": "writing-scenes-02.webp",
      "index": 1,
      "columns": 4,
      "alt": "Officer and traffic.",
      "kind": "exact"
    },
    "A teacher collected finished papers.": {
      "file": "storybook-03.webp",
      "index": 2,
      "columns": 4,
      "rows": 4,
      "alt": "A teacher writing words.",
      "kind": "topic"
    },
    "The dog barked at thunder.": {
      "file": "storybook-01.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A dog running.",
      "kind": "topic"
    },
    "A miner carried heavy tools.": {
      "file": "writing-scenes-02.webp",
      "index": 2,
      "columns": 4,
      "alt": "Miner carrying tools.",
      "kind": "exact"
    },
    "The eagle spotted tiny fish.": {
      "file": "storybook-09.webp",
      "index": 2,
      "columns": 4,
      "rows": 4,
      "alt": "An eagle stretching its wide wings above a deep canyon.",
      "kind": "topic"
    },
    "A nurse wrapped the bandage.": {
      "file": "storybook-03.webp",
      "index": 6,
      "columns": 4,
      "rows": 4,
      "alt": "A nurse helping children.",
      "kind": "topic"
    },
    "The cat chased fluttering leaves.": {
      "file": "storybook-13.webp",
      "index": 6,
      "columns": 4,
      "rows": 4,
      "alt": "A playful kitten chasing a ball of yarn.",
      "kind": "topic"
    },
    "A whale lifted its tail.": {
      "file": "storybook-04.webp",
      "index": 9,
      "columns": 4,
      "rows": 4,
      "alt": "A whale splashing.",
      "kind": "topic"
    },
    "The store displayed colorful scarves.": {
      "file": "writing-scenes-02.webp",
      "index": 3,
      "columns": 4,
      "alt": "Store display of colorful scarves.",
      "kind": "exact"
    },
    "A drummer tapped wooden sticks.": {
      "file": "storybook-09.webp",
      "index": 1,
      "columns": 4,
      "rows": 4,
      "alt": "A young drummer playing a large drum with two drumsticks.",
      "kind": "exact"
    },
    "The baker delivered warm bread.": {
      "file": "storybook-07.webp",
      "index": 7,
      "columns": 4,
      "rows": 4,
      "alt": "A baker placing two golden bread loaves into an oven.",
      "kind": "topic"
    },
    "A camper roasted one marshmallow.": {
      "file": "storybook-08.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A cozy canvas tent and a small safe campfire beside a lake.",
      "kind": "topic"
    },
    "The fox crossed a bridge.": {
      "file": "storybook-07.webp",
      "index": 13,
      "columns": 4,
      "rows": 4,
      "alt": "A wooden footbridge crossing a small stream.",
      "kind": "topic"
    },
    "A penguin balanced an egg.": {
      "file": "writing-scenes-02.webp",
      "index": 4,
      "columns": 4,
      "alt": "Penguin and an egg.",
      "kind": "exact"
    },
    "The gardener filled empty pots.": {
      "file": "storybook-06.webp",
      "index": 7,
      "columns": 4,
      "rows": 4,
      "alt": "A child watering plants.",
      "kind": "topic"
    },
    "A raccoon washed its snack.": {
      "file": "writing-scenes-02.webp",
      "index": 5,
      "columns": 4,
      "alt": "Raccoon and a snack beside water.",
      "kind": "exact"
    },
    "The sunrise painted pink clouds.": {
      "file": "storybook-01.webp",
      "index": 15,
      "columns": 4,
      "rows": 4,
      "alt": "A shining sun.",
      "kind": "topic"
    },
    "A rabbit hopped through grass.": {
      "file": "storybook-03.webp",
      "index": 13,
      "columns": 4,
      "rows": 4,
      "alt": "A rabbit hopping.",
      "kind": "topic"
    },
    "The classroom displayed student artwork.": {
      "file": "storybook-11.webp",
      "index": 4,
      "columns": 4,
      "rows": 4,
      "alt": "An adult hanging a framed drawing neatly on a wall.",
      "kind": "topic"
    },
    "The owl watched a quiet meadow.": {
      "file": "storybook-04.webp",
      "index": 2,
      "columns": 4,
      "rows": 4,
      "alt": "An owl hooting at night.",
      "kind": "topic"
    },
    "A camel crossed the sandy desert.": {
      "file": "storybook-04.webp",
      "index": 6,
      "columns": 4,
      "rows": 4,
      "alt": "A camel drinking.",
      "kind": "topic"
    },
    "The gardener picked purple tulips.": {
      "file": "storybook-06.webp",
      "index": 8,
      "columns": 4,
      "rows": 4,
      "alt": "A girl picking flowers.",
      "kind": "topic"
    },
    "Six frogs jumped over logs.": {
      "file": "storybook-01.webp",
      "index": 4,
      "columns": 4,
      "rows": 4,
      "alt": "A frog jumping.",
      "kind": "topic"
    },
    "The puppy carried a blue leash.": {
      "file": "storybook-05.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A girl petting a puppy.",
      "kind": "topic"
    },
    "A robin sang before sunrise.": {
      "file": "storybook-13.webp",
      "index": 9,
      "columns": 4,
      "rows": 4,
      "alt": "A child cupping one hand behind an ear to listen to a small singing bird.",
      "kind": "topic"
    },
    "The kitten climbed a short fence.": {
      "file": "storybook-13.webp",
      "index": 6,
      "columns": 4,
      "rows": 4,
      "alt": "A playful kitten chasing a ball of yarn.",
      "kind": "topic"
    },
    "The farmer loaded fresh hay.": {
      "file": "storybook-09.webp",
      "index": 5,
      "columns": 4,
      "rows": 4,
      "alt": "A farmer scattering grain for a small flock of chickens.",
      "kind": "topic"
    },
    "A turtle rested beneath shade.": {
      "file": "storybook-03.webp",
      "index": 12,
      "columns": 4,
      "rows": 4,
      "alt": "A turtle walking.",
      "kind": "topic"
    },
    "The baker rolled soft dough.": {
      "file": "storybook-05.webp",
      "index": 6,
      "columns": 4,
      "rows": 4,
      "alt": "A boy rolling dough.",
      "kind": "exact"
    },
    "Two puppies chased fluttering ribbons.": {
      "file": "storybook-05.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A girl petting a puppy.",
      "kind": "topic"
    },
    "The sailor spotted distant islands.": {
      "file": "storybook-08.webp",
      "index": 2,
      "columns": 4,
      "rows": 4,
      "alt": "A friendly ship captain giving directions to two attentive crew members.",
      "kind": "topic"
    },
    "A deer drank cool water.": {
      "file": "writing-scenes-02.webp",
      "index": 6,
      "columns": 4,
      "alt": "Deer drinking from a stream.",
      "kind": "exact"
    },
    "The teacher arranged colored pencils.": {
      "file": "storybook-11.webp",
      "index": 2,
      "columns": 4,
      "rows": 4,
      "alt": "A child sharpening a wooden pencil in a small handheld sharpener.",
      "kind": "topic"
    },
    "The skier raced down snowy hills.": {
      "file": "storybook-10.webp",
      "index": 11,
      "columns": 4,
      "rows": 4,
      "alt": "Two child hikers in warm gloves climbing a gentle snowy mountain trail.",
      "kind": "topic"
    },
    "The frog caught a tiny bug.": {
      "file": "storybook-01.webp",
      "index": 4,
      "columns": 4,
      "rows": 4,
      "alt": "A frog jumping.",
      "kind": "topic"
    },
    "A chef stirred spicy soup.": {
      "file": "storybook-14.webp",
      "index": 14,
      "columns": 4,
      "rows": 4,
      "alt": "A chef stirring a pot of soup with a wooden spoon.",
      "kind": "topic"
    },
    "The rabbit explored tall grass.": {
      "file": "storybook-14.webp",
      "index": 7,
      "columns": 4,
      "rows": 4,
      "alt": "A rabbit hiding among tall green grass.",
      "kind": "topic"
    },
    "The duck splashed in puddles.": {
      "file": "storybook-01.webp",
      "index": 7,
      "columns": 4,
      "rows": 4,
      "alt": "A duck quacking.",
      "kind": "topic"
    },
    "A spider climbed the window.": {
      "file": "storybook-12.webp",
      "index": 5,
      "columns": 4,
      "rows": 4,
      "alt": "A small friendly spider sitting in a delicate web between two branches.",
      "kind": "topic"
    },
    "The clown juggled bright balls.": {
      "file": "writing-scenes-02.webp",
      "index": 7,
      "columns": 4,
      "alt": "Clown and bright juggling balls.",
      "kind": "exact"
    },
    "The pilot studied cloudy maps.": {
      "file": "writing-scenes-02.webp",
      "index": 8,
      "columns": 4,
      "alt": "Pilot and weather maps.",
      "kind": "exact"
    },
    "The fox sniffed fallen leaves.": {
      "file": "storybook-03.webp",
      "index": 15,
      "columns": 4,
      "rows": 4,
      "alt": "A fox running.",
      "kind": "topic"
    },
    "A carpenter built sturdy shelves.": {
      "file": "writing-scenes-02.webp",
      "index": 9,
      "columns": 4,
      "alt": "Carpenter and wooden shelves.",
      "kind": "exact"
    },
    "The musician packed shiny cymbals.": {
      "file": "storybook-11.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A small children's orchestra tuning violins, a cello and a flute before a concert.",
      "kind": "topic"
    },
    "A zebra ran across plains.": {
      "file": "storybook-04.webp",
      "index": 5,
      "columns": 4,
      "rows": 4,
      "alt": "A zebra walking.",
      "kind": "topic"
    },
    "The doctor listened carefully.": {
      "file": "storybook-03.webp",
      "index": 7,
      "columns": 4,
      "rows": 4,
      "alt": "A doctor checking a heart.",
      "kind": "topic"
    },
    "A penguin waddled toward water.": {
      "file": "storybook-04.webp",
      "index": 7,
      "columns": 4,
      "rows": 4,
      "alt": "A penguin sliding on ice.",
      "kind": "topic"
    },
    "The puppy sniffed muddy boots.": {
      "file": "storybook-05.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A girl petting a puppy.",
      "kind": "topic"
    },
    "A knight carried one shield.": {
      "file": "writing-scenes-02.webp",
      "index": 10,
      "columns": 4,
      "alt": "Knight and a shield.",
      "kind": "exact"
    },
    "The baker decorated chocolate cakes.": {
      "file": "storybook-07.webp",
      "index": 14,
      "columns": 4,
      "rows": 4,
      "alt": "A baker carefully placing a round cake into an oven.",
      "kind": "topic"
    },
    "A bee visited orange flowers.": {
      "file": "storybook-03.webp",
      "index": 8,
      "columns": 4,
      "rows": 4,
      "alt": "A buzzing bee.",
      "kind": "topic"
    },
    "Moonlight covered a quiet lake.": {
      "file": "storybook-02.webp",
      "index": 2,
      "columns": 4,
      "rows": 4,
      "alt": "A glowing moon.",
      "kind": "topic"
    },
    "The train reached a station.": {
      "file": "storybook-12.webp",
      "index": 15,
      "columns": 4,
      "rows": 4,
      "alt": "A train arriving alongside a small station platform.",
      "kind": "topic"
    },
    "A seal balanced one ball.": {
      "file": "storybook-04.webp",
      "index": 8,
      "columns": 4,
      "rows": 4,
      "alt": "A seal clapping.",
      "kind": "topic"
    },
    "The artist sketched smiling faces.": {
      "file": "storybook-02.webp",
      "index": 12,
      "columns": 4,
      "rows": 4,
      "alt": "A child painting.",
      "kind": "topic"
    },
    "A whale swam near shore.": {
      "file": "storybook-04.webp",
      "index": 9,
      "columns": 4,
      "rows": 4,
      "alt": "A whale splashing.",
      "kind": "topic"
    },
    "The farmer repaired a gate.": {
      "file": "writing-scenes-02.webp",
      "index": 11,
      "columns": 4,
      "alt": "Farmer repairing a gate.",
      "kind": "exact"
    },
    "A parrot copied funny sounds.": {
      "file": "writing-scenes-02.webp",
      "index": 12,
      "columns": 4,
      "alt": "Parrot making sounds.",
      "kind": "exact"
    },
    "The bus passed tall buildings.": {
      "file": "storybook-02.webp",
      "index": 5,
      "columns": 4,
      "rows": 4,
      "alt": "A bus stopping.",
      "kind": "topic"
    },
    "A dragon chased silver clouds.": {
      "file": "writing-scenes-02.webp",
      "index": 13,
      "columns": 4,
      "alt": "Friendly dragon among silver clouds.",
      "kind": "exact"
    },
    "A cashier closed the register.": {
      "file": "writing-scenes-02.webp",
      "index": 14,
      "columns": 4,
      "alt": "Cashier and a closed register.",
      "kind": "exact"
    },
    "The puppy licked cold snow.": {
      "file": "storybook-05.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A girl petting a puppy.",
      "kind": "topic"
    },
    "A ranger mapped forest trails.": {
      "file": "storybook-12.webp",
      "index": 14,
      "columns": 4,
      "rows": 4,
      "alt": "A family looking at a trail map at the start of a forest hike, no legible text.",
      "kind": "topic"
    },
    "The painter chose bright colors.": {
      "file": "storybook-02.webp",
      "index": 12,
      "columns": 4,
      "rows": 4,
      "alt": "A child painting.",
      "kind": "topic"
    },
    "The cat napped beside pillows.": {
      "file": "storybook-13.webp",
      "index": 4,
      "columns": 4,
      "rows": 4,
      "alt": "A small kitten curled up asleep in a cozy woven basket.",
      "kind": "topic"
    },
    "A detective found hidden clues.": {
      "file": "storybook-08.webp",
      "index": 14,
      "columns": 4,
      "rows": 4,
      "alt": "A child detective using a magnifying glass to examine small clues on the ground.",
      "kind": "topic"
    },
    "The storm soaked empty streets.": {
      "file": "storybook-12.webp",
      "index": 7,
      "columns": 4,
      "rows": 4,
      "alt": "Dark gray rain clouds over a small landscape, a distant gentle lightning flash.",
      "kind": "topic"
    },
    "A squirrel climbed slippery bark.": {
      "file": "storybook-12.webp",
      "index": 6,
      "columns": 4,
      "rows": 4,
      "alt": "A squirrel with a large bushy tail holding a nut, with more nuts by a tree.",
      "kind": "topic"
    },
    "The baker kneaded warm dough.": {
      "file": "storybook-05.webp",
      "index": 6,
      "columns": 4,
      "rows": 4,
      "alt": "A boy rolling dough.",
      "kind": "topic"
    },
    "A pirate raised striped sails.": {
      "file": "storybook-08.webp",
      "index": 2,
      "columns": 4,
      "rows": 4,
      "alt": "A friendly ship captain giving directions to two attentive crew members.",
      "kind": "topic"
    },
    "The nurse checked sore ankles.": {
      "file": "storybook-03.webp",
      "index": 6,
      "columns": 4,
      "rows": 4,
      "alt": "A nurse helping children.",
      "kind": "topic"
    },
    "The teacher rang a bell.": {
      "file": "writing-scenes-02.webp",
      "index": 15,
      "columns": 4,
      "alt": "Teacher holding a bell.",
      "kind": "exact"
    },
    "A rabbit chewed leafy greens.": {
      "file": "writing-scenes-03.webp",
      "index": 0,
      "columns": 4,
      "alt": "Rabbit and leafy greens.",
      "kind": "exact"
    },
    "The gardener planted tall sunflowers.": {
      "file": "storybook-12.webp",
      "index": 9,
      "columns": 4,
      "rows": 4,
      "alt": "A young sunflower growing from dark soil, with sunshine and a small watering can.",
      "kind": "topic"
    },
    "A boat floated past docks.": {
      "file": "ship-harbor.webp",
      "index": 0,
      "columns": 1,
      "rows": 1,
      "alt": "A ship docked safely beside a harbor pier.",
      "kind": "topic"
    },
    "The drummer carried brass cymbals.": {
      "file": "storybook-11.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A small children's orchestra tuning violins, a cello and a flute before a concert.",
      "kind": "topic"
    },
    "A penguin wore one scarf.": {
      "file": "writing-scenes-03.webp",
      "index": 1,
      "columns": 4,
      "alt": "Penguin with a scarf.",
      "kind": "exact"
    },
    "The scientist tested salty water.": {
      "file": "storybook-12.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A friendly scientist recording an experiment in a notebook at a simple laboratory table.",
      "kind": "topic"
    },
    "The firefighter drove a truck.": {
      "file": "storybook-09.webp",
      "index": 7,
      "columns": 4,
      "rows": 4,
      "alt": "A friendly firefighter in a red helmet spraying water from a hose beside a fire engine.",
      "kind": "topic"
    },
    "The eagle circled above cliffs.": {
      "file": "storybook-09.webp",
      "index": 2,
      "columns": 4,
      "rows": 4,
      "alt": "An eagle stretching its wide wings above a deep canyon.",
      "kind": "topic"
    },
    "A boy tossed smooth pebbles.": {
      "file": "writing-scenes-03.webp",
      "index": 2,
      "columns": 4,
      "alt": "Boy and smooth pebbles beside a pond.",
      "kind": "exact"
    },
    "The librarian opened a window.": {
      "file": "storybook-07.webp",
      "index": 12,
      "columns": 4,
      "rows": 4,
      "alt": "A librarian gently shelving books on a low wooden bookshelf.",
      "kind": "topic"
    },
    "A bird built one nest.": {
      "file": "storybook-08.webp",
      "index": 12,
      "columns": 4,
      "rows": 4,
      "alt": "A black crow building a twig nest in a tall pine tree.",
      "kind": "topic"
    },
    "The coach praised brave players.": {
      "file": "storybook-08.webp",
      "index": 5,
      "columns": 4,
      "rows": 4,
      "alt": "A friendly coach explaining a soccer play to attentive children.",
      "kind": "topic"
    },
    "A horse trotted through fields.": {
      "file": "storybook-01.webp",
      "index": 8,
      "columns": 4,
      "rows": 4,
      "alt": "A horse trotting.",
      "kind": "exact"
    },
    "The dentist fixed a tooth.": {
      "file": "storybook-08.webp",
      "index": 13,
      "columns": 4,
      "rows": 4,
      "alt": "A kind dentist checking a child's teeth in a bright friendly dental room.",
      "kind": "topic"
    },
    "A family packed picnic baskets.": {
      "file": "storybook-11.webp",
      "index": 3,
      "columns": 4,
      "rows": 4,
      "alt": "An open picnic basket containing sandwiches and apples on a checkered picnic blanket.",
      "kind": "topic"
    },
    "The wind pushed gray clouds.": {
      "file": "storybook-12.webp",
      "index": 7,
      "columns": 4,
      "rows": 4,
      "alt": "Dark gray rain clouds over a small landscape, a distant gentle lightning flash.",
      "kind": "topic"
    },
    "A goat climbed steep rocks.": {
      "file": "writing-scenes-03.webp",
      "index": 3,
      "columns": 4,
      "alt": "Goat on steep rocks.",
      "kind": "exact"
    },
    "The baker sold cinnamon rolls.": {
      "file": "writing-scenes-03.webp",
      "index": 4,
      "columns": 4,
      "alt": "Baker and cinnamon rolls.",
      "kind": "exact"
    },
    "A puppy chased bubbles.": {
      "file": "storybook-05.webp",
      "index": 2,
      "columns": 4,
      "rows": 4,
      "alt": "A child blowing bubbles.",
      "kind": "topic"
    },
    "The frog hid under stones.": {
      "file": "storybook-09.webp",
      "index": 10,
      "columns": 4,
      "rows": 4,
      "alt": "A pond with a frog on a lily pad and clearly visible little tadpoles in the water.",
      "kind": "topic"
    },
    "A carpenter measured narrow boards.": {
      "file": "storybook-09.webp",
      "index": 12,
      "columns": 4,
      "rows": 4,
      "alt": "An adult using a hammer to tap a nail into a wooden board.",
      "kind": "topic"
    },
    "The astronaut packed a helmet.": {
      "file": "storybook-07.webp",
      "index": 4,
      "columns": 4,
      "rows": 4,
      "alt": "An astronaut packing small sealed food pouches into a suitcase beside a space helmet.",
      "kind": "topic"
    },
    "A dolphin leaped above waves.": {
      "file": "storybook-tools.webp",
      "index": 4,
      "columns": 4,
      "rows": 4,
      "alt": "A dolphin leaping above ocean waves.",
      "kind": "topic"
    },
    "The crowd waved tiny flags.": {
      "file": "storybook-11.webp",
      "index": 1,
      "columns": 4,
      "rows": 4,
      "alt": "A cheerful small street parade with musicians and people waving.",
      "kind": "topic"
    },
    "A mouse carried cheese.": {
      "file": "storybook-03.webp",
      "index": 14,
      "columns": 4,
      "rows": 4,
      "alt": "A mouse hiding.",
      "kind": "topic"
    },
    "The teacher praised careful writers.": {
      "file": "storybook-12.webp",
      "index": 11,
      "columns": 4,
      "rows": 4,
      "alt": "Children writing thank-you notes at a table, no legible lettering.",
      "kind": "topic"
    },
    "A tractor pulled heavy wagons.": {
      "file": "writing-scenes-03.webp",
      "index": 5,
      "columns": 4,
      "alt": "Tractor and heavy wagons.",
      "kind": "exact"
    },
    "The cat watched raindrops.": {
      "file": "storybook-13.webp",
      "index": 6,
      "columns": 4,
      "rows": 4,
      "alt": "A playful kitten chasing a ball of yarn.",
      "kind": "topic"
    },
    "A bell rang across campus.": {
      "file": "writing-scenes-03.webp",
      "index": 6,
      "columns": 4,
      "alt": "Campus buildings and a ringing bell.",
      "kind": "exact"
    },
    "The artist framed a portrait.": {
      "file": "storybook-11.webp",
      "index": 4,
      "columns": 4,
      "rows": 4,
      "alt": "An adult hanging a framed drawing neatly on a wall.",
      "kind": "topic"
    },
    "A sailor tied strong knots.": {
      "file": "storybook-08.webp",
      "index": 2,
      "columns": 4,
      "rows": 4,
      "alt": "A friendly ship captain giving directions to two attentive crew members.",
      "kind": "topic"
    },
    "The fox listened near bushes.": {
      "file": "storybook-03.webp",
      "index": 15,
      "columns": 4,
      "rows": 4,
      "alt": "A fox running.",
      "kind": "topic"
    },
    "A puppy found striped socks.": {
      "file": "storybook-05.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A girl petting a puppy.",
      "kind": "topic"
    },
    "The farmer fed hungry goats.": {
      "file": "writing-scenes-03.webp",
      "index": 7,
      "columns": 4,
      "alt": "Farmer feeding goats.",
      "kind": "exact"
    },
    "The child hugged a blanket.": {
      "file": "writing-scenes-03.webp",
      "index": 8,
      "columns": 4,
      "alt": "Child hugging a blanket.",
      "kind": "exact"
    },
    "The store sold red balloons.": {
      "file": "writing-scenes-03.webp",
      "index": 9,
      "columns": 4,
      "alt": "Store and red balloons.",
      "kind": "exact"
    },
    "A truck carried wooden crates.": {
      "file": "storybook-02.webp",
      "index": 11,
      "columns": 4,
      "rows": 4,
      "alt": "A truck honking.",
      "kind": "topic"
    },
    "The baker served fruit pies.": {
      "file": "writing-scenes-03.webp",
      "index": 10,
      "columns": 4,
      "alt": "Baker and fruit pies.",
      "kind": "exact"
    },
    "A butterfly drank flower nectar.": {
      "file": "storybook-03.webp",
      "index": 9,
      "columns": 4,
      "rows": 4,
      "alt": "A butterfly landing on a flower.",
      "kind": "topic"
    },
    "The doctor washed clean hands.": {
      "file": "storybook-05.webp",
      "index": 8,
      "columns": 4,
      "rows": 4,
      "alt": "A child washing hands.",
      "kind": "topic"
    },
    "A puppy guarded the porch.": {
      "file": "storybook-05.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A girl petting a puppy.",
      "kind": "topic"
    },
    "The river splashed over stones.": {
      "file": "storybook-11.webp",
      "index": 11,
      "columns": 4,
      "rows": 4,
      "alt": "A winding blue river flowing through a green valley.",
      "kind": "topic"
    },
    "The knight rode a horse.": {
      "file": "writing-scenes-03.webp",
      "index": 11,
      "columns": 4,
      "alt": "Knight on a horse.",
      "kind": "exact"
    },
    "The chef served lemon rice.": {
      "file": "writing-scenes-03.webp",
      "index": 12,
      "columns": 4,
      "alt": "Chef and lemon rice.",
      "kind": "exact"
    },
    "A parrot watched green trees.": {
      "file": "storybook-13.webp",
      "index": 0,
      "columns": 4,
      "rows": 4,
      "alt": "A tall spreading oak tree in a green park.",
      "kind": "topic"
    },
    "The sun warmed chilly sand.": {
      "file": "storybook-01.webp",
      "index": 15,
      "columns": 4,
      "rows": 4,
      "alt": "A shining sun.",
      "kind": "topic"
    },
    "The child opened a present.": {
      "file": "storybook-04.webp",
      "index": 14,
      "columns": 4,
      "rows": 4,
      "alt": "A child opening gifts.",
      "kind": "topic"
    }
  },
  "grammar": {}
};
