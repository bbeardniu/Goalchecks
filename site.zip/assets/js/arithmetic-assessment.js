(() => {
  'use strict';
  const core = window.BeardArithmeticCore, app = document.getElementById('arithmeticApp');
  if (!core || !app) return;
  const $ = id => document.getElementById(id), body = document.body, data = body.dataset;
  const mode = data.arithmeticMode || 'whole', allowed = mode === 'no-regroup' ? ['add','subtract'] : Object.keys(core.operations);
  const ranges = String(data.arithmeticRanges || '5,10,20,50,100,1000,100000,1000000').split(',').map(Number);
  let options = {mode,max:Number(data.arithmeticMaximum || 100),factMax:9,family:0,regrouping:mode === 'no-regroup'?'without':'any',large:data.arithmeticLarge === 'true',operations:String(data.arithmeticOperations || 'add,subtract').split(',')};
  const random = () => window.BeardRun?.random?.() ?? Math.random();
  const escape = value => String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let active = false, locked = true, current = null, history = [], operationBag = [], lastProblem = '';
  let startedAt = null, questionAt = null, stoppedSeconds = 0, stoppedDate = null, timer = null, advanceTimer = null, correct = 0;
  function shuffled(values) { const result=values.slice();for(let i=result.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[result[i],result[j]]=[result[j],result[i]];}return result; }
  function operationsText() { return options.operations.map(op=>core.operations[op].name).join(' + '); }
  function level() {
    if (mode === 'no-regroup') return operationsText()+' · two-digit numbers · no regrouping';
    if (mode === 'facts') return operationsText()+' · facts through '+options.factMax+(options.family?' · '+options.family+' family':'');
    return operationsText()+' · whole numbers within '+options.max.toLocaleString('en-US')+(options.operations.some(op=>['multiply','divide'].includes(op))?' · multiplication/division facts through '+options.factMax:'')+(options.regrouping!=='any'?' · add/sub '+options.regrouping+' regrouping':'');
  }
  function updateLevel() {
    data.beardLevel=level();data.beardSkill='Whole-number arithmetic';
    const names=options.operations.map(op=>core.operations[op].name),heading=names.length===4?'Mixed Arithmetic':names.join(' & ');
    $('arithmeticHeading').textContent=heading+(mode==='no-regroup'?' · No Regrouping':mode==='facts'?' Facts':' · Within '+options.max.toLocaleString('en-US'));
    document.title=$('arithmeticHeading').textContent+' Goal Check';
    $('arithmeticLevelNote').textContent=mode==='no-regroup'?'Both operands have two digits. Addition has no carrying; subtraction has no borrowing.':mode==='facts'?'Multiplication uses factors through '+options.factMax+'. Division uses exact fact families through '+options.factMax+' with no zero divisor. Addition and subtraction use numbers through '+options.factMax+'.':'All operands and answers stay within '+options.max.toLocaleString('en-US')+'. Multiplication and division also use the selected fact range; division answers are whole numbers.';
    const facts=options.operations.some(op=>['multiply','divide'].includes(op));$('arithmeticFactsField').hidden=mode==='no-regroup'||mode!=='facts'&&!facts;
    $('arithmeticFactMaxLabel').textContent=mode==='facts'?'Fact numbers':'Multiplication / division facts';
    $('arithmeticRegroupingField').hidden=mode!=='whole'||!options.operations.some(op=>['add','subtract'].includes(op));
    $('arithmeticFamilyField').hidden=mode!=='facts';
  }
  function settings() { return {...options,operations:options.operations.slice()}; }
  function elapsed() { return active ? Math.max(0,(Date.now()-startedAt)/1000) : stoppedSeconds; }
  function cancelTimers() { clearTimeout(advanceTimer);clearInterval(timer);advanceTimer=null;timer=null; }
  function stats() { $('attempts').textContent='Attempts: '+history.length;$('attempts').dataset.beardCorrect=String(correct);$('score').textContent='Score: '+(history.length?Math.round(correct/history.length*100):0)+'%'; }
  function next() {
    if(!active)return false;
    clearTimeout(advanceTimer);advanceTimer=null;
    if(!operationBag.length)operationBag=shuffled(options.operations);
    const operation=operationBag.pop();
    for(let i=0;i<8;i++){current=core.generate(options,random,operation);if(current.problem!==lastProblem)break;}
    lastProblem=current.problem;locked=false;questionAt=Date.now();
    $('problem').textContent=current.problem;$('problem').dataset.beardProblem=current.problem;
    $('answer').value='';$('answer').disabled=false;$('answer').removeAttribute('aria-invalid');$('submitBtn').disabled=false;$('nextBtn').disabled=true;
    $('feedback').textContent='';$('feedback').className='';$('answerHelp').textContent='Enter a whole-number answer. Commas are optional.';
    if(window.matchMedia?.('(pointer:fine)').matches)$('answer').focus({preventScroll:true});return true;
  }
  function state() { return {assessment:document.title,skill:'Whole-number arithmetic',level:level(),settings:settings(),active,attempts:history.length,correct,errors:history.length-correct,seconds:elapsed(),date:stoppedDate?.toISOString(),scoreType:'Accuracy',score:history.length?correct/history.length:null,percentage:history.length?Math.round(correct/history.length*100):null,current:current?{...current}:null,responses:history.map(row=>({...row}))}; }
  function submit() {
    if(!active||locked||!current)return false;
    const raw=$('answer').value.trim(),parsed=core.parse(raw);
    if(!parsed.valid){$('answer').setAttribute('aria-invalid','true');$('answerHelp').textContent='Enter a whole number using digits. Do not use letters or an exponent; group any commas in threes.';return false;}
    locked=true;const outcome=parsed.value===current.expected;if(outcome)correct++;
    history.push({problem:current.problem,prompt:current.problem,answer:raw,expected:current.expected,operation:current.operation,correct:outcome,outcome,seconds:Math.max(0,(Date.now()-questionAt)/1000),elapsedSeconds:elapsed()});
    $('answer').disabled=true;$('submitBtn').disabled=true;$('nextBtn').disabled=false;stats();
    $('feedback').textContent=outcome?'Correct!':'Incorrect. The answer is '+current.expected.toLocaleString('en-US')+'.';$('feedback').className=outcome?'good':'bad';
    advanceTimer=setTimeout(next,750);return true;
  }
  function renderReport() {
    const percent=history.length?Math.round(correct/history.length*100):0;
    $('summary').innerHTML='<h2>Arithmetic Results</h2><p class="arithmetic-report-meta"><strong>'+escape(stoppedDate.toLocaleDateString())+' · '+(history.length?percent+'%':'No responses')+'</strong><br>'+escape(level())+'<br>Correct: '+correct+' / '+history.length+' · Total time: '+stoppedSeconds.toFixed(1)+' seconds</p><div class="arithmetic-response-grid">'+history.map((row,i)=>'<article class="arithmetic-response-card" data-beard-response-index="'+i+'" tabindex="0" role="button" title="Right-click to change Correct / Incorrect"><span>'+(i+1)+'. '+escape(row.problem)+'</span><strong class="'+(row.correct?'good':'bad')+'">'+escape(row.answer)+'</strong><small>'+row.seconds.toFixed(1)+' s</small></article>').join('')+'</div><div class="arithmetic-controls"><button type="button" id="arithmeticAgain">Reset check</button><button type="button" id="arithmeticPrint">Print / Save PDF</button></div>';
    $('summary').style.display='block';$('arithmeticAgain').addEventListener('click',requestReset);$('arithmeticPrint').addEventListener('click',()=>window.print());
  }
  function stop() {
    if(!active)return false;stoppedSeconds=elapsed();stoppedDate=new Date();active=false;locked=true;cancelTimers();
    $('workArea').hidden=true;$('answer').disabled=true;$('submitBtn').disabled=true;$('nextBtn').disabled=true;$('stopBtn').disabled=true;$('feedback').textContent='';
    renderReport();document.dispatchEvent(new CustomEvent('beard:assessment-stop',{detail:{state:state()}}));return true;
  }
  function correctResponse(index,outcome) {
    if(active||!Number.isInteger(index)||index<0||index>=history.length||typeof outcome!=='boolean')return false;
    history[index].correct=outcome;history[index].outcome=outcome;correct=history.filter(row=>row.correct).length;stats();renderReport();document.dispatchEvent(new CustomEvent('beard:report-updated'));return true;
  }
  function reset() {
    cancelTimers();active=false;locked=true;current=null;history=[];operationBag=[];lastProblem='';correct=0;startedAt=null;questionAt=null;stoppedSeconds=0;stoppedDate=null;
    $('summary').replaceChildren();$('summary').style.display='none';$('workArea').hidden=false;$('answer').value='';$('answer').disabled=true;$('answer').removeAttribute('aria-invalid');$('submitBtn').disabled=true;$('nextBtn').disabled=true;$('stopBtn').disabled=true;$('problem').textContent='A new problem will appear automatically.';$('problem').dataset.beardProblem='';$('feedback').textContent='';$('timer').textContent='Time: 0s';stats();updateLevel();
  }
  function start() { reset();active=true;startedAt=Date.now();$('stopBtn').disabled=false;timer=setInterval(()=>$('timer').textContent='Time: '+Math.floor(elapsed())+'s',250);next(); }
  function requestReset() { reset();document.dispatchEvent(new CustomEvent('beard:settings-changed',{detail:{level:level(),skill:data.beardSkill}}));if(!data.beardAutoStart)start(); }
  function syncControls() {
    allowed.forEach(op=>{$('arithmeticOp-'+op).checked=options.operations.includes(op);});
    $('arithmeticMaximum').value=String(options.max);$('arithmeticFactMax').value=String(options.factMax);$('arithmeticFamily').value=String(options.family);$('arithmeticRegrouping').value=options.regrouping;
    for(const option of $('arithmeticFamily').options)option.disabled=Number(option.value)>options.factMax;
  }
  const params=new URLSearchParams(window.location?.search||'');
  if(ranges.includes(Number(params.get('max'))))options.max=Number(params.get('max'));
  if([5,9,12].includes(Number(params.get('factMax'))))options.factMax=Number(params.get('factMax'));
  if(Number(params.get('fact'))>=2&&Number(params.get('fact'))<=options.factMax)options.family=Number(params.get('fact'));
  if(mode!=='no-regroup'&&['any','with','without'].includes(params.get('regrouping')))options.regrouping=params.get('regrouping');
  const requested=params.has('operations')?params.get('operations').split(','):params.get('operation')==='all'?allowed:allowed.includes(params.get('operation'))?[params.get('operation')]:null;
  if(requested?.length&&requested.every(op=>allowed.includes(op)))options.operations=[...new Set(requested)];
  if(options.max<10&&options.regrouping==='with')options.regrouping='any';
  syncControls();
  for(const op of allowed)$('arithmeticOp-'+op).addEventListener('change',event=>{
    const selected=allowed.filter(value=>$('arithmeticOp-'+value).checked);
    if(!selected.length){event.target.checked=true;$('arithmeticSettingsStatus').textContent='Keep at least one operation selected.';return;}
    options.operations=selected;$('arithmeticSettingsStatus').textContent='';requestReset();
  });
  $('arithmeticMaximum').addEventListener('change',()=>{options.max=Number($('arithmeticMaximum').value);if(options.max<10&&options.regrouping==='with')options.regrouping='any';syncControls();$('arithmeticSettingsStatus').textContent='';requestReset();});
  $('arithmeticFactMax').addEventListener('change',()=>{options.factMax=Number($('arithmeticFactMax').value);if(options.family>options.factMax)options.family=0;syncControls();requestReset();});
  $('arithmeticFamily').addEventListener('change',()=>{options.family=Number($('arithmeticFamily').value);requestReset();});
  $('arithmeticRegrouping').addEventListener('change',()=>{if($('arithmeticRegrouping').value==='with'&&options.max<10){$('arithmeticRegrouping').value=options.regrouping;$('arithmeticSettingsStatus').textContent='Choose a number range of at least 10 for regrouping.';return;}options.regrouping=$('arithmeticRegrouping').value;requestReset();});
  $('submitBtn').addEventListener('click',submit);$('nextBtn').addEventListener('click',()=>{if(active&&locked)next();});$('stopBtn').addEventListener('click',stop);$('resetBtn').addEventListener('click',requestReset);
  $('answer').addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.repeat){event.preventDefault();submit();}});
  function correctFromEvent(event) {
    if(active||event.target.closest?.('button,input,select,a'))return;
    const card=event.target.closest?.('[data-beard-response-index]');if(!card)return;
    if(event.type==='keydown'&&(event.repeat||!['Enter',' '].includes(event.key)))return;
    const index=Number(card.dataset.beardResponseIndex);if(!history[index])return;
    if(correctResponse(index,!history[index].correct)){event.preventDefault();event.stopPropagation();}
  }
  $('summary').addEventListener('contextmenu',correctFromEvent);$('summary').addEventListener('keydown',correctFromEvent);
  document.addEventListener('beard:run-start',start);
  window.BeardAssessment={start,reset,stop,getState:state};window.BeardAssessmentState={getReport:state,reset,stop,correctResponse};
  if(window.top===window)start();else reset();
})();
