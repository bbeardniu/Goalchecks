(() => {
  'use strict';
  const bank=window.BeardSpellingBank,core=window.BeardSpellingCore,studentView=window.BeardSpellingStudent;
  const $=id=>document.getElementById(id);
  if(!bank?.grades||!core||!studentView){$('practiceApp').hidden=true;$('practiceError').hidden=false;return;}
  const gradeSelect=$('practiceGrade'),unitSelect=$('practiceUnit'),weekSelect=$('practiceWeek');
  let test=null,anonymous=null,view=null,currentWeek=1;
  function option(value,label){const node=document.createElement('option');node.value=String(value);node.textContent=label;return node;}
  function gradeData(grade){return bank.grades[String(grade)]||bank.grades['2'];}
  function selectedUnit(grade,unitId){const units=gradeData(grade).units;return units.find(unit=>unit.id===unitId)||units[0];}
  function validWeek(value,unit){const number=Number(value);return Number.isInteger(number)&&number>=1&&number<=unit.lessons.length?number:1;}
  function label(){return 'Grade '+test.grade+' · '+selectedUnit(test.grade,test.unitId).title+' · Week '+currentWeek;}
  function populate(grade,unitId,week){
    const data=gradeData(grade),unit=selectedUnit(grade,unitId);
    gradeSelect.value=String(grade);
    unitSelect.replaceChildren(...data.units.map(item=>option(item.id,item.title)));
    unitSelect.value=unit.id;
    weekSelect.replaceChildren(...unit.lessons.map((_,index)=>option(index+1,'Week '+(index+1))));
    weekSelect.value=String(validWeek(week,unit));
  }
  function updateUrl(){
    try{const url=new URL(window.location.href);url.searchParams.set('grade',test.grade);url.searchParams.set('unit',test.unitId);url.searchParams.set('week',String(currentWeek));url.searchParams.delete('lesson');window.history.replaceState(null,'',url.href);}catch{}
  }
  function chooseAnotherWeek(){
    $('practiceChoices').scrollIntoView({behavior:window.matchMedia?.('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});
    weekSelect.focus({preventScroll:true});
  }
  function newPractice(config){
    try{
      const retainFocus=[gradeSelect,unitSelect,weekSelect].includes(document.activeElement)?document.activeElement:null;
      const grade=String(config.grade)==='3'?'3':'2',unit=selectedUnit(grade,config.unitId),week=validWeek(config.week,unit),lesson=unit.lessons[week-1];
      const fresh=core.createTest(bank,{grade,unitId:unit.id,lessonId:lesson.id});
      view?.reset();
      test=fresh;currentWeek=week;
      anonymous={id:'practice',name:'',responses:test.words.map(()=>({spelling:'',correct:null}))};
      populate(grade,unit.id,week);
      $('practiceMeta').textContent=label()+' · '+test.words.length+' words';
      $('practiceStatus').textContent='';
      document.title='Spelling Practice · '+label()+" · Beard's Classroom";
      updateUrl();
      view?.open();
      retainFocus?.focus({preventScroll:true});
      return true;
    }catch(error){$('practiceStatus').textContent='This practice list could not load. Choose another week or refresh the page.';return false;}
  }
  function repeatPractice(){return newPractice({grade:test.grade,unitId:test.unitId,week:currentWeek});}
  function keepResponse(index,patch){
    if(!Number.isInteger(index)||index<0||index>=anonymous.responses.length||typeof patch?.spelling!=='string'||Array.from(patch.spelling).length>core.MAX_SPELLING_LENGTH)throw new Error('This answer could not be kept. Please try again.');
    // Anonymous practice keeps only the learner's own text, never a score or answer review.
    anonymous.responses[index]={spelling:patch.spelling,correct:null};
  }
  try{
    view=studentView.mount({host:$('practicePlayer'),standalone:true,getTest:()=>test,getStudent:()=>anonymous,setResponse:keepResponse,getLabel:label,onChooseList:chooseAnotherWeek,onRepeat:repeatPractice});
    const params=new URLSearchParams(window.location.search),grade=params.get('grade')==='3'?'3':'2';
    if(!newPractice({grade,unitId:params.get('unit'),week:params.get('week')}))throw new Error('No practice list');
    gradeSelect.addEventListener('change',()=>newPractice({grade:gradeSelect.value,unitId:gradeData(gradeSelect.value).units[0].id,week:1}));
    unitSelect.addEventListener('change',()=>newPractice({grade:test.grade,unitId:unitSelect.value,week:1}));
    weekSelect.addEventListener('change',()=>newPractice({grade:test.grade,unitId:test.unitId,week:weekSelect.value}));
    $('practiceShuffle').addEventListener('click',repeatPractice);
  }catch(error){$('practiceApp').hidden=true;$('practiceError').hidden=false;}
})();
