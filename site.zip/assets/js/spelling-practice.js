(() => {
  'use strict';
  const bank=window.BeardSpellingBank,phonics=window.BeardSpellingPhonics,core=window.BeardSpellingCore,studentView=window.BeardSpellingStudent;
  const sessionFactory=window.BeardSpellingPracticeSession,reports=window.BeardSpellingPracticeReport;
  const $=id=>document.getElementById(id);
  if(!bank?.grades||!phonics?.skills?.length||!core||!studentView||!sessionFactory||!reports){$('practiceApp').hidden=true;$('practiceError').hidden=false;$('practiceStop').disabled=true;return;}
  const gradeSelect=$('practiceGrade'),unitSelect=$('practiceUnit'),weekSelect=$('practiceWeek');
  let test=null,anonymous=null,view=null,session=null,currentWeek=1,timer=null,rang=false,audioContext=null,lastHeardIndex=null,runNumber=0;
  const mixedWords=new Map();
  phonics.skills.forEach(skill=>skill.words.forEach(word=>{const key=core.normalizeWord(word);if(!mixedWords.has(key))mixedWords.set(key,word);}));
  const skills=[...phonics.skills,{id:'mixed',label:'Mixed Phonics · All Skills',words:[...mixedWords.values()]}];
  function option(value,label){const node=document.createElement('option');node.value=String(value);node.textContent=label;return node;}
  function gradeData(grade){return bank.grades[String(grade)]||bank.grades['2'];}
  function selectedUnit(grade,unitId){const units=gradeData(grade).units;return units.find(unit=>unit.id===unitId)||units[0];}
  function validWeek(value,unit){const number=Number(value);return Number.isInteger(number)&&number>=1&&number<=unit.lessons.length?number:1;}
  function selectedSkill(id){return skills.find(skill=>skill.id===id)||skills[0];}
  function shuffled(words){const result=[...words];for(let index=result.length-1;index>0;index--){const other=Math.floor(Math.random()*(index+1));[result[index],result[other]]=[result[other],result[index]];}return result;}
  function label(){return test.grade==='all'?'All grades · Phonics · '+selectedSkill(test.unitId).label:'Grade '+test.grade+' · '+selectedUnit(test.grade,test.unitId).title+' · Week '+currentWeek;}
  function fmt(seconds){const whole=Math.max(0,Math.floor(seconds));return Math.floor(whole/60)+':'+String(whole%60).padStart(2,'0');}
  function populate(grade,unitId,week){
    const all=grade==='all';
    gradeSelect.value=String(grade);
    $('practiceUnitLabel').textContent=all?'Phonics skill':'Unit';
    $('practiceWeekField').hidden=all;
    $('practiceSelectors').classList.toggle('is-phonics',all);
    if(all){unitSelect.replaceChildren(...skills.map(skill=>option(skill.id,skill.label)));unitSelect.value=selectedSkill(unitId).id;return;}
    const data=gradeData(grade),unit=selectedUnit(grade,unitId);
    unitSelect.replaceChildren(...data.units.map(item=>option(item.id,item.title)));
    unitSelect.value=unit.id;
    weekSelect.replaceChildren(...unit.lessons.map((_,index)=>option(index+1,'Week '+(index+1))));
    weekSelect.value=String(validWeek(week,unit));
  }
  function updateUrl(){
    try{const url=new URL(window.location.href);url.searchParams.set('grade',test.grade);url.searchParams.delete('lesson');if(test.grade==='all'){url.searchParams.set('skill',test.unitId);url.searchParams.delete('unit');url.searchParams.delete('week');}else{url.searchParams.set('unit',test.unitId);url.searchParams.set('week',String(currentWeek));url.searchParams.delete('skill');}window.history.replaceState(null,'',url.href);}catch{}
  }
  function unlockAudio(){
    try{const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)return;audioContext??=new Audio();audioContext.resume?.()?.catch?.(()=>{});}catch{}
  }
  function chime(){
    if(rang)return;rang=true;
    try{unlockAudio();if(!audioContext)return;const now=audioContext.currentTime,gain=audioContext.createGain();gain.gain.setValueAtTime(.001,now);gain.gain.exponentialRampToValueAtTime(.22,now+.03);gain.gain.exponentialRampToValueAtTime(.001,now+.8);gain.connect(audioContext.destination);[740,988].forEach((frequency,index)=>{const osc=audioContext.createOscillator();osc.type='sine';osc.frequency.setValueAtTime(frequency,now+index*.12);osc.connect(gain);osc.start(now+index*.12);osc.stop(now+.8);});}catch{}
  }
  function renderHud(){
    if(!session)return;const state=session.getState();
    $('beard-countdown').textContent=state.totalSeconds<=60?'Countdown: '+fmt(state.countdownSeconds):'Overtime: +'+fmt(state.overtimeSeconds);
    $('practiceElapsed').textContent='Elapsed: '+fmt(state.totalSeconds);
    $('beard-percent').textContent=state.pending?'Score: Pending':state.percentage===null?'Score: —':'Score: '+state.percentage+'%';
    $('beard-attempts').textContent='Attempts: '+state.attempts;
    $('beard-errors').textContent='Errors: '+state.errors;
    $('practiceStop').disabled=state.phase!=='running';
    $('beard-countdown-reset').disabled=false;
    if(state.minuteReached)chime();
  }
  function stopTicker(){if(timer!==null){window.clearInterval(timer);timer=null;}}
  function startTicker(){stopTicker();timer=window.setInterval(renderHud,250);renderHud();}
  function chooseAnotherWeek(){
    $('practiceChoices').scrollIntoView({behavior:window.matchMedia?.('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});
    (test.grade==='all'?unitSelect:weekSelect).focus({preventScroll:true});
  }
  function keepResponse(index,patch){
    if(!Number.isInteger(index)||index<0||index>=anonymous.responses.length||typeof patch?.spelling!=='string'||Array.from(patch.spelling).length>core.MAX_SPELLING_LENGTH)throw new Error('This answer could not be kept. Please try again.');
    anonymous.responses[index]={spelling:patch.spelling,correct:null};
  }
  function submitAnswer(index,payload){
    if(!session||session.phase!=='running')return;
    const mode=payload.mode==='paper'?'paper':'type',spelling=mode==='paper'?'':payload.spelling;
    const row=session.submit(index,{spelling,mode});
    if(row)anonymous.responses[index]={spelling:row.spelling,correct:row.outcome};
    renderHud();
  }
  function preparePrint(){
    if(!session||session.phase!=='finished'){$('practicePrintArea').replaceChildren();document.body.classList.remove('practice-report-print');return false;}
    reports.makePrint($('practiceReport'),$('practicePrintArea'));document.body.classList.add('practice-report-print');return true;
  }
  function printReport(){if(preparePrint())window.print();}
  function renderReport(){
    reports.render($('practiceReport'),{state:session.getState(),label:label(),onCorrect:(index,outcome)=>{session.correct(index,outcome);const row=session.getState().responses.find(item=>item.index===index);if(row)anonymous.responses[index].correct=row.outcome;renderHud();renderReport();},onPrint:printReport,onRestart:repeatPractice});
  }
  function finishAssessment(){
    if(!session||session.phase!=='running')return false;
    const current=view?.flush();
    if(current&&!current.done){
      const existing=session.getState().responses.some(row=>row.index===current.index);
      if((current.mode==='type'&&(current.spelling.trim()||existing))||(current.mode==='paper'&&(lastHeardIndex===current.index||existing)))submitAnswer(current.index,current);
    }
    session.finish();stopTicker();view?.suspend();view?.close();renderHud();renderReport();
    $('practiceReport').scrollIntoView({behavior:window.matchMedia?.('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});
    $('practiceReport').focus({preventScroll:true});return true;
  }
  function beginCurrentOrder(){
    stopTicker();view?.reset();rang=false;lastHeardIndex=null;
    anonymous={id:'practice',name:'',responses:test.words.map(()=>({spelling:'',correct:null}))};
    $('practiceReport').replaceChildren();$('practiceReport').hidden=true;$('practicePrintArea').replaceChildren();document.body.classList.remove('practice-report-print');
    session=sessionFactory.create({words:test.words,normalize:core.normalizeWord,now:()=>Date.now()});session.begin();
    $('practiceBannerLabel').textContent=label();$('practiceStatus').textContent='';
    view?.open();startTicker();
  }
  function newPractice(config){
    try{
      const retainFocus=[gradeSelect,unitSelect,weekSelect].includes(document.activeElement)?document.activeElement:null;
      const grade=['all','3'].includes(String(config.grade))?String(config.grade):'2';
      if(grade==='all'){
        const skill=selectedSkill(config.skillId||config.unitId);
        test={version:1,id:'phonics-'+Date.now()+'-'+(++runNumber),grade:'all',unitId:skill.id,lessonId:'all',words:shuffled(skill.words),students:[],createdAt:new Date().toISOString()};currentWeek=1;
      }else{
        const unit=selectedUnit(grade,config.unitId),week=validWeek(config.week,unit),lesson=unit.lessons[week-1];
        test=core.createTest(bank,{grade,unitId:unit.id,lessonId:lesson.id});currentWeek=week;
      }
      populate(grade,test.unitId,currentWeek);
      $('practiceMeta').textContent=label()+' · '+test.words.length+' words';
      document.title='Spelling Practice · '+label()+" · Beard's Classroom";updateUrl();beginCurrentOrder();
      retainFocus?.focus({preventScroll:true});return true;
    }catch(error){$('practiceStatus').textContent='This assessment could not load. Choose another list or refresh the page.';return false;}
  }
  function repeatPractice(){return newPractice({grade:test.grade,unitId:test.unitId,week:currentWeek});}
  try{
    view=studentView.mount({host:$('practicePlayer'),standalone:true,getTest:()=>test,getStudent:()=>anonymous,setResponse:keepResponse,getLabel:label,onChooseList:chooseAnotherWeek,onRepeat:repeatPractice,onPrompt:index=>{session?.notePrompt(index);},onSubmit:submitAnswer,onFinish:finishAssessment,onHear:index=>{lastHeardIndex=index;unlockAudio();}});
    const params=new URLSearchParams(window.location.search),grade=['all','3'].includes(params.get('grade'))?params.get('grade'):'2';
    if(!newPractice({grade,unitId:params.get('skill')||params.get('unit'),week:params.get('week')}))throw new Error('No spelling list');
    gradeSelect.addEventListener('change',()=>newPractice({grade:gradeSelect.value,week:1}));
    unitSelect.addEventListener('change',()=>newPractice({grade:test.grade,unitId:unitSelect.value,week:1}));
    weekSelect.addEventListener('change',()=>newPractice({grade:test.grade,unitId:test.unitId,week:weekSelect.value}));
    $('practiceShuffle').addEventListener('click',repeatPractice);
    $('practiceStop').addEventListener('click',finishAssessment);
    $('beard-countdown-reset').addEventListener('click',beginCurrentOrder);
    document.addEventListener('pointerdown',unlockAudio,{capture:true});
    document.addEventListener('keydown',event=>{
      unlockAudio();if(event.repeat||event.ctrlKey||event.altKey||event.metaKey||event.isComposing||event.target.closest?.('input,textarea,select,[contenteditable]'))return;
      if(event.key==='3'){event.preventDefault();finishAssessment();}
    });
    window.addEventListener('beforeprint',preparePrint);
    window.addEventListener('afterprint',()=>document.body.classList.remove('practice-report-print'));
    window.addEventListener('pagehide',stopTicker);
    window.addEventListener('pageshow',()=>{if(session?.phase==='running')startTicker();});
    window.BeardAssessmentLayout?.attach(document,$('beard-teacher-banner'));
  }catch(error){stopTicker();$('practiceApp').hidden=true;$('practiceError').hidden=false;$('practiceStop').disabled=true;}
})();
