(function () {
  'use strict';

  const win = window;
  const doc = document;
  if (typeof win.addEventListener !== 'function') return;

  let stopped = false;

  function isEditable(target) {
    return Boolean(target && (target.isContentEditable || target.closest?.('input,textarea,select,[contenteditable]:not([contenteditable="false"])')));
  }

  function stopAssessment() {
    // The launcher must finish its shared clock and report through the same
    // control as a mouse/touch Stop, rather than only stopping a native timer.
    if (typeof win.BeardStopAssessment === 'function') return win.BeardStopAssessment();
    if (stopped) return false;

    const control = doc.getElementById('beard-finish-read') ||
      doc.getElementById('stopBtn') || doc.getElementById('stopButton') ||
      doc.querySelector('button[onclick*="stopTimer"]');
    if (control && !control.disabled && !control.hidden) {
      stopped = true;
      control.click();
      return true;
    }
    return false;
  }

  function rearm() { stopped = false; }
  doc.addEventListener('beard:run-start', rearm);
  doc.addEventListener('beard:settings-changed', rearm);
  doc.addEventListener('beard:assessment-stop', () => { stopped = true; });
  doc.addEventListener('change', event => {
    if (event.target?.matches?.('select')) rearm();
  });
  doc.addEventListener('click', event => {
    const control = event.target?.closest?.('button,input[type="button"],input[type="submit"]');
    if (!control) return;
    const label = (control.textContent || control.value || '').trim();
    if (/^(stop|finish|end)(\s|$)/i.test(label) ||
        /^(stopBtn|stopButton|beard-finish-read)$/.test(control.id)) {
      stopped = true;
      return;
    }
    if (/^(start|reset|restart|play again|try again|new check)(\s|$)/i.test(label)) rearm();
  }, true);

  win.addEventListener('keydown', event => {
    if (event.ctrlKey || event.altKey || event.metaKey ||
        event.isComposing || isEditable(event.target)) return;
    if (event.key !== '3') {
      // Standalone passages also have keyboard Start/Reset controls. A later
      // read must be stoppable even when no button was clicked to start it.
      if (!event.repeat && /^[145]$/.test(event.key) &&
          doc.querySelector('button[onclick*="startTimer"]')) rearm();
      return;
    }
    // Capture at the window so old document handlers cannot grade answer 3 or
    // reset a fluency timer before the assessment has been stopped.
    event.preventDefault();
    event.stopImmediatePropagation();
    if (!event.repeat) stopAssessment();
  }, true);

  const stopControl = doc.getElementById('stopBtn') || doc.getElementById('stopButton') ||
    doc.querySelector('button[onclick*="stopTimer"]');
  if (stopControl) {
    stopControl.setAttribute('aria-keyshortcuts', '3');
    stopControl.title = 'Stop assessment (3)';
  }
}());
