/* Original, mathematically constrained one- and two-step word problems. */
(function(root,factory){'use strict';const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.BeardWordProblems=api;})(typeof window!=='undefined'?window:typeof globalThis!=='undefined'?globalThis:null,function(){
  'use strict';
  const operations=Object.freeze(['add','subtract','multiply','divide']);
  const symbols={add:'+',subtract:'−',multiply:'×',divide:'÷'};
  const names=['Nora','Jamal','Eli','Sofia','Riley','Maya','Theo','Ava','Luca','Zoe','Amir','Leah'];
  const count=(number,singular,plural=singular+'s')=>number+' '+(number===1?singular:plural);
  const more=(number,singular,plural=singular+'s')=>number+' more '+(number===1?singular:plural);
  function integer(min,max,random){const value=Math.max(0,Math.min(.9999999999999999,Number(random())||0));return min+Math.floor(value*(max-min+1));}
  function choose(values,random){return values[integer(0,values.length-1,random)];}
  function selected(values){const valid=operations.filter(op=>Array.isArray(values)&&values.includes(op));if(!valid.length)throw new Error('Choose at least one operation.');return valid;}
  function sequences(values,steps){const list=selected(values);if(![1,2].includes(Number(steps)))throw new Error('Choose one or two steps.');return Number(steps)===1?list.map(op=>[op]):list.flatMap(first=>list.map(second=>[first,second]));}
  function calculate(operation,left,right){return operation==='add'?left+right:operation==='subtract'?left-right:operation==='multiply'?left*right:left/right;}
  function rights(operation,left,max){
    const result=[];
    if(operation==='add')for(let right=1;right<=max-left;right++)result.push(right);
    if(operation==='subtract')for(let right=1;right<left;right++)result.push(right);
    if(operation==='multiply'&&left>=2)for(let right=2;right<=Math.min(10,Math.floor(max/left));right++)result.push(right);
    if(operation==='divide')for(let right=2;right<=Math.min(10,left);right++)if(left%right===0)result.push(right);
    return result;
  }
  function path(sequence,max,random){
    for(let trial=0;trial<160;trial++){
      const start=integer(2,sequence[0]==='multiply'?Math.floor(max/2):max,random);let left=start;const solution=[];
      for(const operation of sequence){const candidates=rights(operation,left,max);if(!candidates.length)break;const right=choose(candidates,random),result=calculate(operation,left,right);solution.push({operation,left,right,result});left=result;}
      if(solution.length===sequence.length)return solution;
    }
    // A deterministic valid path keeps even a constant random source usable.
    const first=sequence[0],start=first==='divide'?8:first==='subtract'?6:2;let left=start;
    return sequence.map(operation=>{const right=2,result=calculate(operation,left,right),step={operation,left,right,result};left=result;return step;});
  }
  const single={
    add:[
      ({a,b,n})=>[`${n} has ${count(a,'sticker')}. A friend gives ${n} ${more(b,'sticker')}. How many stickers does ${n} have now?`,'stickers'],
      ({a,b})=>[`A fruit stand has ${count(a,'red apple')}. A farmer brings ${count(b,'green apple')}. How many apples does the fruit stand have altogether?`,'apples'],
      ({a,b})=>[`A library lends ${count(a,'book')} on Monday and ${count(b,'book')} on Tuesday. How many books does the library lend during the two days?`,'books'],
      ({a,b})=>[`A school sells ${count(a,'ticket')} for a fair in the morning and ${count(b,'ticket')} in the afternoon. How many tickets does the school sell that day?`,'tickets'],
      ({a,b})=>[`A library room has ${count(a,'book')}. A librarian brings in ${count(b,'returned book')}. How many books are in the room now?`,'books'],
      ({a,b,n})=>[`${n} collects ${count(a,'smooth stone')} near a path and ${count(b,'smooth stone')} near a pond. How many stones does ${n} collect altogether?`,'stones']
    ],
    subtract:[
      ({a,b,n})=>[`${n} has ${count(a,'marble')} and gives ${count(b,'marble')} to a friend. How many marbles does ${n} have left?`,'marbles'],
      ({a,b})=>[`A bakery makes ${count(a,'muffin')}. It sells ${count(b,'muffin')} before lunch. How many muffins are left?`,'muffins'],
      ({a,b})=>[`A theater has ${count(a,'seat')}. Visitors reserve ${count(b,'seat')}. How many seats have not been reserved?`,'seats'],
      ({a,b})=>[`The art table has ${count(a,'paintbrush','paintbrushes')}. Students take ${count(b,'paintbrush','paintbrushes')} to use. How many paintbrushes remain on the table?`,'paintbrushes'],
      ({a,b,n})=>[`${n} sets a goal to read ${count(a,'page')} during the school break. ${n} has already read ${count(b,'page')}. How many more pages does ${n} need to read to reach the goal?`,'pages'],
      ({a,b})=>[`A garden has ${count(a,'tulip')}. A gardener cuts ${count(b,'tulip')} for a vase. How many tulips are still growing in the garden?`,'tulips']
    ],
    multiply:[
      ({a,b})=>[`There are ${count(a,'bag')} with ${count(b,'marble')} in each bag. How many marbles are there altogether?`,'marbles'],
      ({a,b})=>[`A garden has ${count(a,'row')} with ${count(b,'carrot plant')} in each row. How many carrot plants are in the garden?`,'plants'],
      ({a,b})=>[`There are ${count(a,'table')}. Each table has ${count(b,'chair')}. How many chairs are there altogether?`,'chairs'],
      ({a,b})=>[`A teacher buys ${count(a,'pack')} of pencils. Each pack contains ${count(b,'pencil')}. How many pencils does the teacher buy?`,'pencils'],
      ({a,b})=>[`There are ${count(a,'team')}, and each team has ${count(b,'player')}. How many players are on the teams altogether?`,'players'],
      ({a,b})=>[`A baker fills ${count(a,'tray')} with ${count(b,'cookie')} on each tray. How many cookies are on the trays altogether?`,'cookies']
    ],
    divide:[
      ({a,b})=>[`A teacher shares ${count(a,'sticker')} equally among ${count(b,'student')}. How many stickers does each student get?`,'stickers'],
      ({a,b})=>[`A gardener plants ${count(a,'seedling')} in ${count(b,'equal row')}. How many seedlings are in each row?`,'seedlings'],
      ({a,b})=>[`A librarian puts ${count(a,'book')} into boxes with ${count(b,'book')} in each box. How many boxes are needed?`,'boxes'],
      ({a,b})=>[`A coach divides ${count(a,'player')} into equal teams with ${count(b,'player')} on each team. How many teams are there?`,'teams'],
      ({a,b})=>[`A baker shares ${count(a,'muffin')} equally among ${count(b,'tray')}. How many muffins go on each tray?`,'muffins'],
      ({a,b,n})=>[`${n} has ${count(a,'bead')} and uses ${count(b,'bead')} for each bracelet. How many bracelets can ${n} make?`,'bracelets']
    ]
  };
  const double={
    'add-add':[
      ({a,b,c,n})=>[`${n} has ${count(a,'sticker')}. A friend gives ${n} ${count(b,'sticker')}, and a teacher gives ${n} ${count(c,'sticker')}. How many stickers does ${n} have now?`,'stickers'],
      ({a,b,c})=>[`The library receives ${count(a,'book')} on Monday, ${count(b,'book')} on Tuesday, and ${count(c,'book')} on Wednesday. How many books does it receive during the three days?`,'books'],
      ({a,b,c})=>[`A class collects ${count(a,'can')} before recess. It collects ${count(b,'can')} at recess and ${count(c,'can')} after lunch. How many cans does the class collect in all?`,'cans']
    ],
    'add-subtract':[
      ({a,b,c,n})=>[`${n} has ${count(a,'marble')}. ${n} gets ${more(b,'marble')}, then gives ${count(c,'marble')} to a friend. How many marbles does ${n} have left?`,'marbles'],
      ({a,b,c})=>[`A bakery has ${count(a,'roll')}. The baker makes ${more(b,'roll')}, then sells ${count(c,'roll')}. How many rolls are left?`,'rolls'],
      ({a,b,c})=>[`A school sets out ${count(a,'chair')} for a fair. Workers add ${count(b,'chair')}, then put away ${count(c,'chair')}. How many chairs are still set out?`,'chairs']
    ],
    'add-multiply':[
      ({a,b,c})=>[`The class has ${count(a,'pack')} of pencils. A family donates ${more(b,'pack')}. Every pack contains ${count(c,'pencil')}. How many pencils are in all of the packs?`,'pencils'],
      ({a,b,c})=>[`A store has ${count(a,'box','boxes')} of crayons and receives ${more(b,'box','boxes')}. Each box holds ${count(c,'crayon')}. How many crayons are in all of the boxes?`,'crayons'],
      ({a,b,c})=>[`There are ${count(a,'table')} in one room and ${count(b,'table')} in another room. Each table has ${count(c,'chair')}. How many chairs are at the tables altogether?`,'chairs']
    ],
    'add-divide':[
      ({a,b,c})=>[`A teacher has ${count(a,'sticker')} and gets ${more(b,'sticker')}. The teacher shares all of them equally among ${count(c,'student')}. How many stickers does each student get?`,'stickers'],
      ({a,b,c})=>[`A club collects ${count(a,'can')} on Saturday and ${count(b,'can')} on Sunday. It packs all of the cans equally into ${count(c,'box','boxes')}. How many cans go in each box?`,'cans'],
      ({a,b,c})=>[`A gardener has ${count(a,'seedling')} and buys ${more(b,'seedling')}. All of the seedlings are planted equally in ${count(c,'row')}. How many seedlings are in each row?`,'seedlings']
    ],
    'subtract-add':[
      ({a,b,c,n})=>[`${n} has ${count(a,'pencil')}. ${n} gives away ${count(b,'pencil')}, then receives ${more(c,'pencil')}. How many pencils does ${n} have now?`,'pencils'],
      ({a,b,c})=>[`A library display has ${count(a,'book')}. Students borrow ${count(b,'book')}, then a librarian adds ${count(c,'book')}. How many books are on the display now?`,'books'],
      ({a,b,c})=>[`A warehouse has ${count(a,'box','boxes')}. Workers ship ${count(b,'box','boxes')}, then receive ${more(c,'box','boxes')}. How many boxes are in the warehouse now?`,'boxes']
    ],
    'subtract-subtract':[
      ({a,b,c,n})=>[`${n} has ${count(a,'sticker')}. ${n} gives ${count(b,'sticker')} to one friend and ${count(c,'sticker')} to another friend. How many stickers does ${n} keep?`,'stickers'],
      ({a,b,c})=>[`A bakery has ${count(a,'muffin')}. It sells ${count(b,'muffin')} in the morning and ${count(c,'muffin')} after lunch. How many muffins are left?`,'muffins'],
      ({a,b,c})=>[`A gardener has ${count(a,'seed')}. The gardener plants ${count(b,'seed')} in one bed and ${count(c,'seed')} in another bed. How many seeds have not been planted?`,'seeds']
    ],
    'subtract-multiply':[
      ({a,b,c})=>[`A shop has ${count(a,'box','boxes')} of crayons. It sells ${count(b,'box','boxes')}. Each remaining box contains ${count(c,'crayon')}. How many crayons remain in the boxes?`,'crayons'],
      ({a,b,c})=>[`The school has ${count(a,'table')}. Workers put away ${count(b,'table')}. Each table still in use needs ${count(c,'chair')}. How many chairs are needed for those tables?`,'chairs'],
      ({a,b,c})=>[`A garden has ${count(a,'row')} planned. The gardener leaves ${count(b,'row')} empty and plants ${count(c,'flower')} in each remaining row. How many flowers are planted?`,'flowers']
    ],
    'subtract-divide':[
      ({a,b,c})=>[`A teacher has ${count(a,'marker')} and sets aside ${count(b,'marker')}. The remaining markers are shared equally among ${count(c,'table')}. How many markers go on each table?`,'markers'],
      ({a,b,c})=>[`A library has ${count(a,'book')} to display. It lends ${count(b,'book')}, then arranges the remaining books equally on ${count(c,'shelf','shelves')}. How many books go on each shelf?`,'books'],
      ({a,b,c})=>[`A baker has ${count(a,'cookie')}. After selling ${count(b,'cookie')}, the baker packs the remaining cookies equally into ${count(c,'bag')}. How many cookies go in each bag?`,'cookies']
    ],
    'multiply-add':[
      ({a,b,c})=>[`There are ${count(a,'bag')} with ${count(b,'marble')} in each bag. A jar also holds ${count(c,'loose marble')}. How many marbles are there altogether?`,'marbles'],
      ({a,b,c})=>[`A class has ${count(a,'pack')} with ${count(b,'pencil')} in each pack. A teacher brings ${count(c,'extra pencil')}. How many pencils does the class have in all?`,'pencils'],
      ({a,b,c})=>[`A gardener plants ${count(a,'row')} with ${count(b,'flower')} in each row. The gardener plants ${count(c,'extra flower')} by a gate. How many flowers are planted altogether?`,'flowers']
    ],
    'multiply-subtract':[
      ({a,b,c})=>[`A baker fills ${count(a,'tray')} with ${count(b,'cookie')} on each tray. Customers buy ${count(c,'cookie')}. How many cookies are left?`,'cookies'],
      ({a,b,c})=>[`A teacher opens ${count(a,'box','boxes')} with ${count(b,'crayon')} in each box. Students use up ${count(c,'crayon')}. How many crayons are left to use?`,'crayons'],
      ({a,b,c})=>[`A team collects ${count(a,'bag')} with ${count(b,'can')} in each bag. They remove ${count(c,'damaged can')}. How many cans remain for recycling?`,'cans']
    ],
    'multiply-multiply':[
      ({a,b,c})=>[`A library has ${count(a,'shelf','shelves')}. Each shelf holds ${count(b,'box','boxes')}. Each box contains ${count(c,'book')}. How many books are in all of the boxes?`,'books'],
      ({a,b,c})=>[`There are ${count(a,'team')}. Each team has ${count(b,'player')}. Each player brings ${count(c,'tennis ball')}. How many tennis balls do the players bring altogether?`,'balls'],
      ({a,b,c})=>[`A garden has ${count(a,'bed')}. Each bed has ${count(b,'row')}. Each row has ${count(c,'carrot plant')}. How many carrot plants are in the garden?`,'plants']
    ],
    'multiply-divide':[
      ({a,b,c})=>[`A teacher has ${count(a,'box','boxes')} with ${count(b,'marker')} in each box. All of the markers are shared equally among ${count(c,'table')}. How many markers go on each table?`,'markers'],
      ({a,b,c})=>[`A baker fills ${count(a,'tray')} with ${count(b,'roll')} on each tray. All of the rolls are packed equally into ${count(c,'bag')}. How many rolls go in each bag?`,'rolls'],
      ({a,b,c})=>[`A club has ${count(a,'pack')} with ${count(b,'sticker')} in each pack. All of the stickers are shared equally among ${count(c,'member')}. How many stickers does each member get?`,'stickers']
    ],
    'divide-add':[
      ({a,b,c})=>[`A teacher shares ${count(a,'sticker')} equally among ${count(b,'student')}. Each student then gets ${count(c,'extra sticker')}. How many stickers does each student have altogether?`,'stickers'],
      ({a,b,c})=>[`A gardener plants ${count(a,'seedling')} equally in ${count(b,'row')}. Then the gardener adds ${count(c,'seedling')} to each row. How many seedlings are in each row now?`,'seedlings'],
      ({a,b,c})=>[`A librarian divides ${count(a,'book')} equally among ${count(b,'shelf','shelves')}. Then a librarian adds ${count(c,'book')} to each shelf. How many books are on each shelf now?`,'books']
    ],
    'divide-subtract':[
      ({a,b,c})=>[`A teacher shares ${count(a,'counter')} equally among ${count(b,'student')}. Each student returns ${count(c,'counter')}. How many counters does each student keep?`,'counters'],
      ({a,b,c})=>[`A baker puts ${count(a,'muffin')} equally on ${count(b,'tray')}. Then customers buy ${count(c,'muffin')} from each tray. How many muffins remain on each tray?`,'muffins'],
      ({a,b,c})=>[`A gardener plants ${count(a,'flower')} equally in ${count(b,'row')}. Then a gardener picks ${count(c,'flower')} from each row. How many flowers remain in each row?`,'flowers']
    ],
    'divide-multiply':[
      ({a,b,c})=>[`A gardener plants ${count(a,'seedling')} equally in ${count(b,'row')}. Each seedling needs ${count(c,'cup')} of water. How many cups of water are needed for one whole row?`,'cups'],
      ({a,b,c})=>[`A school divides ${count(a,'student')} into ${count(b,'equal group')}. Each student needs ${count(c,'pencil')}. How many pencils are needed for one group?`,'pencils'],
      ({a,b,c})=>[`A club divides ${count(a,'plant')} equally among ${count(b,'table')}. Each plant needs ${count(c,'label')}. How many labels are needed for the plants on one table?`,'labels']
    ],
    'divide-divide':[
      ({a,b,c})=>[`A teacher divides ${count(a,'counter')} equally among ${count(b,'classroom')}. Each classroom then shares its counters equally among ${count(c,'group')}. How many counters does one group get?`,'counters'],
      ({a,b,c})=>[`A library divides ${count(a,'book')} equally among ${count(b,'classroom')}. Each classroom places its books equally on ${count(c,'shelf','shelves')}. How many books go on one shelf?`,'books'],
      ({a,b,c})=>[`A gardener divides ${count(a,'seed')} equally into ${count(b,'tray')}. Each tray has ${count(c,'equal section')}. The seeds in each tray are shared equally among its sections. How many seeds go in one section?`,'seeds']
    ]
  };
  function generate({steps=1,max=100,operations:allowed=['add','subtract'],sequence,random=Math.random,templateIndex}={}){
    steps=Number(steps);max=Number(max);if(![20,100,1000].includes(max))throw new Error('Choose a supported number range.');const valid=selected(allowed),choices=sequences(valid,steps);
    const selectedSequence=sequence?sequence.slice():choose(choices,random);if(selectedSequence.length!==steps||selectedSequence.some(op=>!valid.includes(op)))throw new Error('The problem must use only selected operations.');
    const solution=path(selectedSequence,max,random),a=solution[0].left,b=solution[0].right,c=solution[1]?.right,n=choose(names,random),key=selectedSequence.join('-');
    const templates=steps===1?single[key]:double[key],index=Number.isInteger(templateIndex)?((templateIndex%templates.length)+templates.length)%templates.length:integer(0,templates.length-1,random);
    const [question,unit]=templates[index]({a,b,c,n});
    return {question,answer:solution.at(-1).result,expected:solution.at(-1).result,steps,max,operations:selectedSequence,solution,unit,templateId:key+'-'+index,equation:solution.map(step=>step.left+' '+symbols[step.operation]+' '+step.right+' = '+step.result).join('; ')};
  }
  return Object.freeze({generate,sequences,operations,templateCounts:Object.freeze({oneStep:24,twoStep:48})});
});
