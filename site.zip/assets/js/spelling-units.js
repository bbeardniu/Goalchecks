(() => {
  'use strict';
  const bank=window.BeardSpellingBank,core=window.BeardSpellingCore;
  const $=id=>document.getElementById(id);
  if(!bank||!core){$('spellingApp').hidden=true;$('loadError').hidden=false;return;}
  const gradeSelect=$('gradeSelect'),unitSelect=$('unitSelect'),lessonSelect=$('lessonSelect');
  let test,activeStudentId=null,modal=null,modalReturnFocus=null,printMode=null,studentView=null;
  const cards=new Map();
  const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function node(tag,props={},text){const element=document.createElement(tag);Object.assign(element,props);if(text!==undefined)element.textContent=text;return element;}
  function gradeData(grade){return bank.grades[String(grade)]||bank.grades['2'];}
  function unitData(config=test){return gradeData(config.grade).units.find(unit=>unit.id===config.unitId)||gradeData(config.grade).units[0];}
  function lessonData(config=test){return unitData(config).lessons.find(lesson=>lesson.id===config.lessonId);}
  function selectionLabel(config=test){const lesson=lessonData(config);return 'Grade '+config.grade+' · '+unitData(config).title+' · '+(lesson?lesson.title:'All lessons');}
  function dateLabel(){return new Date(test.createdAt).toLocaleDateString(undefined,{year:'numeric',month:'long',day:'numeric'});}
  function selected(){return test.students.find(student=>student.id===activeStudentId)||null;}
  function status(message,error=false){$('rosterStatus').textContent=message;$('rosterStatus').className='status'+(error?' is-error':'');}
  function hasResults(){return test.students.some(student=>student.responses.some(response=>response.correct!==null||response.spelling!==''));}
  function updateUrl(){try{const url=new URL(window.location.href);url.searchParams.set('grade',test.grade);url.searchParams.set('unit',test.unitId);if(test.lessonId==='all')url.searchParams.delete('lesson');else url.searchParams.set('lesson',test.lessonId);window.history.replaceState(null,'',url.href);}catch{}}
  function populateSelectors(config){
    gradeSelect.value=String(config.grade);
    const units=gradeData(config.grade).units;
    unitSelect.replaceChildren(...units.map(unit=>node('option',{value:unit.id},unit.title)));
    unitSelect.value=units.some(unit=>unit.id===config.unitId)?config.unitId:units[0].id;
    const unit=units.find(item=>item.id===unitSelect.value);
    lessonSelect.replaceChildren(node('option',{value:'all'},'All lessons in this unit'),...unit.lessons.map(lesson=>node('option',{value:lesson.id},lesson.title+' · '+lesson.skill)));
    lessonSelect.value=unit.lessons.some(lesson=>lesson.id===config.lessonId)?config.lessonId:'all';
  }
  function renderList(){
    populateSelectors(test);
    const lesson=lessonData();
    $('listMeta').textContent=selectionLabel()+' · '+test.words.length+' words'+(lesson?' · '+lesson.skill:'');
    $('wordList').replaceChildren(...test.words.map(word=>node('li',{},word)));
    document.title='Grade '+test.grade+' '+unitData().title+' Spelling · Beard\'s Classroom';
    updateUrl();
  }
  function scoreText(student){const summary=core.summary(test,student.id);return summary.scored?summary.correct+'/'+summary.scored+' correct · '+summary.percentage+'%': 'No words scored';}
  function updateRosterScores(){
    $('rosterCount').textContent=test.students.length+' / 10';
    $('addStudentBtn').disabled=test.students.length>=10;
    for(const button of $('studentRoster').querySelectorAll('[data-student-id]')){
      const student=test.students.find(item=>item.id===button.dataset.studentId);if(!student)continue;
      button.querySelector('.student-tab-name').textContent=student.name;
      button.querySelector('.student-tab-score').textContent=scoreText(student);
      button.setAttribute('aria-pressed',String(student.id===activeStudentId));
      button.setAttribute('aria-label',student.name+', '+scoreText(student));
    }
  }
  function renderRoster(){
    $('studentRoster').replaceChildren(...test.students.map(student=>{
      const button=node('button',{type:'button',className:'student-tab'});button.dataset.studentId=student.id;
      button.append(node('span',{className:'student-tab-name'},student.name),node('span',{className:'student-tab-score'},scoreText(student)));
      button.addEventListener('click',()=>{activeStudentId=student.id;status('Entering results for '+student.name+'.');renderStudent();});return button;
    }));
    updateRosterScores();
  }
  function updateCard(index){
    const student=selected(),card=cards.get(index);if(!student||!card)return;
    const response=student.responses[index];card.element.className='word-card'+(response.correct===true?' is-correct':response.correct===false?' is-incorrect':'');
    if(document.activeElement!==card.input)card.input.value=response.spelling;
    card.correct.setAttribute('aria-pressed',String(response.correct===true));card.incorrect.setAttribute('aria-pressed',String(response.correct===false));
    card.clear.disabled=response.correct===null&&!response.spelling;
  }
  function refreshScores(){
    const student=selected();updateRosterScores();if(!student)return;
    const score=core.summary(test,student.id);
    $('gradingStats').textContent=(score.percentage===null?'No score yet':score.percentage+'% of scored words')+' · '+score.correct+' correct / '+score.scored+' scored · '+score.unscored+' unscored';
    $('studentReport').innerHTML=reportHtml(student.id);
  }
  function changeResponse(index,patch){const student=selected();if(!student)return;try{core.setResponse(test,student.id,index,patch);updateCard(index);refreshScores();}catch(error){status(error.message,true);}}
  function renderCards(){
    const student=selected();cards.clear();if(!student){$('wordCards').replaceChildren();return;}
    $('wordCards').replaceChildren(...test.words.map((word,index)=>{
      const card=node('article',{className:'word-card'}),heading=node('div',{className:'word-heading'});
      heading.append(node('span',{className:'word-number'},String(index+1)+'.'),node('strong',{className:'word-prompt'},word));
      const id='spelling-answer-'+index,label=node('label',{className:'spelling-label',htmlFor:id},'Student spelling (optional)');
      const input=node('input',{id,type:'text',className:'spelling-input',value:student.responses[index].spelling,maxLength:200,autocomplete:'off',spellcheck:false});
      input.setAttribute('autocorrect','off');input.setAttribute('autocapitalize','none');input.setAttribute('aria-label',student.name+' spelling for word '+(index+1)+', '+word);
      input.addEventListener('input',()=>changeResponse(index,{spelling:input.value,correct:null}));
      input.addEventListener('change',()=>changeResponse(index,{spelling:input.value}));
      input.addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.repeat){event.preventDefault();changeResponse(index,{spelling:input.value});cards.get(index+1)?.input.focus();}});
      const controls=node('div',{className:'mark-buttons'}),correct=node('button',{type:'button',className:'mark-button correct'},'Correct'),incorrect=node('button',{type:'button',className:'mark-button incorrect'},'Incorrect'),clear=node('button',{type:'button',className:'clear-score'},'Clear');
      correct.setAttribute('aria-label','Mark '+word+' correct for '+student.name);incorrect.setAttribute('aria-label','Mark '+word+' incorrect for '+student.name);clear.setAttribute('aria-label','Clear result for '+word+' for '+student.name);
      correct.addEventListener('click',()=>changeResponse(index,{correct:true}));incorrect.addEventListener('click',()=>changeResponse(index,{correct:false}));clear.addEventListener('click',()=>changeResponse(index,{spelling:'',correct:null}));
      card.addEventListener('contextmenu',event=>{if(event.target.closest('input,textarea'))return;event.preventDefault();const current=selected()?.responses[index];if(current)changeResponse(index,{correct:current.correct!==true});});
      controls.append(correct,incorrect,clear);card.append(heading,label,input,controls);cards.set(index,{element:card,input,correct,incorrect,clear});return card;
    }));
    test.words.forEach((_,index)=>updateCard(index));
  }
  function renderStudent(){
    const student=selected();$('emptyRoster').hidden=Boolean(student);$('gradingPanel').hidden=!student;$('studentReport').hidden=!student;
    $('studentViewBtn').disabled=!student;
    if(student){$('currentStudentName').textContent=student.name;renderCards();refreshScores();}else{$('wordCards').replaceChildren();$('studentReport').replaceChildren();}
    updateRosterScores();
  }
  function renderAll(){renderList();renderRoster();renderStudent();}
  function reportHtml(studentId){
    const student=test.students.find(item=>item.id===studentId),score=core.summary(test,studentId);
    const percent=score.percentage===null?'—':score.percentage+'%';
    const rows=score.responses.map(row=>{
      const outcome=row.correct===true?'correct':row.correct===false?'incorrect':'unscored';
      const response=row.spelling?'Student: '+row.spelling:row.correct===true?'Marked correct':row.correct===false?'Marked incorrect':'Not scored';
      return '<article class="report-word is-'+outcome+'"><span class="report-word-index">'+(row.index+1)+'.</span><div class="report-word-body"><strong>'+escape(row.word)+'</strong><span class="student-spelling">'+escape(response)+'</span></div></article>';
    }).join('');
    return '<article class="report-sheet"><div class="report-heading"><div><p class="report-title">Beard\'s Classroom · Spelling results</p><h2>'+escape(student.name)+'</h2><p class="report-details">'+escape(selectionLabel())+'</p></div><div class="report-score"><strong>'+percent+'</strong><span>of scored words</span></div></div><div class="report-meta"><span><strong>'+escape(dateLabel())+'</strong></span><span><strong>'+score.correct+' / '+score.scored+'</strong> correct</span><span><strong>'+score.scored+' / '+score.total+'</strong> words scored</span><span><strong>'+score.unscored+'</strong> unscored</span></div><p class="report-note">'+(score.unscored?'In progress: unscored words are not included in the percentage.':'All words have been scored.')+' Same word order for every student · Test '+escape(test.id)+'.</p><div class="report-grid">'+rows+'</div></article>';
  }
  function newTest(config){
    if(hasResults()&&!window.confirm('Changing the word list starts a new test and clears the recorded results. Export your save code first if you want to keep them. Continue?')){populateSelectors(test);return false;}
    const names=test.students.map(student=>student.name),selectedName=selected()?.name;
    try{const next=core.createTest(bank,{...config,names});test=next;studentView?.reset();activeStudentId=test.students.find(student=>student.name===selectedName)?.id||test.students[0]?.id||null;renderAll();status('New test ready. Every student has the same '+test.words.length+' words in the same order.');return true;}catch(error){populateSelectors(test);status(error.message,true);return false;}
  }
  gradeSelect.addEventListener('change',()=>newTest({grade:gradeSelect.value,unitId:gradeData(gradeSelect.value).units[0].id,lessonId:'all'}));
  unitSelect.addEventListener('change',()=>newTest({grade:test.grade,unitId:unitSelect.value,lessonId:'all'}));
  lessonSelect.addEventListener('change',()=>newTest({grade:test.grade,unitId:test.unitId,lessonId:lessonSelect.value}));
  $('reshuffleBtn').addEventListener('click',()=>newTest({grade:test.grade,unitId:test.unitId,lessonId:test.lessonId}));
  $('studentForm').addEventListener('submit',event=>{
    event.preventDefault();try{const student=core.addStudent(test,$('studentName').value);activeStudentId=student.id;$('studentName').value='';renderRoster();renderStudent();status('Added '+student.name+'. The word list has not changed.');if(test.students.length<10)$('studentName').focus();}catch(error){status(error.message,true);$('studentName').focus();}
  });
  $('removeStudentBtn').addEventListener('click',()=>{
    const student=selected();if(!student||!window.confirm('Remove '+student.name+' and their results from this test?'))return;
    core.removeStudent(test,student.id);activeStudentId=test.students[0]?.id||null;renderRoster();renderStudent();status(student.name+' was removed. Other results and word order are unchanged.');
  });
  function closeModal(){if(modal){modal.remove();modal=null;}modalReturnFocus?.focus();modalReturnFocus=null;}
  function openModal(title){
    closeModal();modalReturnFocus=document.activeElement;
    modal=node('section',{className:'save-modal'});modal.setAttribute('role','dialog');modal.setAttribute('aria-modal','true');modal.setAttribute('aria-label',title);
    const card=node('div',{className:'save-card'});card.append(node('h2',{},title));modal.append(card);$('modalHost').append(modal);
    modal.addEventListener('click',event=>{if(event.target===modal)closeModal();});
    modal.addEventListener('keydown',event=>{
      if(event.key==='Escape'){event.preventDefault();closeModal();return;}
      if(event.key!=='Tab')return;const focusable=[...modal.querySelectorAll('button,input,textarea,select,a[href]')].filter(item=>!item.disabled&&!item.hidden);if(!focusable.length)return;
      if(event.shiftKey&&document.activeElement===focusable[0]){event.preventDefault();focusable[focusable.length-1].focus();}else if(!event.shiftKey&&document.activeElement===focusable[focusable.length-1]){event.preventDefault();focusable[0].focus();}
    });
    return card;
  }
  $('renameStudentBtn').addEventListener('click',()=>{
    const student=selected();if(!student)return;const card=openModal('Rename student'),form=node('form'),label=node('label',{htmlFor:'renameInput'},'Student name'),input=node('input',{id:'renameInput',type:'text',className:'name-input',value:student.name,maxLength:80}),error=node('p',{className:'modal-status'}),actions=node('div',{className:'toolbar'}),save=node('button',{type:'submit'},'Save name'),cancel=node('button',{type:'button',className:'quiet'},'Cancel');
    error.setAttribute('role','alert');actions.append(save,cancel);form.append(label,input,error,actions);card.append(form);cancel.addEventListener('click',closeModal);
    form.addEventListener('submit',event=>{event.preventDefault();try{core.renameStudent(test,student.id,input.value);closeModal();renderRoster();renderStudent();status('Student name updated. Scores and word order are unchanged.');}catch(problem){error.textContent=problem.message;}});input.focus();input.select();
  });
  function downloadCode(code){
    const blob=new Blob([code+'\n'],{type:'text/plain'}),url=URL.createObjectURL(blob),link=node('a',{href:url,download:'Beard-Spelling-Grade-'+test.grade+'-'+test.unitId+'-'+test.createdAt.slice(0,10)+'.txt'});
    document.body.append(link);link.click();link.remove();window.setTimeout(()=>URL.revokeObjectURL(url),2000);
  }
  $('exportBtn').addEventListener('click',()=>{
    const code=core.encode(test),card=openModal('Keep this spelling test');card.append(node('p',{className:'small'},'This code includes the exact word order, all student names, and every result. Copy it or download it as a text file, then import it to continue later. Keep student records in your usual private student folder.'));
    const label=node('label',{htmlFor:'exportCode'},'Save code'),area=node('textarea',{id:'exportCode',readOnly:true,value:code}),message=node('p',{className:'modal-status'}),actions=node('div',{className:'toolbar'}),copy=node('button',{type:'button'},'Copy code'),download=node('button',{type:'button',className:'quiet'},'Download .txt'),close=node('button',{type:'button',className:'quiet'},'Close');
    message.setAttribute('role','status');actions.append(copy,download,close);card.append(label,area,message,actions);
    copy.addEventListener('click',async()=>{area.focus();area.select();try{await navigator.clipboard.writeText(code);message.textContent='Copied. Paste the code into a text file to keep it.';}catch{let copied=false;try{copied=document.execCommand('copy');}catch{}message.textContent=copied?'Copied.':'The code is selected. Press Ctrl+C or use your device’s Copy command.';}});
    download.addEventListener('click',()=>{downloadCode(code);message.textContent='Your text-file download has started.';});close.addEventListener('click',closeModal);area.focus();area.select();
  });
  $('importBtn').addEventListener('click',()=>{
    const card=openModal('Restore a spelling test');card.append(node('p',{className:'small'},'Paste an exported spelling save code or choose its text file. Import restores the original word order and every student’s results.'));
    const label=node('label',{htmlFor:'importCode'},'Save code'),area=node('textarea',{id:'importCode',placeholder:'BEARDSPELLING1:…'}),file=node('input',{type:'file',accept:'.txt,text/plain'}),error=node('p',{className:'modal-status'}),actions=node('div',{className:'toolbar'}),restore=node('button',{type:'button'},'Import test'),cancel=node('button',{type:'button',className:'quiet'},'Cancel');
    file.setAttribute('aria-label','Choose a saved spelling text file');error.setAttribute('role','alert');actions.append(restore,cancel);card.append(label,area,file,error,actions);
    file.addEventListener('change',()=>{const chosen=file.files?.[0];if(!chosen)return;if(chosen.size>2*1024*1024){error.textContent='This file is too large to be a spelling save code.';return;}const reader=new FileReader();reader.onload=()=>{area.value=String(reader.result||'');error.textContent='';};reader.onerror=()=>{error.textContent='The file could not be read. Try pasting the save code instead.';};reader.readAsText(chosen);});
    restore.addEventListener('click',()=>{try{const restored=core.decode(bank,area.value);if(hasResults()&&!window.confirm('Import replaces the current test and its recorded results. Continue?'))return;test=restored;studentView?.reset();activeStudentId=test.students[0]?.id||null;closeModal();renderAll();status('Restored '+test.students.length+' student'+(test.students.length===1?'':'s')+' and the original '+test.words.length+'-word order.');}catch(problem){error.textContent=problem.message||'This code could not be restored.';area.focus();}});
    cancel.addEventListener('click',closeModal);area.focus();
  });
  $('showReportBtn').addEventListener('click',()=>{$('studentReport').scrollIntoView({behavior:window.matchMedia?.('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});$('studentReport').focus({preventScroll:true});});
  function preparePrint(){if(studentView?.isOpen){$('printArea').replaceChildren();return;}const students=printMode==='all'?test.students:selected()?[selected()]:[];$('printArea').innerHTML=students.map(student=>reportHtml(student.id)).join('');}
  function printReports(all){if(!test.students.length)return;printMode=all?'all':'selected';preparePrint();window.print();}
  $('printStudentBtn').addEventListener('click',()=>printReports(false));$('printAllBtn').addEventListener('click',()=>printReports(true));
  window.addEventListener('beforeprint',preparePrint);window.addEventListener('afterprint',()=>{printMode=null;});
  try{
    const params=new URLSearchParams(window.location.search),grade=params.get('grade')==='3'?'3':'2',units=gradeData(grade).units,unitId=units.some(unit=>unit.id===params.get('unit'))?params.get('unit'):units[0].id,unit=units.find(item=>item.id===unitId),lessonId=unit.lessons.some(lesson=>lesson.id===params.get('lesson'))?params.get('lesson'):'all';
    test=core.createTest(bank,{grade,unitId,lessonId});renderAll();
    if(window.BeardSpellingStudent){
      studentView=window.BeardSpellingStudent.mount({host:$('studentViewHost'),teacherRoot:$('spellingApp'),getTest:()=>test,getStudent:selected,getLabel:()=>selectionLabel(),setResponse:(index,patch)=>{const student=selected();if(!student)throw new Error('Choose a student first.');core.setResponse(test,student.id,index,patch);updateCard(index);refreshScores();},onClose:()=>{renderStudent();status('Student view closed. The word order and recorded results are unchanged.');$('studentViewBtn').focus();}});
    }
    $('studentViewBtn').addEventListener('click',()=>{if(!selected())return;if(!studentView){status('Student view could not load. Refresh the page and try again.',true);return;}studentView.open();});
  }catch(error){$('spellingApp').hidden=true;$('loadError').hidden=false;console.error('Spelling initialization failed:',error);}
})();
