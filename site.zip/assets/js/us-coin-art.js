(() => {
  'use strict';
  // Original colored-pencil teaching illustrations of familiar U.S. coin reverses.
  // Deterministic hatching adds texture without changing the assessment random stream.
  // Relative diameters: https://www.usmint.gov/learn/coins-and-medals/circulating-coins/coin-specifications
  const specs=Object.freeze({
    penny:Object.freeze({name:'Penny',plural:'pennies',value:1,diameter:19.05}),
    nickel:Object.freeze({name:'Nickel',plural:'nickels',value:5,diameter:21.21}),
    dime:Object.freeze({name:'Dime',plural:'dimes',value:10,diameter:17.91}),
    quarter:Object.freeze({name:'Quarter',plural:'quarters',value:25,diameter:24.26})
  });
  const memorial='<path d="M30 54H90L85 49H35Z M28 79H92V83H28Z M32 75H88V79H32Z"/><path d="M33 55H87V74H33Z" fill="none" stroke-width="2"/><path d="M37 56V73M43 56V73M49 56V73M55 56V73M61 56V73M67 56V73M73 56V73M79 56V73M85 56V73" stroke-width="2.5"/><path d="M30 46H90V50H30Z"/><path d="M26 84H94M23 87H97" fill="none" stroke-width="2"/>';
  const monticello='<path d="M25 74H95V79H25Z M35 57H85V74H35Z" fill="none" stroke-width="2"/><path d="M47 47Q60 32 73 47Z M45 49H75V54H45Z M31 56L60 44L89 56Z"/><path d="M43 59V74M51 59V74M59 59V74M67 59V74M75 59V74" stroke-width="3"/><path d="M23 79H97M20 83H100M16 87H104" fill="none" stroke-width="2"/><path d="M25 65H31V72H25ZM89 65H95V72H89Z"/>';
  const torch='<path d="M56 58H64L63 82H57Z M53 52H67V58H53Z"/><path d="M55 49C45 38 55 34 56 28C64 34 60 37 66 39C70 45 65 49 62 50Z"/><path d="M39 83Q30 65 34 45M81 83Q90 65 86 45" fill="none" stroke-width="2.5"/><path d="M34 54Q21 48 26 41Q38 44 34 54ZM33 64Q20 62 22 54Q35 55 33 64ZM36 74Q23 75 23 67Q35 64 36 74ZM86 54Q99 48 94 41Q82 44 86 54ZM87 64Q100 62 98 54Q85 55 87 64ZM84 74Q97 75 97 67Q85 64 84 74Z"/><path d="M35 82L47 88M85 82L73 88" fill="none" stroke-width="2"/>';
  const eagle='<path d="M56 50L49 44L28 36L18 41L36 57L26 53L20 56L44 71L53 66L50 79L59 89L68 79L65 66L75 71L99 56L93 53L84 57L102 41L92 36L71 44L64 50Z"/><path d="M56 50L55 43L59 38L65 39L65 43L72 45L65 48L64 54Z"/><path d="M51 57H69V70L60 78L51 70Z" fill="#e7e9e5" stroke-width="1.5"/><path d="M54 61V70M58 61V73M62 61V73M66 61V70M52 59H68" fill="none" stroke-width="1.1"/><path d="M28 42L46 56M24 45L43 60M33 51L45 63M92 42L74 56M96 45L77 60M87 51L75 63" fill="none" stroke="#eef0ec" stroke-width="1.4"/><path d="M49 78L36 87M71 78L84 87M33 82L41 84M80 83L86 80M80 86L87 85" fill="none" stroke-width="2"/>';
  function draw(kind,serial=0){
    const coin=specs[kind];if(!coin)throw new Error('Unknown U.S. coin');
    const id='coin-'+kind+'-'+String(serial).replace(/[^a-zA-Z0-9_-]/g,''),copper=kind==='penny';
    const light=copper?'#f4d8b8':'#f7f4e9',middle=copper?'#d7a078':kind==='nickel'?'#d3d4c7':'#d7ddd9',dark=copper?'#ac6f4b':'#98a8a7',ink=copper?'#704b38':'#566969';
    const denomination={penny:'ONE CENT',nickel:'FIVE CENTS',dime:'ONE DIME',quarter:'QUARTER DOLLAR'}[kind];
    const design={penny:memorial,nickel:monticello,dime:torch,quarter:eagle}[kind];
    const reeded=kind==='dime'||kind==='quarter';
    const inkGrain='<pattern id="'+id+'-ink" width="4" height="4" patternUnits="userSpaceOnUse"><rect width="4" height="4" fill="'+ink+'"/><path d="M0 3L3 0M2 5L5 2" stroke="'+middle+'" stroke-width=".45" opacity=".52"/></pattern>';
    const hatch='<pattern id="'+id+'-pencil" width="9" height="9" patternUnits="userSpaceOnUse"><rect width="9" height="9" fill="'+middle+'"/><path d="M-3 4L4-3M-1 9L9-1M4 12L12 4M1 3L6 0M3 9L9 3" fill="none" stroke="'+ink+'" stroke-width=".45" opacity=".22"/><path d="M0 7L7 0M4 9L9 4M0 2L2 0" fill="none" stroke="'+light+'" stroke-width=".9" opacity=".72"/><path d="M0 5L4 9M5 0L9 4" fill="none" stroke="'+dark+'" stroke-width=".3" opacity=".16"/></pattern>';
    return '<svg xmlns="http://www.w3.org/2000/svg" class="coin coin-'+kind+'" data-coin="'+kind+'" data-art-style="colored-pencil" style="--coin-ratio:'+(coin.diameter/24.26).toFixed(5)+'" viewBox="0 0 120 120" role="img" aria-label="'+coin.name+', reverse side"><title>'+coin.name+'</title><defs>'+hatch+inkGrain+'<clipPath id="'+id+'-face"><circle cx="60" cy="59" r="55"/></clipPath></defs><ellipse cx="61" cy="115" rx="43" ry="2.2" fill="#705b42" opacity=".09"/><circle cx="60" cy="59" r="55" fill="url(#'+id+'-pencil)" stroke="'+ink+'" stroke-width="1.55"/><g fill="none" stroke-linecap="round"><circle cx="60.3" cy="59.1" r="54" stroke="'+ink+'" stroke-width=".5" opacity=".55"/><circle cx="59.7" cy="58.8" r="52.5" stroke="'+light+'" stroke-width="1.5"/><circle cx="60" cy="59" r="50.5" stroke="'+ink+'" stroke-width="'+(reeded?'1.7':'.65')+'"'+(reeded?' stroke-dasharray=".5 2.1"':'')+' opacity=".7"/><circle cx="60" cy="59" r="48.2" stroke="'+light+'" stroke-width=".9"/></g><g clip-path="url(#'+id+'-face)" fill="none" stroke="'+light+'" stroke-width="1" opacity=".45"><path d="M8 30Q34 0 82 8M5 38Q28 9 55 7M8 86Q35 121 87 107"/></g><g fill="url(#'+id+'-ink)" stroke="'+ink+'" stroke-linecap="round" stroke-linejoin="round" opacity=".88">'+design+'</g><text x="60" y="26" textLength="74" lengthAdjust="spacingAndGlyphs" text-anchor="middle" fill="'+ink+'" font-family="Georgia,serif" font-weight="700" font-size="4.4" letter-spacing=".1">UNITED STATES OF AMERICA</text><text x="60" y="100" textLength="'+({penny:48,nickel:58,dime:48,quarter:64}[kind])+'" lengthAdjust="spacingAndGlyphs" text-anchor="middle" fill="'+ink+'" font-family="Georgia,serif" font-weight="700" font-size="6.3" letter-spacing=".35">'+denomination+'</text></svg>';
  }
  window.BeardCoinArt=Object.freeze({specs,draw});
})();
