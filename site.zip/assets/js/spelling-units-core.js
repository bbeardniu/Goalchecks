(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.BeardSpellingCore = api;
})(typeof window !== 'undefined' ? window : typeof globalThis !== 'undefined' ? globalThis : null, function () {
  'use strict';

  const PREFIX = 'BEARDSPELLING1:';
  const MAX_STUDENTS = 10;
  const MAX_NAME_LENGTH = 80;
  const MAX_SPELLING_LENGTH = 200;
  const MAX_WORDS = 1000;
  const MAX_CODE_LENGTH = 2000000;
  let formSequence = 0;

  function fail(message) { throw new Error(message); }
  function own(object, key) { return Object.prototype.hasOwnProperty.call(object, key); }
  function object(value) { return value !== null && typeof value === 'object' && !Array.isArray(value); }
  function normalizeWord(value) {
    return String(value ?? '').normalize('NFC').replace(/[\u2018\u2019\u02bc\uff07]/g, "'").trim().toLocaleLowerCase('en-US');
  }
  function cleanName(value) {
    if (typeof value !== 'string') fail('Enter a student name.');
    const name = value.normalize('NFC').trim().replace(/\s+/g, ' ');
    if (!name) fail('Enter a student name.');
    if (Array.from(name).length > MAX_NAME_LENGTH) fail('Student names must be 80 characters or fewer.');
    if (/[\u0000-\u001f\u007f]/.test(name)) fail('Student names cannot contain control characters.');
    return name;
  }
  function nameKey(name) { return cleanName(name).toLocaleLowerCase('en-US'); }
  function identifier(value) { return typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9._:-]{0,119}$/.test(value); }
  function scope(bank, options) {
    if (!object(bank) || !object(bank.grades)) fail('The spelling word lists are unavailable.');
    const grade = String(options?.grade ?? '');
    if (!own(bank.grades, grade)) fail('Choose a valid grade.');
    const group = bank.grades[grade];
    if (!object(group) || !Array.isArray(group.units)) fail('The spelling word lists are unavailable.');
    const unit = group.units.find(item => item && item.id === options?.unitId);
    if (!unit || !Array.isArray(unit.lessons)) fail('Choose a valid spelling unit.');
    const lessonId = options?.lessonId ?? 'all';
    const lessons = lessonId === 'all' ? unit.lessons : unit.lessons.filter(item => item && item.id === lessonId);
    if (!lessons.length) fail('Choose a lesson from the selected spelling unit.');
    return {grade, unit, lessonId, lessons};
  }
  function getList(bank, options) {
    const chosen = scope(bank, options), seen = new Set(), words = [];
    chosen.lessons.forEach(lesson => {
      if (!Array.isArray(lesson.words)) fail('This spelling lesson has no word list.');
      lesson.words.forEach(value => {
        if (typeof value !== 'string' || !normalizeWord(value)) fail('The spelling list contains an invalid word.');
        const word = value.trim(), key = normalizeWord(word);
        if (!seen.has(key)) { seen.add(key); words.push(word); }
      });
    });
    if (!words.length || words.length > MAX_WORDS) fail('This spelling list cannot be used for a test.');
    return words;
  }
  function findStudent(test, studentId) {
    if (!object(test) || !Array.isArray(test.students)) fail('Open a spelling test first.');
    const student = test.students.find(item => item.id === studentId);
    if (!student) fail('Choose a student in this test.');
    return student;
  }
  function addStudent(test, rawName) {
    if (!object(test) || !Array.isArray(test.students) || !Array.isArray(test.words)) fail('Open a spelling test first.');
    if (test.students.length >= MAX_STUDENTS) fail('A spelling test can include up to 10 students.');
    const name = cleanName(rawName), key = nameKey(name);
    if (test.students.some(student => nameKey(student.name) === key)) fail('That student name is already in this test.');
    let number = 1;
    while (test.students.some(student => student.id === 'student-' + number)) number++;
    const student = {id:'student-' + number, name, responses:test.words.map(() => ({spelling:'', correct:null}))};
    test.students.push(student);
    return student;
  }
  function renameStudent(test, studentId, rawName) {
    const student = findStudent(test, studentId), name = cleanName(rawName), key = nameKey(name);
    if (test.students.some(item => item.id !== studentId && nameKey(item.name) === key)) fail('That student name is already in this test.');
    student.name = name;
    return student;
  }
  function removeStudent(test, studentId) {
    const student = findStudent(test, studentId);
    test.students.splice(test.students.indexOf(student), 1);
    return student;
  }
  function createTest(bank, options = {}) {
    const chosen = scope(bank, options), words = getList(bank, {grade:chosen.grade, unitId:chosen.unit.id, lessonId:chosen.lessonId}), random = options.random ?? Math.random;
    if (typeof random !== 'function') fail('A valid shuffle function is required.');
    for (let index = words.length - 1; index > 0; index--) {
      const value = random();
      if (!Number.isFinite(value) || value < 0 || value >= 1) fail('The shuffle function returned an invalid number.');
      const other = Math.floor(value * (index + 1));
      [words[index], words[other]] = [words[other], words[index]];
    }
    const suppliedNow = options.now === undefined ? Date.now() : typeof options.now === 'function' ? options.now() : options.now;
    const moment = new Date(suppliedNow);
    if (!Number.isFinite(moment.getTime())) fail('The test date is invalid.');
    const test = {version:1, id:'spelling-' + Math.floor(moment.getTime()).toString(36) + '-' + (++formSequence).toString(36), createdAt:moment.toISOString(), grade:chosen.grade, unitId:chosen.unit.id, lessonId:chosen.lessonId, words, students:[]};
    const names = options.names ?? [];
    if (!Array.isArray(names)) fail('Student names must be a list.');
    names.forEach(name => addStudent(test, name));
    return test;
  }
  function setResponse(test, studentId, index, patch) {
    const student = findStudent(test, studentId);
    if (!Number.isInteger(index) || index < 0 || index >= test.words.length) fail('Choose a word in this spelling test.');
    if (!object(patch)) fail('The spelling result is invalid.');
    const previous = student.responses[index];
    let spelling = previous.spelling, correct = previous.correct;
    if (own(patch, 'spelling')) {
      if (typeof patch.spelling !== 'string' || Array.from(patch.spelling).length > MAX_SPELLING_LENGTH) fail('A student spelling must be 200 characters or fewer.');
      spelling = patch.spelling;
      correct = spelling.trim() ? normalizeWord(spelling) === normalizeWord(test.words[index]) : null;
    }
    if (own(patch, 'correct')) {
      if (patch.correct !== true && patch.correct !== false && patch.correct !== null) fail('Mark the word correct, incorrect, or unscored.');
      correct = patch.correct;
    }
    const response = {spelling, correct};
    student.responses[index] = response;
    return response;
  }
  function summary(test, studentId) {
    const student = findStudent(test, studentId);
    let correct = 0, incorrect = 0;
    const responses = test.words.map((word, index) => {
      const response = student.responses[index];
      if (response.correct === true) correct++;
      if (response.correct === false) incorrect++;
      return {word, spelling:response.spelling, correct:response.correct, index};
    });
    const scored = correct + incorrect, total = test.words.length;
    return {correct, incorrect, scored, total, unscored:total - scored, percentage:scored ? Math.round(correct / scored * 100) : null, responses};
  }
  function checksum(value) {
    let hash = 2166136261;
    for (let index = 0; index < value.length; index++) hash = Math.imul(hash ^ value.charCodeAt(index), 16777619);
    return (hash >>> 0).toString(36);
  }
  function toBase64(value) {
    if (typeof Buffer !== 'undefined') return Buffer.from(value, 'utf8').toString('base64');
    let binary = '';
    new TextEncoder().encode(value).forEach(byte => { binary += String.fromCharCode(byte); });
    return btoa(binary);
  }
  function fromBase64(value) {
    if (!/^[A-Za-z0-9+/]*={0,2}$/.test(value) || value.length % 4 !== 0) fail('The spelling save code is incomplete or invalid.');
    if (typeof Buffer !== 'undefined') return Buffer.from(value, 'base64').toString('utf8');
    return new TextDecoder('utf-8', {fatal:true}).decode(Uint8Array.from(atob(value), character => character.charCodeAt(0)));
  }
  function cleanTest(raw, bank) {
    if (!object(raw) || raw.version !== 1) fail('This spelling save code uses an unsupported version.');
    if (!identifier(raw.id)) fail('The spelling test identifier is invalid.');
    if (typeof raw.createdAt !== 'string' || !Number.isFinite(Date.parse(raw.createdAt)) || new Date(raw.createdAt).toISOString() !== raw.createdAt) fail('The spelling test date is invalid.');
    if (typeof raw.grade !== 'string' || !identifier(raw.unitId) || !identifier(raw.lessonId)) fail('The spelling test selection is invalid.');
    if (!Array.isArray(raw.words) || !raw.words.length || raw.words.length > MAX_WORDS || raw.words.some(word => typeof word !== 'string' || !word.trim() || Array.from(word).length > MAX_SPELLING_LENGTH)) fail('The spelling save code contains an invalid word list.');
    const keys = raw.words.map(normalizeWord);
    if (new Set(keys).size !== keys.length) fail('The spelling save code repeats a word.');
    if (bank) {
      const expected = getList(bank, raw);
      if (expected.length !== raw.words.length || expected.some(word => !raw.words.includes(word))) fail('The saved word list does not match this grade, unit, and lesson.');
    }
    if (!Array.isArray(raw.students) || raw.students.length > MAX_STUDENTS) fail('A spelling test can include up to 10 students.');
    const ids = new Set(), names = new Set();
    const students = raw.students.map(item => {
      if (!object(item) || !identifier(item.id) || ids.has(item.id)) fail('The save code contains an invalid or duplicate student identifier.');
      const name = cleanName(item.name), key = nameKey(name);
      if (names.has(key)) fail('The save code contains duplicate student names.');
      ids.add(item.id); names.add(key);
      if (!Array.isArray(item.responses) || item.responses.length !== raw.words.length) fail('A saved student has the wrong number of word results.');
      const responses = item.responses.map(response => {
        if (!object(response) || typeof response.spelling !== 'string' || Array.from(response.spelling).length > MAX_SPELLING_LENGTH || (response.correct !== true && response.correct !== false && response.correct !== null)) fail('The save code contains an invalid spelling result.');
        return {spelling:response.spelling, correct:response.correct};
      });
      return {id:item.id, name, responses};
    });
    return {version:1, id:raw.id, createdAt:raw.createdAt, grade:raw.grade, unitId:raw.unitId, lessonId:raw.lessonId, words:raw.words.slice(), students};
  }
  function encode(test) {
    const payload = toBase64(JSON.stringify(cleanTest(test)));
    const code = PREFIX + payload + '.' + checksum(payload);
    if (code.length > MAX_CODE_LENGTH) fail('This spelling test is too large to export.');
    return code;
  }
  function decode(bank, code) {
    if (typeof code !== 'string' || code.length > MAX_CODE_LENGTH) fail('The spelling save code is invalid or too large.');
    const value = code.replace(/\s+/g, '');
    if (!value.startsWith(PREFIX)) fail('Paste a Beard spelling save code beginning with BEARDSPELLING1:.');
    const body = value.slice(PREFIX.length), separator = body.lastIndexOf('.');
    if (separator < 1) fail('The spelling save code looks cut off. Copy the complete code.');
    const payload = body.slice(0, separator);
    if (checksum(payload) !== body.slice(separator + 1)) fail('The spelling save code is incomplete or has changed. Copy the complete code.');
    let raw;
    try { raw = JSON.parse(fromBase64(payload)); }
    catch (error) { fail('The spelling save code could not be read.'); }
    return cleanTest(raw, bank);
  }

  return Object.freeze({PREFIX, MAX_STUDENTS, MAX_NAME_LENGTH, MAX_SPELLING_LENGTH, normalizeWord, getList, createTest, addStudent, renameStudent, removeStudent, setResponse, summary, encode, decode});
});
