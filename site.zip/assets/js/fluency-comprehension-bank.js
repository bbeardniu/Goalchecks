/* Questions use the existing classroom passages; evidence is retained for teacher review. */
window.BeardFluencyComprehension = Object.freeze({
  "stories": [
    {
      "id": "grade-2-a-good-day",
      "grade": 2,
      "title": "A Good Day",
      "path": "HTMLs/Reading Fluency/2nd Grade Fluency/A Good Day.html",
      "text": "I was working at my desk when my teacher \nwalked up to me. Was he going to warn me to \nstudy harder? No, he was smiling.\n“Amy, I have great news,” he said. “Your \ndrawing of the lizard won first prize in our \ncontest. We would like to hang it at school for the \nMarch Art Fair.”\nAs he passed me two copies of the award \ncertificate, my friends clapped loudly. I gripped \nthe copies in shaky hands. I could not believe \nI won first prize!\nThe bell rang, and I tossed my books into my \nempty bag. I could hardly wait to tell my family \nthe happy news. I ran home quickly! As soon as I \nopened the door, I shouted to my mother, “I got \nfirst prize! My drawing will be hanging in a fancy \nframe.”\nMy mother smiled. “Ever since you were a \nbaby, you’ve always loved to draw. I am very \nproud of you!”\nShe reminded me that all my hours of practice \nhad been worthwhile. It was a good day.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who came to Amy with good news?",
          "answer": "Her teacher.",
          "evidence": "I was working at my desk when my teacher walked up to me."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who told Amy that she had loved drawing since she was a baby?",
          "answer": "Her mother.",
          "evidence": "My mother smiled. “Ever since you were a baby, you’ve always loved to draw."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What animal had Amy drawn?",
          "answer": "A lizard.",
          "evidence": "Your drawing of the lizard won first prize in our contest."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What did the teacher hand Amy?",
          "answer": "Two copies of the award certificate.",
          "evidence": "As he passed me two copies of the award certificate, my friends clapped loudly."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When would Amy’s drawing be shown at the art fair?",
          "answer": "In March.",
          "evidence": "We would like to hang it at school for the March Art Fair."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did Amy pack her books and head home?",
          "answer": "After the bell rang.",
          "evidence": "The bell rang, and I tossed my books into my empty bag."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where was Amy working when her teacher walked up?",
          "answer": "At her desk.",
          "evidence": "I was working at my desk when my teacher walked up to me."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where would Amy’s winning drawing be hung?",
          "answer": "At school for the art fair.",
          "evidence": "We would like to hang it at school for the March Art Fair."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why did Amy’s friends clap?",
          "answer": "Amy had won first prize for her drawing.",
          "evidence": "Your drawing of the lizard won first prize in our contest. We would like to hang it at school"
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why did Amy hurry home?",
          "answer": "She wanted to tell her family the happy news.",
          "evidence": "I could hardly wait to tell my family the happy news. I ran home quickly!"
        }
      ]
    },
    {
      "id": "grade-2-a-silly-day",
      "grade": 2,
      "title": "A Silly Day",
      "path": "HTMLs/Reading Fluency/2nd Grade Fluency/A Silly Day.html",
      "text": "“Tomorrow is Wear Something Silly Day at \nschool,” Sara told her mother. “I want to wear \nsomething silly, but I don’t know what to wear.”\nSara’s mother asked her whether she \nhad any clothes that looked silly. Sara shook her \nhead sadly. Her mother told her to look in \nher bedroom closet and in the brown trunk in the \nattic. Sara went to her closet and looked closely \nat all of the clothes there. Then she went up to \nthe attic. She got down on her knees and carefully \nlooked through the trunk. None of the clothes \nwere silly, so she repacked them. As she was \ncoming down the stairs, she had an idea.\n“I might have a solution,” she told her \nmother. Sara went back into her room and picked \nout some clothes. She turned the clothes inside \nout and then put them on backward. Then she \nshowed her mother. “Here I am, Mom. What do \nyou think?” she asked.\n“That’s a very silly outfit!” her mother said. \n“What a great idea!” Sara agreed.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who wanted to find something silly to wear?",
          "answer": "Sara.",
          "evidence": "Sara told her mother. “I want to wear something silly, but I don’t know what to wear.”"
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who suggested looking in the closet and the attic trunk?",
          "answer": "Sara’s mother.",
          "evidence": "Her mother told her to look in her bedroom closet and in the brown trunk in the attic."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What did Sara do to make her clothes look silly?",
          "answer": "She turned them inside out and put them on backward.",
          "evidence": "She turned the clothes inside out and then put them on backward."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What did Sara’s mother think of the outfit?",
          "answer": "She thought it was very silly and a great idea.",
          "evidence": "“That’s a very silly outfit!” her mother said. “What a great idea!”"
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When was Wear Something Silly Day?",
          "answer": "The next day, or tomorrow.",
          "evidence": "“Tomorrow is Wear Something Silly Day at school,” Sara told her mother."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did Sara think of her solution?",
          "answer": "As she was coming down the stairs.",
          "evidence": "As she was coming down the stairs, she had an idea."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where was the brown trunk?",
          "answer": "In the attic.",
          "evidence": "in her bedroom closet and in the brown trunk in the attic."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where was Wear Something Silly Day going to happen?",
          "answer": "At school.",
          "evidence": "“Tomorrow is Wear Something Silly Day at school,” Sara told her mother."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why did Sara put the clothes back into the trunk?",
          "answer": "None of them looked silly.",
          "evidence": "None of the clothes were silly, so she repacked them."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why did Sara turn her clothes inside out and backward?",
          "answer": "To make a silly outfit for the special day at school.",
          "evidence": "“I want to wear something silly, but I don’t know what to wear.”"
        }
      ]
    },
    {
      "id": "grade-2-amazing-earthworms",
      "grade": 2,
      "title": "Amazing Earthworms",
      "path": "HTMLs/Reading Fluency/2nd Grade Fluency/Amazing Earthworms.html",
      "text": "Most people ignore the earthworm. It is often \nhidden under the ground. Did you know that \nearthworms are good for gardens?\nThey dig in the ground by eating and pushing \nthe soil. They make burrows, or tunnels. Their \nwork breaks up the soil and makes stiff ground \nsoft. The soft ground helps plants grow. Roots \ncan spread. Stems can find their way to the air. \nThe more earthworms you have, the better your \ngarden will be.\nEarthworms need to stay wet to live. They \nmust have the right kind of climate. They do not \nappear above ground during the day, unless it \nrains. The Sun might dry them up. Earthworms \ncome out at night to track down food to eat. Then \nthey wiggle back into the ground. This is where \nthey want to be. \nSome soil is full of earthworms. Some is not. \nPeople buy earthworms to add to their gardens. \nThis makes earthworms and people very happy.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who buys earthworms to put in gardens?",
          "answer": "People who want to improve their gardens.",
          "evidence": "People buy earthworms to add to their gardens."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who does the passage say is happy when earthworms are added to gardens?",
          "answer": "Both earthworms and people.",
          "evidence": "This makes earthworms and people very happy."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What are earthworm burrows?",
          "answer": "Tunnels in the soil.",
          "evidence": "They make burrows, or tunnels. Their work breaks up the soil"
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What do earthworms do to dig through the ground?",
          "answer": "They eat and push the soil.",
          "evidence": "They dig in the ground by eating and pushing the soil."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When do earthworms come out to look for food?",
          "answer": "At night.",
          "evidence": "Earthworms come out at night to track down food to eat."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When might earthworms come above ground during the day?",
          "answer": "When it rains.",
          "evidence": "They do not appear above ground during the day, unless it rains."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where are earthworms usually hidden?",
          "answer": "Under the ground.",
          "evidence": "Most people ignore the earthworm. It is often hidden under the ground."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where do people add earthworms to help plants grow?",
          "answer": "In their gardens.",
          "evidence": "People buy earthworms to add to their gardens."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why are earthworm tunnels good for plants?",
          "answer": "They soften the soil so roots and stems can grow.",
          "evidence": "The soft ground helps plants grow. Roots can spread. Stems can find their way to the air."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why do earthworms usually stay underground during a sunny day?",
          "answer": "They need to stay wet, and the Sun could dry them up.",
          "evidence": "They do not appear above ground during the day, unless it rains. The Sun might dry them up."
        }
      ]
    },
    {
      "id": "grade-2-at-the-beach",
      "grade": 2,
      "title": "At the Beach",
      "path": "HTMLs/Reading Fluency/2nd Grade Fluency/At the Beach.html",
      "text": "Ben and his family walked on the beach. Ben \nliked the beach and the sunshine. He hopped in \nthe sand. It was rough with pebbles, but he kept \nhopping.\nBen spotted fish in a narrow bit of water. \nThey were swimming close together. His father \nsnapped a photo. Then Ben watched two crabs \nhiding near some shells. He wondered which \nshell the bigger crab would decide to live in. He \nalso saw a few birds flying high in the sky. Would \nthey catch some fish to eat?\nMany people were swimming and splashing in \nthe water. A dog chased a yellow ball. Ben saw \nchildren making sandcastles. What would it be \nlike to join them later? They were having a lot \nof fun.\nHe sat near some children on the beach and \nwatched. Then he helped to make the sandcastle. \nBen had a happy day at the beach!",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who walked on the beach with Ben?",
          "answer": "His family.",
          "evidence": "Ben and his family walked on the beach."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who took a photo of the fish?",
          "answer": "Ben’s father.",
          "evidence": "They were swimming close together. His father snapped a photo."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What was the dog chasing?",
          "answer": "A yellow ball.",
          "evidence": "A dog chased a yellow ball. Ben saw children making sandcastles."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What did Ben help the children make?",
          "answer": "A sandcastle.",
          "evidence": "Then he helped to make the sandcastle. Ben had a happy day at the beach!"
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did Ben help with the sandcastle?",
          "answer": "After he sat near the children and watched them.",
          "evidence": "He sat near some children on the beach and watched. Then he helped to make the sandcastle."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did Ben’s father take the photo: before or after Ben watched the crabs?",
          "answer": "Before Ben watched the crabs.",
          "evidence": "His father snapped a photo. Then Ben watched two crabs hiding near some shells."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where were the fish Ben saw?",
          "answer": "In a narrow bit of water.",
          "evidence": "Ben spotted fish in a narrow bit of water."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where were the two crabs hiding?",
          "answer": "Near some shells.",
          "evidence": "Then Ben watched two crabs hiding near some shells."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why did Ben think it might be fun to join the children?",
          "answer": "They looked like they were having fun making sandcastles.",
          "evidence": "Ben saw children making sandcastles. What would it be like to join them later? They were having a lot of fun."
        },
        {
          "id": "what-3",
          "type": "what",
          "question": "What made the sand feel rough?",
          "answer": "Pebbles.",
          "evidence": "It was rough with pebbles, but he kept hopping."
        }
      ]
    },
    {
      "id": "grade-2-bike-safety",
      "grade": 2,
      "title": "Bike Safety",
      "path": "HTMLs/Reading Fluency/2nd Grade Fluency/Bike Safety.html",
      "text": "Imagine riding your bike. It is a lot of fun!\nYou can glide down a slope. You can pedal hard\nto climb a hill. Do you have good rules to follow\nwhen you ride a bike?\nDo you think about what could happen? Do\nyou judge how to stay safe? City streets are full\nof signs you need to read. You learn to look twice\nbefore you cross a road.\nThere are other rules to follow when you cycle.\nYou should not ride too fast. This can surprise or\nscare other people. Ride in a line with other bikes.\nSlow down when others are around.\nYou also need to wear a bike helmet. This will\nhelp keep you safe if you fall off your bike. Your\nhelmet should be tight on your head. You need to\nlook at your bike, too. Is it safe to ride? Use tools\nto make your bike safe.\nBikes are fun to ride at any age. Just\nremember to keep your ride safe!",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who might be surprised or scared if a rider goes too fast?",
          "answer": "Other people.",
          "evidence": "You should not ride too fast. This can surprise or scare other people."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who should ride in a line together?",
          "answer": "Bike riders riding with other bikes.",
          "evidence": "Ride in a line with other bikes."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What should you wear on your head when riding a bike?",
          "answer": "A bike helmet.",
          "evidence": "You also need to wear a bike helmet."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What should you do to get up a hill on your bike?",
          "answer": "Pedal hard.",
          "evidence": "You can pedal hard to climb a hill."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When should you look twice?",
          "answer": "Before crossing a road.",
          "evidence": "You learn to look twice before you cross a road."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When should you slow your bike down?",
          "answer": "When other people are around.",
          "evidence": "Slow down when others are around."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where does the passage say there are many signs to read?",
          "answer": "On city streets.",
          "evidence": "City streets are full of signs you need to read."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where should your helmet fit tightly?",
          "answer": "On your head.",
          "evidence": "Your helmet should be tight on your head."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why should you wear a helmet?",
          "answer": "To help keep you safe if you fall off your bike.",
          "evidence": "This will help keep you safe if you fall off your bike."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why should you look at your bike and use tools on it?",
          "answer": "To make sure the bike is safe to ride.",
          "evidence": "You need to look at your bike, too. Is it safe to ride? Use tools to make your bike safe."
        }
      ]
    },
    {
      "id": "grade-2-birthday-pie",
      "grade": 2,
      "title": "Birthday Pie",
      "path": "HTMLs/Reading Fluency/2nd Grade Fluency/Birthday Pie.html",
      "text": "Jason is glad today. It is his birthday. Five\nfriends will come to his house to have a picnic\nlunch and eat snacks. Next the children will tell\njokes and play games.\n\nJason will rip open his gifts. Will his friends\nbring a tent, a bug box, or a frog kit? Those were\nsome gifts on his list. He will soon see what his\nfriends will bring.\n\nWill they eat birthday cake? No! Jason does\nnot like birthday cake. Cake is too sweet. He does\nnot like nuts or jam or plums, either. Jason\nlikes pie.\n\nHe helps his mom sift flour until she digs in\nto make the crust. He licks his lips. This pie will be\nthe best. His friends will love it.\n\nJason’s mother will stick candles on his pie.\nShe will turn off the lights. Then his friends and\nfamily will sit around to sing. “Happy Birthday to\nyou!” The song will echo through the house.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who is celebrating a birthday?",
          "answer": "Jason.",
          "evidence": "Jason is glad today. It is his birthday."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who will put candles on Jason’s pie?",
          "answer": "Jason’s mother.",
          "evidence": "Jason’s mother will stick candles on his pie."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What meal will Jason and his friends have?",
          "answer": "A picnic lunch and snacks.",
          "evidence": "Five friends will come to his house to have a picnic lunch and eat snacks."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What are two gifts on Jason’s wish list?",
          "answer": "Any two of: a tent, a bug box, or a frog kit.",
          "evidence": "Will his friends bring a tent, a bug box, or a frog kit? Those were some gifts on his list.",
          "accept": "Accept any two of the three listed gifts."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When will the children tell jokes and play games?",
          "answer": "After having their picnic lunch and snacks.",
          "evidence": "have a picnic lunch and eat snacks. Next the children will tell jokes and play games."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When will the friends and family sing Happy Birthday?",
          "answer": "After his mother turns off the lights.",
          "evidence": "She will turn off the lights. Then his friends and family will sit around to sing."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where will Jason’s friends come for the party?",
          "answer": "To Jason’s house.",
          "evidence": "Five friends will come to his house to have a picnic lunch and eat snacks."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where will Jason’s mother put the birthday candles?",
          "answer": "On his pie.",
          "evidence": "Jason’s mother will stick candles on his pie."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why doesn’t Jason want birthday cake?",
          "answer": "He thinks cake is too sweet.",
          "evidence": "Jason does not like birthday cake. Cake is too sweet."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why does Jason help sift flour?",
          "answer": "To help his mom make the pie crust.",
          "evidence": "He helps his mom sift flour until she digs in to make the crust."
        }
      ]
    },
    {
      "id": "grade-2-bumblebees",
      "grade": 2,
      "title": "Bumblebees",
      "path": "HTMLs/Reading Fluency/2nd Grade Fluency/Bumblebees.html",
      "text": "A bee is made up of different parts. Each \npart has a special use. Let’s look at how a bee \nuses three of these parts.\nA bee has five eyes. Two eyes are large, and \nthree eyes are small. A bee’s eyes can see things \nmove. They see different colors than we do. For \nexample, a bee can’t see red!\nA bee flies with four wings. It must move its \nwings fast to fly. If it doesn’t, it won’t lift up in \nthe air. Bees fly from flower to flower. They are \nlooking for pollen. This helps flowers grow.\nA bee has six legs. Some of its legs have hair \non them. The hair helps carry the pollen bees find.\nDo you feel nervous around bees? Many \npeople become tense around bees. We’ve heard \nthat they sometimes can sting. We’re afraid we’ll \nget hurt. But if we leave bees alone, they’ll leave \nus alone, too!",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who does the passage say often becomes tense around bees?",
          "answer": "Many people.",
          "evidence": "Many people become tense around bees. We’ve heard that they sometimes can sting."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who goes from flower to flower looking for pollen?",
          "answer": "Bees.",
          "evidence": "Bees fly from flower to flower. They are looking for pollen."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What color can a bee not see?",
          "answer": "Red.",
          "evidence": "For example, a bee can’t see red!"
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What helps a bee carry pollen on its legs?",
          "answer": "Hair on some of its legs.",
          "evidence": "Some of its legs have hair on them. The hair helps carry the pollen bees find."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When can a bee lift up into the air?",
          "answer": "When it moves its wings fast.",
          "evidence": "It must move its wings fast to fly. If it doesn’t, it won’t lift up in the air."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When does the passage say bees will leave us alone?",
          "answer": "If we leave the bees alone.",
          "evidence": "But if we leave bees alone, they’ll leave us alone, too!"
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where do bees fly to find pollen?",
          "answer": "From flower to flower.",
          "evidence": "Bees fly from flower to flower. They are looking for pollen."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where on a bee does the passage describe hair that carries pollen?",
          "answer": "On some of its legs.",
          "evidence": "Some of its legs have hair on them. The hair helps carry the pollen bees find."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why are many people afraid of bees?",
          "answer": "They are afraid of being stung and hurt.",
          "evidence": "We’ve heard that they sometimes can sting. We’re afraid we’ll get hurt."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why is a bee’s search for pollen helpful to flowers?",
          "answer": "It helps flowers grow.",
          "evidence": "They are looking for pollen. This helps flowers grow."
        }
      ]
    },
    {
      "id": "grade-2-digging-for-clams",
      "grade": 2,
      "title": "Digging for Clams",
      "path": "HTMLs/Reading Fluency/2nd Grade Fluency/Digging for Clams.html",
      "text": "Have you ever found seashells on the beach? \nMany shells are clamshells. Clams often live \nunderwater in the wet sand or mud.\nA clam’s shell has two parts. The parts open \nand close like a mouth. The clam opens its shell \nto get food. An open clam can look ready to bite \ndown. Does anybody trust a hungry mouth?\nHave you ever thought about digging for \nclams? It is not always fun. Clams can be hard to \nfind. They like to stay hidden. Maybe they know \nthey are good to eat!\nThere is a lot of mud when you dig for clams. \nPeople might wear boots or raincoats to keep \nfrom getting muddy. Then it can be fun to pluck \none from the mud.\nThere are many ways to cook clams. You can \nfind recipes in a book. Does digging for clams \nsound too hard? There is an easier way to get \nthem. You can buy clams at a fish shop or a \ngrocery store, too!",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who might wear boots or raincoats while digging for clams?",
          "answer": "People digging for clams.",
          "evidence": "People might wear boots or raincoats to keep from getting muddy."
        },
        {
          "id": "what-3",
          "type": "what",
          "question": "What can an open clam look ready to do?",
          "answer": "Bite down, like a mouth.",
          "evidence": "An open clam can look ready to bite down."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What opens and closes like a mouth on a clam?",
          "answer": "Its two-part shell.",
          "evidence": "A clam’s shell has two parts. The parts open and close like a mouth."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What is an easier way to get clams without digging?",
          "answer": "Buy them at a fish shop or grocery store.",
          "evidence": "There is an easier way to get them. You can buy clams at a fish shop or a grocery store, too!"
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When does a clam open its shell?",
          "answer": "When it needs to get food.",
          "evidence": "The clam opens its shell to get food."
        },
        {
          "id": "why-3",
          "type": "why",
          "question": "Why might someone buy clams instead of digging for them?",
          "answer": "Buying them is easier if digging for clams seems too hard.",
          "evidence": "Does digging for clams sound too hard? There is an easier way to get them."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where do clams often live?",
          "answer": "Underwater in wet sand or mud.",
          "evidence": "Clams often live underwater in the wet sand or mud."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where can you find recipes for cooking clams?",
          "answer": "In a book.",
          "evidence": "There are many ways to cook clams. You can find recipes in a book."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why can clams be difficult to find?",
          "answer": "They like to stay hidden.",
          "evidence": "Clams can be hard to find. They like to stay hidden."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why might a person wear boots while digging for clams?",
          "answer": "To keep from getting muddy.",
          "evidence": "People might wear boots or raincoats to keep from getting muddy."
        }
      ]
    },
    {
      "id": "grade-2-dinosaur-museum",
      "grade": 2,
      "title": "Dinosaur Museum",
      "path": "HTMLs/Reading Fluency/2nd Grade Fluency/Dinosaur Museum.html",
      "text": "Welcome to the museum. It is open all week, \nand Mondays are free. We have space to keep \nyour coats as you get started.\nIf you like, a person who works here can lead \nyou through and show you different things from \naround the world. You may also walk through the \nmuseum with only your family.\nDo you dream of seeing dinosaurs? This \nmuseum has the bones of many different kinds! \nYou will see models of baby dinosaurs. You will \neven see real dinosaur eggs that were found in \nthe ground.\nEveryone needs to follow a few rules at the \nmuseum. Please walk slowly. Never run. Do not \nbring in food and drinks. Eat meals only in the \nfood areas. You must stay with your leader, even \nif you want to peek at something else. Objects \nare old and break easily, so do not touch things in \nthe museum. Be very careful!\nHave fun while you visit. It is a pleasure to \nhave you here!",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who can lead visitors through the museum and show them things?",
          "answer": "A person who works at the museum.",
          "evidence": "a person who works here can lead you through and show you different things from around the world."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who must you stay with while visiting the museum?",
          "answer": "Your leader.",
          "evidence": "You must stay with your leader, even if you want to peek at something else."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What are two dinosaur things visitors can see at this museum?",
          "answer": "Any two of: dinosaur bones, models of baby dinosaurs, or real dinosaur eggs.",
          "evidence": "This museum has the bones of many different kinds! You will see models of baby dinosaurs. You will even see real dinosaur eggs",
          "accept": "Accept any two: dinosaur bones, baby dinosaur models, real dinosaur eggs."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What does the museum ask visitors to do instead of running?",
          "answer": "Walk slowly.",
          "evidence": "Please walk slowly. Never run. Do not bring in food and drinks."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When is visiting the museum free?",
          "answer": "On Mondays.",
          "evidence": "It is open all week, and Mondays are free."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When during the week is the museum open?",
          "answer": "All week.",
          "evidence": "Welcome to the museum. It is open all week, and Mondays are free."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where can visitors leave their coats?",
          "answer": "In the coat space at the museum.",
          "evidence": "We have space to keep your coats as you get started."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where should visitors eat their meals?",
          "answer": "Only in the food areas.",
          "evidence": "Eat meals only in the food areas."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why should visitors avoid touching museum objects?",
          "answer": "The objects are old and break easily.",
          "evidence": "Objects are old and break easily, so do not touch things in the museum."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why might a family choose to have a museum worker lead them?",
          "answer": "The worker can show them the different things in the museum.",
          "evidence": "a person who works here can lead you through and show you different things from around the world."
        }
      ]
    },
    {
      "id": "grade-2-dr-seuss",
      "grade": 2,
      "title": "Dr. Seuss",
      "path": "HTMLs/Reading Fluency/2nd Grade Fluency/Dr Seuss.html",
      "text": "Do you know the name Dr. Seuss? That might \nbe because you have read his books. Maybe your \nteacher has his books in the classroom right now! \nDr. Seuss was a writer of many children’s books. \nChildren like his funny pictures and rhymes.\nDr. Seuss was born in 1904. In school, he \nliked to write stories with funny pictures. He also \ndecided to try designing cartoons. He wanted to \nsee whether he was good at it. He was!\nWhen Dr. Seuss finished and sold his first \ncartoon, he moved to New York City. He wrote his \nfirst story in 1937.\nTwenty years later, he wrote The Cat in the \nHat. In this story, two children wonder why the \nSun does not shine. They are surprised at the \nsight of the wild cat that stops by! It is very funny. \nMany more stories delighted readers before \nDr. Seuss died in 1991.\nToday children still love his books. There is \nsomething in his stories for any age. Do you have \na Dr. Seuss book that you love?",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who wrote the children’s books described in the passage?",
          "answer": "Dr. Seuss.",
          "evidence": "Dr. Seuss was a writer of many children’s books."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who is surprised by the wild cat in The Cat in the Hat?",
          "answer": "The two children in the story.",
          "evidence": "two children wonder why the Sun does not shine. They are surprised at the sight of the wild cat that stops by!"
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What is the name of the book Dr. Seuss wrote twenty years after his first story?",
          "answer": "The Cat in the Hat.",
          "evidence": "Twenty years later, he wrote The Cat in the Hat."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What did Dr. Seuss like to make when he was in school?",
          "answer": "Stories with funny pictures.",
          "evidence": "In school, he liked to write stories with funny pictures."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When was Dr. Seuss born?",
          "answer": "In 1904.",
          "evidence": "Dr. Seuss was born in 1904."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did Dr. Seuss write his first story, according to the passage?",
          "answer": "In 1937.",
          "evidence": "He wrote his first story in 1937."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where did Dr. Seuss move after selling his first cartoon?",
          "answer": "New York City.",
          "evidence": "When Dr. Seuss finished and sold his first cartoon, he moved to New York City."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where might a teacher have Dr. Seuss books right now?",
          "answer": "In the classroom.",
          "evidence": "Maybe your teacher has his books in the classroom right now!"
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why did Dr. Seuss try designing cartoons?",
          "answer": "He wanted to find out if he was good at it.",
          "evidence": "He also decided to try designing cartoons. He wanted to see whether he was good at it."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why do children enjoy Dr. Seuss books, according to the passage?",
          "answer": "They like the funny pictures and rhymes.",
          "evidence": "Children like his funny pictures and rhymes."
        }
      ]
    },
    {
      "id": "grade-2-lily-s-collection",
      "grade": 2,
      "title": "Lily’s Collection",
      "path": "HTMLs/Reading Fluency/2nd Grade Fluency/Lily's Collection.html",
      "text": "Lily’s father likes to collect clocks. Her mother \nhas more than one hundred small, stuffed bears. \nLily wants to collect things, too.\nShe looks in her room. Lily wonders, “What \ndo I want to collect?” She glances at her toys. Lily \ndoes not want to collect toys. She has books. Lily \ndoes not want to collect books, either. She is not \nsure what to do.\nThen Lily drags a box from under her bed and \nplaces it on her table. She uses the box to store \nher shells. Her best shells are inside it. One shell \nis yellow with stripes. She got it when she went \nto visit her friend, Clare. There is also a little, red \nshell. She scooped this shell from the sand after \nswimming at the beach.\nLily finds a third green shell that is smooth \nacross her skin. She spotted this shell on a school \ntrip to a lighthouse. It really shines!\nLily likes shells. She looks at them. She smiles. \nNow Lily knows what she will collect.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who in Lily’s family collects clocks?",
          "answer": "Her father.",
          "evidence": "Lily’s father likes to collect clocks."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who was Lily visiting when she got the yellow striped shell?",
          "answer": "Her friend Clare.",
          "evidence": "One shell is yellow with stripes. She got it when she went to visit her friend, Clare."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What does Lily’s mother collect?",
          "answer": "Small stuffed bears.",
          "evidence": "Her mother has more than one hundred small, stuffed bears."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What does Lily decide she wants to collect?",
          "answer": "Shells.",
          "evidence": "Lily likes shells. She looks at them. She smiles. Now Lily knows what she will collect."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did Lily find the little red shell?",
          "answer": "After swimming at the beach.",
          "evidence": "She scooped this shell from the sand after swimming at the beach."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did Lily find the green shell?",
          "answer": "During a school trip to a lighthouse.",
          "evidence": "She spotted this shell on a school trip to a lighthouse."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where was Lily’s shell box before she pulled it out?",
          "answer": "Under her bed.",
          "evidence": "Then Lily drags a box from under her bed and places it on her table."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where did Lily put the box after pulling it out?",
          "answer": "On her table.",
          "evidence": "Then Lily drags a box from under her bed and places it on her table."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why was Lily unsure what to collect at first?",
          "answer": "She did not want to collect her toys or her books.",
          "evidence": "Lily does not want to collect toys. She has books. Lily does not want to collect books, either."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why did Lily choose shells for her collection?",
          "answer": "She enjoyed the shells she already had.",
          "evidence": "Lily likes shells. She looks at them. She smiles. Now Lily knows what she will collect."
        }
      ]
    },
    {
      "id": "grade-2-mike-s-idea",
      "grade": 2,
      "title": "Mike’s Idea",
      "path": "HTMLs/Reading Fluency/2nd Grade Fluency/Mike's Idea.html",
      "text": "Mike’s class wanted to do something special \nfor the children at the hospital. The class decided \nto raise money to buy books. The students would \nhave a cookie sale at school. When he got home, \nMike asked his mother for help making cookies. \nShe said, “I am sorry, but I have too much to do \ntoday.”\nMike asked his father for help. He said, “I \nam sorry. I would enjoy making cookies, but I \npromised to help your sister paint her toy chest.”\n“Who else could I ask?” Mike thought. Then \nMike devised a plan. He called his pal Tran, who \nlived nearby. They could make cookies together! \nTran asked his grandfather. His grandfather \nreplied, “I loved baking cookies during my \nboyhood. I would be delighted to help you both.”\nMike took sugar and flour to Tran’s house. \nMike, Tran, and Tran’s grandfather baked cookies. \nThe next day, the boys sold cookies. They used \nthe money to buy seven books for the children at \nthe hospital. Next time they hope to raise enough \nmoney for even more books.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who did Mike call after his parents could not help him bake?",
          "answer": "His pal Tran.",
          "evidence": "He called his pal Tran, who lived nearby."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who agreed to help both boys bake cookies?",
          "answer": "Tran’s grandfather.",
          "evidence": "His grandfather replied, “I loved baking cookies during my boyhood. I would be delighted to help you both.”"
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What did the class plan to sell to raise money?",
          "answer": "Cookies.",
          "evidence": "The students would have a cookie sale at school."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What did the boys buy with the money they raised?",
          "answer": "Seven books for children at the hospital.",
          "evidence": "They used the money to buy seven books for the children at the hospital."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did Mike ask his mother for help making cookies?",
          "answer": "When he got home.",
          "evidence": "When he got home, Mike asked his mother for help making cookies."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did the boys sell their cookies?",
          "answer": "The next day after baking them.",
          "evidence": "Mike, Tran, and Tran’s grandfather baked cookies. The next day, the boys sold cookies."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where would the cookie sale take place?",
          "answer": "At school.",
          "evidence": "The students would have a cookie sale at school."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where did Mike go to bake the cookies with Tran?",
          "answer": "To Tran’s house.",
          "evidence": "Mike took sugar and flour to Tran’s house. Mike, Tran, and Tran’s grandfather baked cookies."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why could Mike’s mother not help bake that day?",
          "answer": "She had too much to do.",
          "evidence": "She said, “I am sorry, but I have too much to do today.”"
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why could Mike’s father not help bake?",
          "answer": "He had promised to help Mike’s sister paint her toy chest.",
          "evidence": "I promised to help your sister paint her toy chest."
        }
      ]
    },
    {
      "id": "grade-2-ramona-and-ben",
      "grade": 2,
      "title": "Ramona and Ben",
      "path": "HTMLs/Reading Fluency/2nd Grade Fluency/Ramona and Ben.html",
      "text": "It was such a beautiful day that Ramona had \na yearning to be outside. She called out, “Where \nare you, Ben? Do you want to go to the park?”\nBen flew into the room and said, “I love the \npark. I’m always ready for an adventure. I wish \nwe could go to the park every day. Today is going \nto be a wonderful day!” He put on his collar. “I \ncan hardly wait to splash in the brook and push \nyou on the wooden swing.” Ben ran to get a few \nthings to take to the park. He got his football and \na good book to read.\n“Ben, you don’t need all that!” Ramona \nexclaimed as she shook her head in wonder.\n“Yes, I do, I truly do!” Ben answered firmly as \nhe refused to put them back.\nRamona knew it was useless to argue, so she \ntook Ben’s leash off its hook and said, “Are we \nready now?”\nBen wiggled with excitement and followed \nRamona out the door. He knew it would be a \nmemorable day.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who asked Ben to go to the park?",
          "answer": "Ramona.",
          "evidence": "She called out, “Where are you, Ben? Do you want to go to the park?”"
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who refused to put the football and book back?",
          "answer": "Ben.",
          "evidence": "Ben answered firmly as he refused to put them back."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What two things did Ben collect to take to the park?",
          "answer": "His football and a book.",
          "evidence": "He got his football and a good book to read.",
          "accept": "Accept football and book; both items are needed."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What did Ramona take off its hook?",
          "answer": "Ben’s leash.",
          "evidence": "she took Ben’s leash off its hook"
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did Ben collect things for the park?",
          "answer": "Before he and Ramona left for the park.",
          "evidence": "Ben ran to get a few things to take to the park. He got his football and a good book to read."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did Ben wiggle with excitement?",
          "answer": "As he followed Ramona out the door.",
          "evidence": "Ben wiggled with excitement and followed Ramona out the door."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where did Ramona and Ben plan to go?",
          "answer": "The park.",
          "evidence": "Do you want to go to the park?"
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where did Ben want to splash?",
          "answer": "In the brook.",
          "evidence": "I can hardly wait to splash in the brook"
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why did Ramona want to be outside?",
          "answer": "It was a beautiful day.",
          "evidence": "It was such a beautiful day that Ramona had a yearning to be outside."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why did Ramona stop arguing about the things Ben wanted to bring?",
          "answer": "Ben firmly refused to put them back, and she knew arguing would not help.",
          "evidence": "Ben answered firmly as he refused to put them back. Ramona knew it was useless to argue,",
          "accept": "Accept that Ben would not change his mind or that arguing was useless."
        }
      ]
    },
    {
      "id": "grade-2-space-story",
      "grade": 2,
      "title": "Space Story",
      "path": "HTMLs/Reading Fluency/2nd Grade Fluency/Space Story.html",
      "text": "Hona was at her computer. Three moons \nshone through her window. She checked her \nreport to make sure all of the words were spelled \ncorrectly. She caught one misspelled word and \ncorrected it.\nOnce she was done with her report, Hona \nsearched the computer for other things she \nwanted to learn. She saw an article called “Global \nWarming Could Prove Fatal.” It was about a \nplanet very far away. Hona had never even heard \nof the planet. It was called Earth.\nShe called out, “Father! You have to hear this. \nThere’s a planet in the Milky Way system that’s still \nusing oil for energy! Come see!”\nMr. Mercury entered his daughter’s room and \nread the article. “This is interesting! They’re close \nenough to their Sun to use its energy! They have \nwind and ocean waves, too. Why aren’t they using \nthose energies for power?”\nHona concluded, “I think we should take a \nspaceship and go over there to talk to them about \nother things they can do.”",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who checked the report for spelling mistakes?",
          "answer": "Hona.",
          "evidence": "Hona was at her computer. Three moons shone through her window. She checked her report"
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who came into Hona’s room and read the article?",
          "answer": "Her father, Mr. Mercury.",
          "evidence": "Mr. Mercury entered his daughter’s room and read the article."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What did Hona fix in her report?",
          "answer": "One misspelled word.",
          "evidence": "She caught one misspelled word and corrected it."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What was Earth still using for energy?",
          "answer": "Oil.",
          "evidence": "There’s a planet in the Milky Way system that’s still using oil for energy!"
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did Hona look for other things to learn on the computer?",
          "answer": "After she finished her report.",
          "evidence": "Once she was done with her report, Hona searched the computer for other things she wanted to learn."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did Hona’s father come to read the article?",
          "answer": "After Hona called him to come and see it.",
          "evidence": "Come see!” Mr. Mercury entered his daughter’s room and read the article."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where were the three moons shining?",
          "answer": "Through Hona’s window.",
          "evidence": "Three moons shone through her window."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where was Earth, according to Hona?",
          "answer": "In the Milky Way system.",
          "evidence": "There’s a planet in the Milky Way system"
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why did Hona check her report?",
          "answer": "To make sure the words were spelled correctly.",
          "evidence": "She checked her report to make sure all of the words were spelled correctly."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why did Hona want to take a spaceship to Earth?",
          "answer": "To talk to people there about other ways to get energy.",
          "evidence": "go over there to talk to them about other things they can do.",
          "accept": "Accept explaining energy from the Sun, wind, or ocean waves instead of oil."
        }
      ]
    },
    {
      "id": "grade-2-the-king-of-insects",
      "grade": 2,
      "title": "The King of Insects",
      "path": "HTMLs/Reading Fluency/2nd Grade Fluency/The King of Insects.html",
      "text": "Could the beetle be the king of insects? There \nare almost 400,000 kinds of beetles on Earth. \nThat is more beetles than any other kind of insect. \nHave you ever explored the ground for bugs? \nHave you searched your own back porch? Be \nready to find beetles in many colors. They can be \nbrown or black. They can be red or green and \nmore. Beetles also come in different sizes and \nforms. The biggest are six inches long.\nLadybugs are a very pretty kind of beetle. You \nmay have held a ladybug in your hand. People \nwith gardens buy boxes of ladybugs from a store. \nThe ladybugs eat insects that chew or bore into \ngarden plants and often destroy them. This helps \nthe garden plants grow.\nSome people keep beetles as pets. Some \npeople eat beetles. Imagine sorting all the \nanimals in the world in a single line. Every fourth \none would be a beetle.\nThat is a lot of beetles! This is why the beetle \nis called the king of insects.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who buys boxes of ladybugs to help their plants?",
          "answer": "People with gardens.",
          "evidence": "People with gardens buy boxes of ladybugs from a store."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who eats the insects that damage garden plants?",
          "answer": "Ladybugs.",
          "evidence": "The ladybugs eat insects that chew or bore into garden plants and often destroy them."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What are two colors a beetle can be?",
          "answer": "Any two of: brown, black, red, or green.",
          "evidence": "They can be brown or black. They can be red or green and more.",
          "accept": "Accept any two colors listed in the passage."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What is the length of the biggest beetles in the passage?",
          "answer": "Six inches.",
          "evidence": "The biggest are six inches long."
        },
        {
          "id": "what-3",
          "type": "what",
          "question": "What do some people keep beetles as?",
          "answer": "Pets.",
          "evidence": "Some people keep beetles as pets."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When do ladybugs help garden plants grow?",
          "answer": "When they eat the insects that damage the plants.",
          "evidence": "The ladybugs eat insects that chew or bore into garden plants and often destroy them. This helps the garden plants grow."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where could you look outside to find beetles?",
          "answer": "On the ground or on a back porch.",
          "evidence": "Have you ever explored the ground for bugs? Have you searched your own back porch?",
          "accept": "Accept either place mentioned."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where can gardeners buy ladybugs?",
          "answer": "At a store.",
          "evidence": "People with gardens buy boxes of ladybugs from a store."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why is the beetle called the king of insects?",
          "answer": "There are so many kinds of beetles—more than any other kind of insect.",
          "evidence": "There are almost 400,000 kinds of beetles on Earth. That is more beetles than any other kind of insect."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why do people with gardens buy ladybugs?",
          "answer": "Ladybugs eat the insects that harm the plants.",
          "evidence": "The ladybugs eat insects that chew or bore into garden plants and often destroy them. This helps the garden plants grow."
        }
      ]
    },
    {
      "id": "grade-2-the-park",
      "grade": 2,
      "title": "The Park",
      "path": "HTMLs/Reading Fluency/2nd Grade Fluency/The Park.html",
      "text": "Where do you like to go in winter? Our park \nis glorious when the weather turns cold. The pond \nfreezes, making a perfect place to ice skate. It is \nthrilling to twirl on the ice!\nWhen it snows, everyone brings a colorful \nsled. Children curl up on their sleds and swerve \nquickly down the hill. There are three hills in the \npark. The third has the deepest snow. Be sure to \nbe very careful where the bigger trees line the hill. \nYou do not want to hit one!\nWhat’s another sight at the park? You might \nsee squirrels and birds. Here’s a red bird flying in \na burst of color across the sea of snow.\nWhat sounds might you hear? When the \nsnow falls, the park becomes quiet. Listen and \nyou might hear a woodpecker pecking the older \ntrees. It is looking for bugs to eat.\nAn hour passes quickly in our park. \nRemember to wear your hat and boots to stay \nwarm. One visit and you will surely return!",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who rides colorful sleds down the hills?",
          "answer": "Children.",
          "evidence": "Children curl up on their sleds and swerve quickly down the hill."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who pecks the older trees to look for bugs?",
          "answer": "A woodpecker.",
          "evidence": "you might hear a woodpecker pecking the older trees. It is looking for bugs to eat."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What color is the bird flying across the snow?",
          "answer": "Red.",
          "evidence": "Here’s a red bird flying in a burst of color across the sea of snow."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What two things should visitors wear to stay warm?",
          "answer": "A hat and boots.",
          "evidence": "Remember to wear your hat and boots to stay warm."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When is the pond a place to ice skate?",
          "answer": "When it freezes in cold weather.",
          "evidence": "Our park is glorious when the weather turns cold. The pond freezes, making a perfect place to ice skate."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When does everyone bring a sled to the park?",
          "answer": "When it snows.",
          "evidence": "When it snows, everyone brings a colorful sled."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where is the deepest snow?",
          "answer": "On the third hill in the park.",
          "evidence": "There are three hills in the park. The third has the deepest snow."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where does the woodpecker look for bugs?",
          "answer": "In the older trees.",
          "evidence": "you might hear a woodpecker pecking the older trees. It is looking for bugs to eat."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why should sledders be careful near the bigger trees?",
          "answer": "So they do not hit a tree.",
          "evidence": "Be sure to be very careful where the bigger trees line the hill. You do not want to hit one!"
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why should you wear a hat and boots at the park?",
          "answer": "To stay warm.",
          "evidence": "Remember to wear your hat and boots to stay warm."
        }
      ]
    },
    {
      "id": "grade-2-tom-saves-the-day",
      "grade": 2,
      "title": "Tom Saves the Day",
      "path": "HTMLs/Reading Fluency/2nd Grade Fluency/Tom Saves the Day.html",
      "text": "Tom talks to his friends about his new job. \nTom used to sit at a gray desk all day. He missed \nbeing outside in the fresh air and sunlight. He \nwanted something different. \nNow his job is much more fun! He works on \na fishing boat. “I like how the boat sways in the \nwind when we put up the sail!” says Tom. “I like \nthe way the water sprays over the rails.”\nTom tells a story. He was on the boat, far out \nin the bay. He saw a large fish through the misty \nrain. It was caught in bunches of fishing line. The \nfish fought but could not get out! The water was \nnot deep enough, and the fish would die soon.\n“We pulled the boat up and stayed close \nto the fish,” says Tom. “I heard its tail flapping \nagainst the water.” Tom was afraid he would not \nfree the fish in time.\nThen he raised the line, and the fish twisted \nout! “I saved the fish!” Tom loves his new job.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who does Tom talk to about his new job?",
          "answer": "His friends.",
          "evidence": "Tom talks to his friends about his new job."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who freed the large fish?",
          "answer": "Tom.",
          "evidence": "Then he raised the line, and the fish twisted out! “I saved the fish!”"
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What did Tom do to free the fish?",
          "answer": "He raised the fishing line.",
          "evidence": "Then he raised the line, and the fish twisted out!"
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What did Tom do at his old job all day?",
          "answer": "He sat at a gray desk.",
          "evidence": "Tom used to sit at a gray desk all day."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did Tom miss being in the fresh air and sunlight?",
          "answer": "When he worked at a desk all day.",
          "evidence": "Tom used to sit at a gray desk all day. He missed being outside in the fresh air and sunlight."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did the fish twist free?",
          "answer": "After Tom raised the line.",
          "evidence": "Then he raised the line, and the fish twisted out!"
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where does Tom work at his new job?",
          "answer": "On a fishing boat.",
          "evidence": "He works on a fishing boat."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where was the boat when Tom saw the trapped fish?",
          "answer": "Far out in the bay.",
          "evidence": "He was on the boat, far out in the bay. He saw a large fish through the misty rain."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why did Tom want a different job?",
          "answer": "He missed being outside in the fresh air and sunlight.",
          "evidence": "He missed being outside in the fresh air and sunlight. He wanted something different."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why did Tom need to free the fish quickly?",
          "answer": "It was trapped in fishing line in water that was not deep enough, and it would die soon.",
          "evidence": "The fish fought but could not get out! The water was not deep enough, and the fish would die soon.",
          "accept": "Accept that the trapped fish would die soon or could not get out of shallow water."
        }
      ]
    },
    {
      "id": "grade-2-wanda-s-swamp",
      "grade": 2,
      "title": "Wanda’s Swamp",
      "path": "HTMLs/Reading Fluency/2nd Grade Fluency/Wanda's Swamp.html",
      "text": "Wanda likes to visit the swamp. A swamp is \na place that is very wet. Wanda’s dad takes her \naround the swamp in his boat. They float under \nthe big willow trees and gum trees.\nMany animals live in the swamp. Wanda stays \nalert in the boat. She looks out for cottonmouth \nsnakes. She knows they are very dangerous. \nWanda’s dad likes to watch for birds. He points \nout the different birds in the sky. Many are social \nbirds and stay together in groups. There are many \nanimals in the swamp that they never see. The \nbobcat stays away from people. Fish swim below \nin the water, but the water is too dark to see \nthem.\nFrom the boat, Wanda can see a turtle. It \nsleeps on a sunny spot on a rock. She watches a \nbeetle take a dive. Two years ago, Wanda saw a \nraccoon catching a fish. But the most exciting day \nat the swamp that she can remember was when \nshe saw two bear cubs running between the trees!",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who takes Wanda around the swamp in a boat?",
          "answer": "Her dad.",
          "evidence": "Wanda’s dad takes her around the swamp in his boat."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who saw a raccoon catching a fish two years ago?",
          "answer": "Wanda.",
          "evidence": "Two years ago, Wanda saw a raccoon catching a fish."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What does Wanda’s dad like to watch for?",
          "answer": "Birds.",
          "evidence": "Wanda’s dad likes to watch for birds."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What animals made Wanda’s most exciting visit special?",
          "answer": "Two bear cubs.",
          "evidence": "the most exciting day at the swamp that she can remember was when she saw two bear cubs running between the trees!"
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did Wanda see a raccoon catching a fish?",
          "answer": "Two years ago.",
          "evidence": "Two years ago, Wanda saw a raccoon catching a fish."
        },
        {
          "id": "what-3",
          "type": "what",
          "question": "What kind of place is a swamp?",
          "answer": "A very wet place.",
          "evidence": "A swamp is a place that is very wet."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where do Wanda and her dad float in the boat?",
          "answer": "Under the big willow trees and gum trees.",
          "evidence": "They float under the big willow trees and gum trees."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where is the turtle sleeping?",
          "answer": "On a sunny spot on a rock.",
          "evidence": "It sleeps on a sunny spot on a rock."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why does Wanda look out for cottonmouth snakes?",
          "answer": "They are very dangerous.",
          "evidence": "She looks out for cottonmouth snakes. She knows they are very dangerous."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why can’t Wanda see the fish below the boat?",
          "answer": "The water is too dark.",
          "evidence": "Fish swim below in the water, but the water is too dark to see them."
        }
      ]
    },
    {
      "id": "grade-3-a-thanksgiving-to-remember",
      "grade": 3,
      "title": "A Thanksgiving to Remember",
      "path": "HTMLs/Reading Fluency/3rd Grade Fluency/A Thanksgiving to Remember.html",
      "text": "There is one Thanksgiving on the farm that I \nremember quite fondly. It had been an extremely \nlong, hot summer. Then came the drought. If memory \nserves, it didn’t rain for a month straight. Next the \nlocusts arrived. They were ferocious, eating all plants \nin their path. And the war raged on, which added to \nthe gloom.\nWe had a cow, so there was plenty of milk \navailable. Mom thinned the mashed potatoes by adding \nbutter and cream. Some neighbors brought us a small \nchicken that served as a “turkey,” and the cabbage \nhad to do as a green vegetable.\nWe all appeared glum when dinner was ready. \nJust as we sat down, there was a knock on the door. \nI answered it. There stood my brother, Matt, handsome \nas a prince in his army uniform. I screamed and jumped \ninto his arms. My shriek was followed by shouts of joy. \nSoon everyone was squealing with excitement that \nMatt had been released from the army.\nSometimes I mash my potatoes just like we did that \nThanksgiving. I add so much butter and cream that \nthey hardly pile up at all. It brings the memory back.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who surprised the family by arriving at Thanksgiving dinner?",
          "answer": "Matt, the narrator’s brother.",
          "evidence": "There stood my brother, Matt, handsome as a prince in his army uniform."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who brought the family a small chicken?",
          "answer": "Some neighbors.",
          "evidence": "Some neighbors brought us a small chicken that served as a “turkey,”"
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What vegetable did the family eat at dinner?",
          "answer": "Cabbage.",
          "evidence": "the cabbage had to do as a green vegetable."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What did Mom add to thin the mashed potatoes?",
          "answer": "Butter and cream.",
          "evidence": "Mom thinned the mashed potatoes by adding butter and cream."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did the drought come?",
          "answer": "After a very long, hot summer.",
          "evidence": "It had been an extremely long, hot summer. Then came the drought."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did someone knock on the door?",
          "answer": "Just as the family sat down for dinner.",
          "evidence": "Just as we sat down, there was a knock on the door."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where did this Thanksgiving take place?",
          "answer": "On the family’s farm.",
          "evidence": "There is one Thanksgiving on the farm that I remember quite fondly."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where was Matt standing when the narrator saw him?",
          "answer": "At the door.",
          "evidence": "there was a knock on the door. I answered it. There stood my brother, Matt,"
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why was the family feeling gloomy before dinner?",
          "answer": "They had been through drought, locusts, and war.",
          "evidence": "They were ferocious, eating all plants in their path. And the war raged on, which added to the gloom.",
          "accept": "Accept any hardship named in the passage: drought, locusts eating plants, or war."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why does the narrator sometimes add lots of butter and cream to mashed potatoes now?",
          "answer": "It brings back the memory of that Thanksgiving.",
          "evidence": "I add so much butter and cream that they hardly pile up at all. It brings the memory back."
        }
      ]
    },
    {
      "id": "grade-3-amy-and-tom",
      "grade": 3,
      "title": "Amy and Tom",
      "path": "HTMLs/Reading Fluency/3rd Grade Fluency/Amy and Tom.html",
      "text": "Amy and Tom are twins. Although Amy was born\nfirst, her parents insist that does not give her an\nadvantage and that she and her brother must take\nturns. Sometimes this is easy, and other times it is\ndifficult.\nDad asks the children whether they want to go\nto the library. Amy and Tom race to the minivan. They\neach attempt to get in the front seat. Dad asks whose\nturn it is to ride up front. Amy and Tom both shout,\n“Mine!” When Dad announces it is Amy’s turn, Amy\nsqueezes past Tom and jumps into the front seat. They\nimmediately start quarreling. “Quiet!” commands Dad.\n“If you are going to squabble, I will turn this vehicle\naround and return home.”\nAfter they return from the library, Tom and Amy\nturn the TV on and start arguing about whose turn\nit is to pick the show. Dad asks whose turn it is. Tom\nand Amy both declare, “Mine!” When Dad tells Tom to\nselect the show, Amy complains it is an injustice.\nAfter dinner, Mom asks whose turn it is to wash the\ndishes. When Amy says, “His!” and Tom says, “Hers!”\nMom and Dad laugh.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who was born first, Amy or Tom?",
          "answer": "Amy.",
          "evidence": "Although Amy was born first,"
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who asked whose turn it was to wash the dishes?",
          "answer": "Mom.",
          "evidence": "After dinner, Mom asks whose turn it is to wash the dishes."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What did both twins shout when Dad asked whose turn it was to ride up front?",
          "answer": "“Mine!”",
          "evidence": "Dad asks whose turn it is to ride up front. Amy and Tom both shout, “Mine!”"
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What did Dad tell Tom to choose after the library trip?",
          "answer": "The TV show.",
          "evidence": "When Dad tells Tom to select the show, Amy complains it is an injustice."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did Amy and Tom turn on the TV?",
          "answer": "After they returned from the library.",
          "evidence": "After they return from the library, Tom and Amy turn the TV on"
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did Mom ask about washing the dishes?",
          "answer": "After dinner.",
          "evidence": "After dinner, Mom asks whose turn it is to wash the dishes."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where was Dad taking the twins in the minivan?",
          "answer": "To the library.",
          "evidence": "Dad asks the children whether they want to go to the library. Amy and Tom race to the minivan."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where did Amy sit in the minivan?",
          "answer": "In the front seat.",
          "evidence": "Amy squeezes past Tom and jumps into the front seat."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why did Dad threaten to turn the vehicle around and go home?",
          "answer": "The twins were quarreling.",
          "evidence": "If you are going to squabble, I will turn this vehicle around and return home."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why did Mom and Dad laugh at the end?",
          "answer": "Both children said the other one should wash the dishes instead of claiming that turn.",
          "evidence": "When Amy says, “His!” and Tom says, “Hers!” Mom and Dad laugh.",
          "accept": "Accept that each twin tried to give the dishwashing job to the other twin."
        }
      ]
    },
    {
      "id": "grade-3-benedict-arnold",
      "grade": 3,
      "title": "Benedict Arnold",
      "path": "HTMLs/Reading Fluency/3rd Grade Fluency/Benedict Arnold.html",
      "text": "Should we remember Benedict Arnold as a good \nguy or a bad guy? The answer is unclear. If Arnold \ncould undo his actions, would he?\nArnold started his career as an American fighter. \nAt that time, his primary aim was to end British rule. \nIn 1775 he helped to capture an important fort from \nthe British. Later that year, he led over a thousand \nsoldiers into Canada. Wounded in battle, he earned a \npromotion. For the next five years, the brave fighter \nserved in battle after battle. In 1777 he led a daring \nattack against the center of the British line at Saratoga.\nYet in 1780, this same fighter did an unlikely thing. \nHe plotted to hand West Point over to the British in \nexchange for money. What was his motive? People \nwho look back at history are unsure. Some say he grew \nresentful when he was passed over for a promotion. \nOthers say he was deeply in debt and had few friends.\nAfter his plot failed, Arnold escaped and joined \nthe British army. He fought openly against his country. \nHated in America and not trusted in England, he died \na lonely, poor, and unhappy man in 1801.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who led American soldiers into Canada in 1775?",
          "answer": "Benedict Arnold.",
          "evidence": "Later that year, he led over a thousand soldiers into Canada."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who controlled the fort before Arnold helped capture it?",
          "answer": "The British.",
          "evidence": "In 1775 he helped to capture an important fort from the British."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What was Arnold’s main aim when he started as an American fighter?",
          "answer": "To end British rule.",
          "evidence": "At that time, his primary aim was to end British rule."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What did Arnold plan to get in exchange for handing West Point to the British?",
          "answer": "Money.",
          "evidence": "He plotted to hand West Point over to the British in exchange for money."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did Arnold help capture the important fort?",
          "answer": "In 1775.",
          "evidence": "In 1775 he helped to capture an important fort from the British."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did Arnold plot to hand West Point to the British?",
          "answer": "In 1780.",
          "evidence": "Yet in 1780, this same fighter did an unlikely thing. He plotted to hand West Point over to the British"
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where did Arnold lead more than a thousand soldiers later in 1775?",
          "answer": "Into Canada.",
          "evidence": "Later that year, he led over a thousand soldiers into Canada."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where did Arnold lead an attack against the center of the British line in 1777?",
          "answer": "At Saratoga.",
          "evidence": "In 1777 he led a daring attack against the center of the British line at Saratoga."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why might Americans have hated Arnold after his plot failed?",
          "answer": "He joined the British army and fought against his own country.",
          "evidence": "After his plot failed, Arnold escaped and joined the British army. He fought openly against his country."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why might Arnold have wanted money, according to one explanation in the passage?",
          "answer": "He was deeply in debt.",
          "evidence": "Others say he was deeply in debt and had few friends.",
          "accept": "Accept that he owed a lot of money. The passage gives this as a possible explanation, not a proven motive."
        }
      ]
    },
    {
      "id": "grade-3-going-fishing",
      "grade": 3,
      "title": "Going Fishing",
      "path": "HTMLs/Reading Fluency/3rd Grade Fluency/Going Fishing.html",
      "text": "One sunny afternoon, Sam and his grandfather \nwent fishing. They walked through the woods to the \nedge of the lake. Sam found a log for them to sit on. \nHis grandfather set up their poles. Then they put \nworms on the hooks. While they sat on the log fishing, \nSam’s grandfather told interesting stories.\nSoon Sam had a bite on his line. He reeled the line \nin and caught his first fish. Sam was so excited that \nhe almost fell into the water. His grandfather helped \nhim get the fish off the hook and put it in the bucket \npromptly. Together they sat talking and fishing until \nhuge black clouds blocked the Sun.\n“Uh-oh, looks like a storm is coming,” said Sam’s \ngrandfather. He was about to suggest they leave when \nthunder rumbled in the distance. Rain was falling across \nthe lake.\nThey packed their things. As they walked back \nthrough the woods, the rain began to pour down. “This \nlooks serious!” said Sam’s grandfather.\nWhen they got to the car, they were soaking wet. \nSam was cold, but he was happy. He could appreciate \nthe time he spent fishing, even though it was short.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who caught his first fish?",
          "answer": "Sam.",
          "evidence": "He reeled the line in and caught his first fish."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who helped Sam take the fish off the hook?",
          "answer": "His grandfather.",
          "evidence": "His grandfather helped him get the fish off the hook and put it in the bucket promptly."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What did Sam and his grandfather put on their hooks?",
          "answer": "Worms.",
          "evidence": "Then they put worms on the hooks."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What blocked the Sun while Sam and his grandfather were fishing?",
          "answer": "Huge black clouds.",
          "evidence": "Together they sat talking and fishing until huge black clouds blocked the Sun."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did Sam and his grandfather go fishing?",
          "answer": "One sunny afternoon.",
          "evidence": "One sunny afternoon, Sam and his grandfather went fishing."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did they pack their things to leave?",
          "answer": "When a storm was coming and they could hear thunder and see rain.",
          "evidence": "thunder rumbled in the distance. Rain was falling across the lake. They packed their things.",
          "accept": "Accept when the storm approached, thunder rumbled, or rain was falling across the lake."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where did Sam and his grandfather go to fish?",
          "answer": "To the edge of the lake.",
          "evidence": "They walked through the woods to the edge of the lake."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where did they put Sam’s fish?",
          "answer": "In a bucket.",
          "evidence": "His grandfather helped him get the fish off the hook and put it in the bucket promptly."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why did Sam almost fall into the water?",
          "answer": "He was very excited about catching his first fish.",
          "evidence": "He reeled the line in and caught his first fish. Sam was so excited that he almost fell into the water."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why was Sam happy even though he was cold and wet?",
          "answer": "He enjoyed the time he had spent fishing.",
          "evidence": "Sam was cold, but he was happy. He could appreciate the time he spent fishing, even though it was short."
        }
      ]
    },
    {
      "id": "grade-3-jennys-game",
      "grade": 3,
      "title": "Jenny’s Game",
      "path": "HTMLs/Reading Fluency/3rd Grade Fluency/Jennys Game.html",
      "text": "Jenny was excited to become a member of the \nbaseball team. Most of the team hadn’t wanted a girl \nto join. But her cousin Roger was an influential member \nof the team. He knew that she was a great pitcher. So \nhe convinced the coach that her skill would help them \nwin games. His teammates still had their doubts.\nTonight after six innings, the team was behind. \nRoger urged the coach to let Jenny pitch. “What will \nthe other team think if we send a girl out to pitch?” \nJenny heard one player ask.\nJenny replied, “What will they think if I strike \nthem out?”\n“Give her a try!” another player called. Curiosity \nwas rising. The boys wanted to see what she would do. \nJenny wanted to show that they were wrong to think a \ngirl couldn’t pitch.\nWhen Jenny walked up to the pitcher’s mound, \nthere were jeers from her foes on the other team. She \nbounced on her feet and then blew on her knuckles. \nThen she braced her knees, twisted her wrist, and \nthrew her own special pitch. When Jenny struck out \nthe third player, her teammates cheered as she walked \nback to the dugout.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who helped convince the coach to let Jenny join the team?",
          "answer": "Her cousin Roger.",
          "evidence": "her cousin Roger was an influential member of the team. He knew that she was a great pitcher. So he convinced the coach"
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who cheered when Jenny walked back after striking out the third player?",
          "answer": "Her teammates.",
          "evidence": "When Jenny struck out the third player, her teammates cheered as she walked back to the dugout."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What baseball skill was Jenny especially good at?",
          "answer": "Pitching.",
          "evidence": "He knew that she was a great pitcher."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What did the players on the other team do when Jenny reached the pitcher’s mound?",
          "answer": "They jeered at her.",
          "evidence": "When Jenny walked up to the pitcher’s mound, there were jeers from her foes on the other team.",
          "accept": "Accept that they mocked her, made fun of her, or jeered."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did Roger urge the coach to let Jenny pitch?",
          "answer": "After six innings, when the team was behind.",
          "evidence": "Tonight after six innings, the team was behind. Roger urged the coach to let Jenny pitch."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did Jenny’s teammates cheer for her?",
          "answer": "When she struck out the third player.",
          "evidence": "When Jenny struck out the third player, her teammates cheered"
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where did Jenny go to throw her pitch?",
          "answer": "To the pitcher’s mound.",
          "evidence": "When Jenny walked up to the pitcher’s mound,"
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where did Jenny walk after striking out the third player?",
          "answer": "Back to the dugout.",
          "evidence": "her teammates cheered as she walked back to the dugout."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why did Roger think Jenny should be on the team?",
          "answer": "Her pitching skill could help the team win games.",
          "evidence": "He knew that she was a great pitcher. So he convinced the coach that her skill would help them win games."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why did Jenny want a chance to pitch?",
          "answer": "To show the boys they were wrong to think a girl could not pitch.",
          "evidence": "Jenny wanted to show that they were wrong to think a girl couldn’t pitch."
        }
      ]
    },
    {
      "id": "grade-3-la-brea-tar-pits",
      "grade": 3,
      "title": "La Brea Tar Pits",
      "path": "HTMLs/Reading Fluency/3rd Grade Fluency/La Brea Tar Pits.html",
      "text": "“Don’t touch that. It’s dirty and sticky!” Have your\nparents ever said that to you? Well maybe someone\nshould say that to a bunch of scientists in Los Angeles,\nCalifornia. Day in, day out, they spend their time\ndigging around in tar.\nWhat are these scientists doing? They are seeking\na special kind of bone—the bones of prehistoric\nanimals. The La Brea Tar Pits are located right in the\ncenter of Los Angeles. So far over one million bones\nhave been pulled from the pits. They include the bones\nof mammoths, giant sloths, dire wolves, saber-toothed\ncats, insects, and birds.\nNo one knows how these bones got there.\nScientists think that animals might have come bounding\ninto the pits. They would have gotten stuck in the tar\nand been unable to climb out. Eventually they died, and\ntheir bones settled in the tar.\nThe scientists have the responsibility of taking\ncare of the bones. They carefully clean them and sort\nthem into groups. These clever scientists also have\nways to date the bones they find. The oldest ones date\nback 46,800 years! From these bones, we are learning\nimportant things about the last Ice Age.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who digs in the tar to look for old animal bones?",
          "answer": "Scientists.",
          "evidence": "a bunch of scientists in Los Angeles, California. Day in, day out, they spend their time digging around in tar."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What kind of bones are the scientists looking for?",
          "answer": "The bones of prehistoric animals.",
          "evidence": "They are seeking a special kind of bone—the bones of prehistoric animals."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What are two kinds of animals whose bones have been found in the pits?",
          "answer": "Any two of: mammoths, giant sloths, dire wolves, saber-toothed cats, insects, or birds.",
          "evidence": "They include the bones of mammoths, giant sloths, dire wolves, saber-toothed cats, insects, and birds.",
          "accept": "Accept any two animals from the passage’s list."
        },
        {
          "id": "what-3",
          "type": "what",
          "question": "What is the age of the oldest bones mentioned in the passage?",
          "answer": "46,800 years old.",
          "evidence": "The oldest ones date back 46,800 years!"
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When do the scientists spend time digging in the tar?",
          "answer": "Day in, day out—day after day.",
          "evidence": "Day in, day out, they spend their time digging around in tar."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did the animals’ bones settle into the tar, according to the scientists’ idea?",
          "answer": "After the trapped animals died.",
          "evidence": "Eventually they died, and their bones settled in the tar."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where are the La Brea Tar Pits?",
          "answer": "In the center of Los Angeles, California.",
          "evidence": "The La Brea Tar Pits are located right in the center of Los Angeles.",
          "accept": "Accept Los Angeles; California may also be included."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where did the bones settle after the animals died?",
          "answer": "In the tar.",
          "evidence": "Eventually they died, and their bones settled in the tar."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why do scientists think the animals could not climb out?",
          "answer": "They became stuck in the tar.",
          "evidence": "They would have gotten stuck in the tar and been unable to climb out."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why are the old bones important to study?",
          "answer": "They help us learn about the last Ice Age.",
          "evidence": "From these bones, we are learning important things about the last Ice Age."
        }
      ]
    },
    {
      "id": "grade-3-mr-clark-s-class",
      "grade": 3,
      "title": "Mr. Clark’s Class",
      "path": "HTMLs/Reading Fluency/3rd Grade Fluency/Mr. Clark's Class.html",
      "text": "Mr. Clark’s class was excited today. Pets were \nallowed in school today! The children had brought \npuppies, cats, and a rabbit. There were also a lizard, \na snake, two hamsters, a turtle, and even a chicken. \nEach boy and girl wrote a story about his or her pet and \nread it aloud.\nSoon it was lunchtime. The children left the animals \nin the classroom. As soon as the door was closed, the \nanimals started to create turmoil. The puppies chased \nthe cats down an aisle. The hamsters and turtle began \neating the children’s work. One puppy tried to bury a \npencil. The rabbit knocked over some paint, and the \npaint spilled onto the lizard. The snake crawled into \nMr. Clark’s desk, and the chicken deliberately laid an \negg on top of it!\nWhen the class got back from lunch, the children \nsaw what the pets had done. Quickly they began \ncleaning up the mess. Just as they finished, Mr. Clark \nwalked back in. He pointed at the quiet animals and \nsaid, “I am really enjoying today. We can all take a \nlesson from your pets and be so well behaved.”",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who wrote and read stories about their pets?",
          "answer": "The children in Mr. Clark’s class.",
          "evidence": "Each boy and girl wrote a story about his or her pet and read it aloud.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who walked back into the classroom just after the children finished cleaning?",
          "answer": "Mr. Clark.",
          "evidence": "Just as they finished, Mr. Clark walked back in.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What did the chicken leave on top of Mr. Clark’s desk?",
          "answer": "An egg.",
          "evidence": "the chicken deliberately laid an egg on top of it!",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What did the hamsters and turtle begin eating?",
          "answer": "The children’s work.",
          "evidence": "The hamsters and turtle began eating the children’s work.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did the animals begin making a mess?",
          "answer": "As soon as the classroom door closed after the children left for lunch.",
          "evidence": "As soon as the door was closed, the animals started to create turmoil.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did the children begin cleaning up the mess?",
          "answer": "When they got back from lunch and saw what the pets had done.",
          "evidence": "When the class got back from lunch, the children saw what the pets had done. Quickly they began cleaning up the mess.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where did the snake crawl?",
          "answer": "Into Mr. Clark’s desk.",
          "evidence": "The snake crawled into Mr. Clark’s desk",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where did the spilled paint land?",
          "answer": "On the lizard.",
          "evidence": "The rabbit knocked over some paint, and the paint spilled onto the lizard.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why was Mr. Clark’s class excited that day?",
          "answer": "Pets were allowed at school.",
          "evidence": "Mr. Clark’s class was excited today. Pets were allowed in school today!",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why did Mr. Clark think the pets were well behaved?",
          "answer": "He saw them sitting quietly after the children had cleaned up.",
          "evidence": "He pointed at the quiet animals and said, “I am really enjoying today. We can all take a lesson from your pets and be so well behaved.”",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        }
      ]
    },
    {
      "id": "grade-3-pigeons",
      "grade": 3,
      "title": "Pigeons",
      "path": "HTMLs/Reading Fluency/3rd Grade Fluency/Pigeons.html",
      "text": "Another name for a pigeon is a rock dove. Pigeons \nbelong to the same bird family as doves. Doves are \nclean and very pretty. Pigeons are not.\nIn cities, pigeons often gather in parks and other \nplaces where people eat lunch. These pigeons are \nlooking for food. Sometimes people pull pieces of bread \noff loaves and feed them to the pigeons. This makes the \npigeons greedy, and they pester people for more food.\nOne type of pigeon is a homing pigeon. These \npigeons are helpful. People teach them to fly home from \nmany miles away. These remarkable birds can carry \nmessages or other possessions.\nAnother type is a passenger pigeon. Passenger \npigeons, like wolves, once were numerous in North \nAmerica. As people moved west, they hunted these \nhelpless creatures, and they rapidly started to die out. \nBy 1880 both were mostly gone from the wilderness.\nThe last passenger pigeon died in a zoo in 1914. \nIf people could have predicted that there would be no \nmore passenger pigeons, maybe they would not have \nhunted them.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who sometimes feeds bread to pigeons in the city?",
          "answer": "People.",
          "evidence": "Sometimes people pull pieces of bread off loaves and feed them to the pigeons.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who hunted passenger pigeons while moving west?",
          "answer": "People moving west.",
          "evidence": "As people moved west, they hunted these helpless creatures, and they rapidly started to die out.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What is another name for a pigeon?",
          "answer": "A rock dove.",
          "evidence": "Another name for a pigeon is a rock dove.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What can trained homing pigeons carry?",
          "answer": "Messages or other possessions.",
          "evidence": "These remarkable birds can carry messages or other possessions.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did the last passenger pigeon die?",
          "answer": "In 1914.",
          "evidence": "The last passenger pigeon died in a zoo in 1914.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "By what year were passenger pigeons and wolves mostly gone from the wilderness, according to the passage?",
          "answer": "By 1880.",
          "evidence": "By 1880 both were mostly gone from the wilderness.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where do city pigeons often gather?",
          "answer": "In parks and other places where people eat lunch.",
          "evidence": "In cities, pigeons often gather in parks and other places where people eat lunch.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where did the last passenger pigeon die?",
          "answer": "In a zoo.",
          "evidence": "The last passenger pigeon died in a zoo in 1914.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why do pigeons gather where people eat lunch?",
          "answer": "They are looking for food.",
          "evidence": "These pigeons are looking for food.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why did passenger pigeons begin dying out?",
          "answer": "People hunted them.",
          "evidence": "As people moved west, they hunted these helpless creatures, and they rapidly started to die out.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        }
      ]
    },
    {
      "id": "grade-3-pizza-party",
      "grade": 3,
      "title": "Pizza Party",
      "path": "HTMLs/Reading Fluency/3rd Grade Fluency/Pizza Party.html",
      "text": "The fans cheered wildly when Central’s basketball \nteam won their fifth game in a row. The team had \nstruggled all year, but now the team led its division. \nTeammates Shawn and Billy wanted to celebrate, so \nShawn’s father suggested everyone meet at their house \nfor pizza.\n“That’s an awesome idea, Mr. Potter!” Billy replied. \nWhile Shawn’s father went to get his minivan, the other \nteam members asked their parents for permission to \nattend the pizza party. Billy, Krista, and Jordan got \na ride with Mr. Potter. Everyone else rode with their \nparents or grandparents. On the way home, Mr. Potter \npicked up two large pizzas.\nNick and Ray arrived at Shawn’s house first. They \ncame with their grandfather, who was carrying two \nlarge cheese pizzas. Alex, Jamal, and Emma came \nnext. Each carried a large, flat box in his or her hands. The \nstrong aroma was unmistakable—sausage pizza.\n“What’s happening here?” Shawn’s father asked, \namazed at all the pizza boxes.\nShawn and his friends laughed. “We’re hungry, but \nnot that hungry!” they said.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who suggested meeting at Shawn’s house for pizza?",
          "answer": "Shawn’s father, Mr. Potter.",
          "evidence": "Shawn’s father suggested everyone meet at their house for pizza.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who brought the two large cheese pizzas?",
          "answer": "Nick and Ray’s grandfather.",
          "evidence": "They came with their grandfather, who was carrying two large cheese pizzas.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What had Central’s basketball team just accomplished?",
          "answer": "They won their fifth game in a row.",
          "evidence": "The fans cheered wildly when Central’s basketball team won their fifth game in a row.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What kind of pizza did Alex, Jamal, and Emma bring?",
          "answer": "Sausage pizza.",
          "evidence": "Each carried a large, flat box in his or her hands. The strong aroma was unmistakable—sausage pizza.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did the fans cheer wildly?",
          "answer": "When Central’s team won its fifth game in a row.",
          "evidence": "The fans cheered wildly when Central’s basketball team won their fifth game in a row.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did the other team members ask their parents for permission to attend the party?",
          "answer": "While Shawn’s father went to get his minivan.",
          "evidence": "While Shawn’s father went to get his minivan, the other team members asked their parents for permission to attend the pizza party.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where was the team going to have its pizza party?",
          "answer": "At Shawn’s house.",
          "evidence": "Shawn’s father suggested everyone meet at their house for pizza.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where were the flat pizza boxes as Alex, Jamal, and Emma arrived?",
          "answer": "In their hands.",
          "evidence": "Each carried a large, flat box in his or her hands.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why did Shawn and Billy want to celebrate?",
          "answer": "Their basketball team had won five games in a row and now led its division.",
          "evidence": "The team had struggled all year, but now the team led its division. Teammates Shawn and Billy wanted to celebrate",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why was Shawn’s father amazed when everyone arrived?",
          "answer": "So many people had brought pizza boxes.",
          "evidence": "“What’s happening here?” Shawn’s father asked, amazed at all the pizza boxes.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        }
      ]
    },
    {
      "id": "grade-3-symbols-of-freedom",
      "grade": 3,
      "title": "Symbols of Freedom",
      "path": "HTMLs/Reading Fluency/3rd Grade Fluency/Symbols of Freedom.html",
      "text": "How many kinds of eagles do you think live in the \nworld? If you guessed about sixty, you would be right. \nSome kinds of eagles are large. Some kinds are small. \nMost are strong for their size. Some are even strong \nenough to lift food that is almost as heavy as they are!\nEagles have been used as symbols of freedom in \nthe United States. Some people call them the “king of \nbirds.” This is because of their brave, proud looks. In \n1782, the United States officially chose the bald eagle \nto be on its Great Seal. From that point on, the bald \neagle has been recognized as the national bird of the \nUnited States. The bald eagle has had a great amount \nof publicity since then.\nBald eagles are large birds. They can weigh from \neight to thirteen pounds. Some eagles have wings that \nspread as much as seven feet across! Their heads are \ncovered with white feathers. The bald eagle is a very \ngood choice for our national bird.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who officially chose the bald eagle for the Great Seal?",
          "answer": "The United States.",
          "evidence": "In 1782, the United States officially chose the bald eagle to be on its Great Seal.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-3",
          "type": "what",
          "question": "What width can some eagles’ wings reach?",
          "answer": "As much as seven feet across.",
          "evidence": "Some eagles have wings that spread as much as seven feet across!",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What is the number of eagle kinds around the world?",
          "answer": "About sixty.",
          "evidence": "If you guessed about sixty, you would be right.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What covers a bald eagle’s head?",
          "answer": "White feathers.",
          "evidence": "Their heads are covered with white feathers.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did the United States choose the bald eagle for its Great Seal?",
          "answer": "In 1782.",
          "evidence": "In 1782, the United States officially chose the bald eagle to be on its Great Seal.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did the bald eagle begin receiving a great deal of publicity?",
          "answer": "After it was chosen for the Great Seal and recognized as the national bird.",
          "evidence": "From that point on, the bald eagle has been recognized as the national bird of the United States. The bald eagle has had a great amount of publicity since then.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where have eagles been used as symbols of freedom?",
          "answer": "In the United States.",
          "evidence": "Eagles have been used as symbols of freedom in the United States.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where was the bald eagle officially chosen to appear?",
          "answer": "On the United States’ Great Seal.",
          "evidence": "In 1782, the United States officially chose the bald eagle to be on its Great Seal.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why do some people call eagles the “king of birds”?",
          "answer": "Because of their brave, proud looks.",
          "evidence": "This is because of their brave, proud looks.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why can some eagles lift food almost as heavy as themselves?",
          "answer": "They are very strong for their size.",
          "evidence": "Most are strong for their size. Some are even strong enough to lift food that is almost as heavy as they are!",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        }
      ]
    },
    {
      "id": "grade-3-the-busy-night",
      "grade": 3,
      "title": "The Busy Night",
      "path": "HTMLs/Reading Fluency/3rd Grade Fluency/The Busy Night.html",
      "text": "My friends and I have a band called The Singing \nCubs, and we’re going to perform in the school talent \nshow. I’m Bobby, the group’s lead guitar player and \nsinger. Kim also plays the guitar, and Ralph is our \ndrummer.\nThe day before the show, the principal made an \nannouncement. All assignments had to be turned in first \nthing in the morning for those students performing in \nthe show. We knew it would be a busy night.\nFirst Ralph’s parents demanded that he clean up \nhis messy room or skip the show. Then to make matters \nworse, my mother got sick, and I had to help with \ndinner. I cooked, served, and cleaned up. Eventually \ndinner was over, and I started my homework.\nJust as I finished my book report, Ralph called. \nI could hear the frustration in his voice. “There’s no way \nI can get my room clean tonight,” he complained. Both \nKim and I dashed over to Ralph’s house. We worked on \nhis room until it was spotless. Nothing would put our \nperformance in jeopardy!\nWhen it came time to perform the next day, \nwe were exhausted. But we were also very proud of \nourselves",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who is the band’s lead guitar player and singer?",
          "answer": "Bobby.",
          "evidence": "I’m Bobby, the group’s lead guitar player and singer.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who is the band’s drummer?",
          "answer": "Ralph.",
          "evidence": "Kim also plays the guitar, and Ralph is our drummer.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What is the name of the friends’ band?",
          "answer": "The Singing Cubs.",
          "evidence": "My friends and I have a band called The Singing Cubs",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What did Bobby do to help with dinner?",
          "answer": "He cooked, served, and cleaned up.",
          "evidence": "I cooked, served, and cleaned up.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did performers have to turn in all their assignments?",
          "answer": "First thing in the morning, before the show.",
          "evidence": "All assignments had to be turned in first thing in the morning for those students performing in the show.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did Ralph call Bobby?",
          "answer": "Just as Bobby finished his book report.",
          "evidence": "Just as I finished my book report, Ralph called.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where was the talent show going to take place?",
          "answer": "At school.",
          "evidence": "we’re going to perform in the school talent show.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where did Bobby and Kim go to help clean?",
          "answer": "To Ralph’s house, to clean his room.",
          "evidence": "Both Kim and I dashed over to Ralph’s house. We worked on his room until it was spotless.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why did Ralph need to clean his room that night?",
          "answer": "His parents said he had to clean it or skip the show.",
          "evidence": "First Ralph’s parents demanded that he clean up his messy room or skip the show.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why did Bobby and Kim help clean Ralph’s room?",
          "answer": "They wanted to make sure their band could perform.",
          "evidence": "We worked on his room until it was spotless. Nothing would put our performance in jeopardy!",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        }
      ]
    },
    {
      "id": "grade-3-the-land-of-the-midnight-sun",
      "grade": 3,
      "title": "The Land of the Midnight Sun",
      "path": "HTMLs/Reading Fluency/3rd Grade Fluency/The Land of the Midnight Sun.html",
      "text": "Iceland is a country that is also a large island. It \nis a great place to see. It is very far north in the North \nAtlantic Ocean. In the winter, it is very dark. There is \ndaylight for only four to six hours a day. But for about \nthree months in summer, it doesn’t get dark at all. \nThat is why some people call Iceland “the land of the \nmidnight Sun.”\nEven though Iceland is very far north, it is not \nas cold as you might think. Most people in Iceland \nlive near the sea. Warm winds from the sea help to \nkeep the land from getting very cold. The summers \nin Iceland are cool, too. It feels more like spring than \nthe hot summers we are used to in the United States. \nIceland is a wonderful place to visit. It is very pretty, \nand many animals live there, including foxes, rabbits, \nand reindeer. You should think about going to see this \nisland soon!",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who lives near the sea in Iceland?",
          "answer": "Most people in Iceland.",
          "evidence": "Most people in Iceland live near the sea.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-3",
          "type": "what",
          "question": "What does a summer in Iceland feel like?",
          "answer": "Cool, more like spring.",
          "evidence": "The summers in Iceland are cool, too. It feels more like spring than the hot summers we are used to in the United States.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What is Iceland besides being a country?",
          "answer": "A large island.",
          "evidence": "Iceland is a country that is also a large island.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What are two kinds of animals that live in Iceland?",
          "answer": "Any two of foxes, rabbits, and reindeer.",
          "evidence": "many animals live there, including foxes, rabbits, and reindeer.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When does Iceland have daylight for only four to six hours a day?",
          "answer": "In winter.",
          "evidence": "In the winter, it is very dark. There is daylight for only four to six hours a day.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When does Iceland stay light all day and night for about three months?",
          "answer": "In summer.",
          "evidence": "But for about three months in summer, it doesn’t get dark at all.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where is Iceland?",
          "answer": "Far north in the North Atlantic Ocean.",
          "evidence": "It is very far north in the North Atlantic Ocean.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where do the warm winds that help Iceland come from?",
          "answer": "From the sea.",
          "evidence": "Warm winds from the sea help to keep the land from getting very cold.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why is Iceland called “the land of the midnight Sun”?",
          "answer": "Because it does not get dark for about three months in summer.",
          "evidence": "But for about three months in summer, it doesn’t get dark at all.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why is Iceland not as cold as someone might expect?",
          "answer": "Warm winds from the sea keep the land from getting very cold.",
          "evidence": "Warm winds from the sea help to keep the land from getting very cold.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        }
      ]
    },
    {
      "id": "grade-3-the-mouse-house",
      "grade": 3,
      "title": "The Mouse House",
      "path": "HTMLs/Reading Fluency/3rd Grade Fluency/The Mouse House.html",
      "text": "Mrs. Hill told the students to “build a better mouse \nhouse.” It needed to be simple but practical. After I \nthought about the design for a few minutes, I decided \nto use an empty carton my mother had thrown out. \nFirst I cut little air holes in the top for my mouse, Jim. \nThey were big enough to let in plenty of air but not so \nbig that he could escape through one. Next I cut out a \ndoor for the house and added water and food dishes \nand some comfortable rags for his bed.\nI placed my pet mouse into his new house and \nbrought my mouse house to school. The class was quiet \nas Mrs. Hill walked around the room. She carefully \nexamined all of the houses. When she came to mine, \nshe opened the door. Out leaped Jim! He landed on \nthe floor and scampered under her desk. I suddenly \nrealized that I was the only one who had brought a \nreal mouse!\nAll the students tried to catch Jim, but Mrs. Hill was \nthe one who caught him. She said that both Jim and \nmy mouse house were terrific.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who asked the students to build a better mouse house?",
          "answer": "Mrs. Hill.",
          "evidence": "Mrs. Hill told the students to “build a better mouse house.”",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who caught Jim after he escaped?",
          "answer": "Mrs. Hill.",
          "evidence": "All the students tried to catch Jim, but Mrs. Hill was the one who caught him.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What did the student use to make the mouse house?",
          "answer": "An empty carton the student’s mother had thrown out.",
          "evidence": "I decided to use an empty carton my mother had thrown out.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What did the student use for Jim’s bed?",
          "answer": "Comfortable rags.",
          "evidence": "added water and food dishes and some comfortable rags for his bed.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did Jim leap out of his house?",
          "answer": "When Mrs. Hill opened the door.",
          "evidence": "she opened the door. Out leaped Jim!",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did the student realize that no one else had brought a real mouse?",
          "answer": "After Jim escaped and ran under Mrs. Hill’s desk.",
          "evidence": "He landed on the floor and scampered under her desk. I suddenly realized that I was the only one who had brought a real mouse!",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where did Jim run after landing on the floor?",
          "answer": "Under Mrs. Hill’s desk.",
          "evidence": "He landed on the floor and scampered under her desk.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where did the student cut the air holes?",
          "answer": "In the top of the carton.",
          "evidence": "First I cut little air holes in the top for my mouse, Jim.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why did the student make small air holes in the carton?",
          "answer": "To let air in without letting Jim escape.",
          "evidence": "They were big enough to let in plenty of air but not so big that he could escape through one.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why did the students try to catch Jim?",
          "answer": "He had escaped from the mouse house and was running around the classroom.",
          "evidence": "He landed on the floor and scampered under her desk.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        }
      ]
    },
    {
      "id": "grade-3-the-quick-save",
      "grade": 3,
      "title": "The Quick Save",
      "path": "HTMLs/Reading Fluency/3rd Grade Fluency/The Quick Save.html",
      "text": "Robert floated lazily on his back and thought how \ngood it felt to gaze at the perfectly blue sky as the \nafternoon sun warmed his skin. He let the gentle ocean \nwaves push him toward the shore, just a few yards \naway, where swimmers splashed in the surf.\nSuddenly, a shout interrupted his thoughts. He \ntried to ignore it, but the panic in the voice made this \nimpossible. “Help, please help! Somebody help her!” \na woman frantically screamed.\n“She needs help!” someone yelled. At first \nRobert’s brain wouldn’t function, so he couldn’t tell \nwhat was happening. As his toes touched the sand, \nhe heard his sister Anna’s urgent voice. “She’s over \nthere, Robert! Get her!” Anna was pointing to the \nwaves nearby.\nLooking around quickly, Robert watched as a child \nstruggled to keep her head above water. Without \nanother thought, he dove and reached for her. His \nfingers soon closed around a tiny arm. Grasping the girl \nwith strong hands, Robert lifted her out of the water. \nHis only thought now was for her safety. She coughed \nand then began to cry. With relief, Robert knew this \nmeant she would be all right.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who pulled the struggling child out of the water?",
          "answer": "Robert.",
          "evidence": "Grasping the girl with strong hands, Robert lifted her out of the water.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who pointed Robert toward the child in the waves?",
          "answer": "His sister Anna.",
          "evidence": "he heard his sister Anna’s urgent voice. “She’s over there, Robert! Get her!” Anna was pointing to the waves nearby.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What was the child struggling to do?",
          "answer": "Keep her head above water.",
          "evidence": "Robert watched as a child struggled to keep her head above water.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What did the girl do after Robert lifted her out of the water?",
          "answer": "She coughed and then began to cry.",
          "evidence": "She coughed and then began to cry.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When in the day was Robert floating in the ocean?",
          "answer": "In the afternoon.",
          "evidence": "the afternoon sun warmed his skin.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did Robert hear Anna calling urgently?",
          "answer": "As his toes touched the sand.",
          "evidence": "As his toes touched the sand, he heard his sister Anna’s urgent voice.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where was Robert floating at the beginning of the story?",
          "answer": "In the ocean, a few yards from shore.",
          "evidence": "He let the gentle ocean waves push him toward the shore, just a few yards away",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where was the girl who needed help?",
          "answer": "In the waves nearby.",
          "evidence": "Anna was pointing to the waves nearby.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why could Robert not keep ignoring the shout?",
          "answer": "He heard panic in the voice.",
          "evidence": "He tried to ignore it, but the panic in the voice made this impossible.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why did Robert feel relieved when the girl coughed and cried?",
          "answer": "He knew those signs meant she would be all right.",
          "evidence": "She coughed and then began to cry. With relief, Robert knew this meant she would be all right.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        }
      ]
    },
    {
      "id": "grade-3-trip-to-the-north-pole",
      "grade": 3,
      "title": "Trip to the North Pole",
      "path": "HTMLs/Reading Fluency/3rd Grade Fluency/Trip To the North Pole.html",
      "text": "In the Far North, a group of men struggled \nagainst frigid wind. It was sixty degrees below zero! \nThe explorers wore thick fur parkas, gloves, and boots. \nSome thought they were fools and should go back. But \nRobert Peary and Matthew Henson wanted to be the \nfirst to reach the North Pole, so they pressed on.\nBefore 1909, no one had ever been to the North \nPole. In the Far North, it is light for six months and dark \nfor six months. The team could not cross the ice in the \ndark. But it would not help to wait too long to leave. \nThe summer Sun could melt the ice on the team’s way \nback. The ice in the Arctic often has cracks. They are \ncaused by Earth’s movement and the pull of the Moon’s \ngravity. The ice cracks could split open at any time, \nplunging the men into the freezing water.\nPeary and Henson had tried to reach the North Pole \ntwice before. Both times they had been beaten by the \nfreezing winds, huge blocks of ice, and starvation. Could \nthey make it this time? From their viewpoint, they would \nnot have another chance.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who wanted to be the first to reach the North Pole?",
          "answer": "Robert Peary and Matthew Henson.",
          "evidence": "Robert Peary and Matthew Henson wanted to be the first to reach the North Pole",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-3",
          "type": "what",
          "question": "What could the summer Sun do to the ice on the team’s way back?",
          "answer": "Melt the ice.",
          "evidence": "The summer Sun could melt the ice on the team’s way back.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What did the explorers wear against the cold?",
          "answer": "Thick fur parkas, gloves, and boots.",
          "evidence": "The explorers wore thick fur parkas, gloves, and boots.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What causes cracks in the Arctic ice, according to the passage?",
          "answer": "Earth’s movement and the pull of the Moon’s gravity.",
          "evidence": "They are caused by Earth’s movement and the pull of the Moon’s gravity.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When could the team not cross the ice?",
          "answer": "During the dark part of the year.",
          "evidence": "In the Far North, it is light for six months and dark for six months. The team could not cross the ice in the dark.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When could the cracks in the ice split open?",
          "answer": "At any time.",
          "evidence": "The ice cracks could split open at any time",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where were Peary and Henson trying to go?",
          "answer": "To the North Pole.",
          "evidence": "Robert Peary and Matthew Henson wanted to be the first to reach the North Pole",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where does the ice often have cracks?",
          "answer": "In the Arctic.",
          "evidence": "The ice in the Arctic often has cracks.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why did Peary and Henson keep going in the terrible cold?",
          "answer": "They wanted to be the first to reach the North Pole.",
          "evidence": "Robert Peary and Matthew Henson wanted to be the first to reach the North Pole, so they pressed on.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why had the two earlier attempts failed?",
          "answer": "Freezing winds, huge blocks of ice, and starvation stopped them.",
          "evidence": "Both times they had been beaten by the freezing winds, huge blocks of ice, and starvation.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        }
      ]
    },
    {
      "id": "grade-3-two-ground-birds",
      "grade": 3,
      "title": "Two Ground Birds",
      "path": "HTMLs/Reading Fluency/3rd Grade Fluency/Two Ground Birds.html",
      "text": "Have you ever seen the Road Runner in a cartoon?\nA roadrunner is a real bird. Unlike many birds, \nroadrunners prefer running to flying. There are other \ndesert birds that prefer the ground to the air, too. One \nof these is the Gambel’s quail. Let’s take a closer look at \nthese two ground birds.\nRoadrunners live throughout the Southwest. These \nbirds are not easily intimidated. They can run at speeds \nof fifteen miles per hour or more. From their head to \ntheir long tail, they can grow to twenty-two inches. Like \nmany birds, they eat spiders and insects. They also eat \nlizards, snakes, and the eggs of other birds.\nQuails also live mainly on the ground. They build \ntheir nests and look for food there. The Gambel’s quail, \nlike the roadrunner, lives in the Southwest. However, its \nrange does not go as far into Texas as the roadrunner’s. \nThis quail grows to about ten inches long. Like other \nquails, it has a short tail. It also has a pretty reddish \nhead and a black plume that curls toward its face. \nQuails eat mainly seeds, berries, grasses, and leaves, \nbut some species can eat insects or eggs.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who can run at fifteen miles an hour or more?",
          "answer": "Roadrunners.",
          "evidence": "These birds are not easily intimidated. They can run at speeds of fifteen miles per hour or more.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who has a reddish head and a black plume that curls toward its face?",
          "answer": "The Gambel’s quail.",
          "evidence": "It also has a pretty reddish head and a black plume that curls toward its face.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What is one of the roadrunner’s foods besides spiders and insects?",
          "answer": "Any one of lizards, snakes, or other birds’ eggs.",
          "evidence": "They also eat lizards, snakes, and the eggs of other birds.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What do quails mainly eat?",
          "answer": "Seeds, berries, grasses, and leaves.",
          "evidence": "Quails eat mainly seeds, berries, grasses, and leaves",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-3",
          "type": "what",
          "question": "What length can a roadrunner grow to?",
          "answer": "About twenty-two inches.",
          "evidence": "From their head to their long tail, they can grow to twenty-two inches.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When are quails on the ground, according to the passage?",
          "answer": "When they build their nests and look for food.",
          "evidence": "Quails also live mainly on the ground. They build their nests and look for food there.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where do both roadrunners and Gambel’s quails live?",
          "answer": "In the Southwest.",
          "evidence": "The Gambel’s quail, like the roadrunner, lives in the Southwest.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-4",
          "type": "what",
          "question": "What is the length of a Gambel’s quail when it is grown?",
          "answer": "About ten inches.",
          "evidence": "This quail grows to about ten inches long.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why does the passage call these birds ground birds?",
          "answer": "They prefer the ground to the air or prefer running to flying.",
          "evidence": "roadrunners prefer running to flying. There are other desert birds that prefer the ground to the air, too.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why could their tails help someone tell a roadrunner and a quail apart?",
          "answer": "A roadrunner has a long tail, while a quail has a short tail.",
          "evidence": "Like other quails, it has a short tail.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        }
      ]
    },
    {
      "id": "grade-3-volcano",
      "grade": 3,
      "title": "Volcano",
      "path": "HTMLs/Reading Fluency/3rd Grade Fluency/Volcano.html",
      "text": "We can walk on Earth’s outside layer, called the \ncrust, without burning our feet. But the temperature \ninside the earth is incredibly hot. It’s hot enough to \nmelt rock!\nAs rock below the surface melts, it forms \nunderground pools. Eventually, solid rock squeezes the \npools from all sides. Heat and pressure start to build.\nThe melted rock pushes in an upward motion and \nshoots through a fracture in Earth’s crust. As the rock \ncools on the surface, it forms a mound. The mound \nbuilds as more melted rock pushes out. Over time a \nhuge mountain, called a volcano, is formed.\nA volcano might look like any other mountain, but \nit is very different. The pool of melted rock remains \nbelow the surface. In time heat and pressure can build \nup again. Before long the hot melted rock and gases \nexplode out of the mountain. The volcano is erupting. \nTry to get a mental picture of flaming liquid rock \nshooting out of a mountain. It is truly an amazing sight! \nBut if you want to personally view an eruption, you \nshould do so from a distance. Volcanic eruptions can \nbe extremely dangerous, destroying everything in \ntheir path.",
      "questions": [
        {
          "id": "what-3",
          "type": "what",
          "question": "What can form over time as more melted rock pushes out?",
          "answer": "A huge mountain called a volcano.",
          "evidence": "The mound builds as more melted rock pushes out. Over time a huge mountain, called a volcano, is formed.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who is warned to watch a volcanic eruption from a distance?",
          "answer": "Anyone who wants to view an eruption.",
          "evidence": "if you want to personally view an eruption, you should do so from a distance.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What is Earth’s outside layer called?",
          "answer": "The crust.",
          "evidence": "We can walk on Earth’s outside layer, called the crust",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What forms when rock below Earth’s surface melts?",
          "answer": "Underground pools of melted rock.",
          "evidence": "As rock below the surface melts, it forms underground pools.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When does melted rock begin forming a mound on the surface?",
          "answer": "As it cools.",
          "evidence": "As the rock cools on the surface, it forms a mound.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When can a volcano erupt again?",
          "answer": "When heat and pressure build up again.",
          "evidence": "In time heat and pressure can build up again. Before long the hot melted rock and gases explode out of the mountain.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where do the pools of melted rock form?",
          "answer": "Underground, below Earth’s surface.",
          "evidence": "As rock below the surface melts, it forms underground pools.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where does melted rock shoot through to reach the surface?",
          "answer": "Through a fracture in Earth’s crust.",
          "evidence": "The melted rock pushes in an upward motion and shoots through a fracture in Earth’s crust.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why does the melted rock begin pushing upward?",
          "answer": "Heat and pressure build up as solid rock squeezes the pools.",
          "evidence": "Eventually, solid rock squeezes the pools from all sides. Heat and pressure start to build.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why should people view an eruption from far away?",
          "answer": "Eruptions can be very dangerous and destroy things in their path.",
          "evidence": "Volcanic eruptions can be extremely dangerous, destroying everything in their path.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        }
      ]
    },
    {
      "id": "grade-3-wilma-rudolph",
      "grade": 3,
      "title": "Wilma Rudolph",
      "path": "HTMLs/Reading Fluency/3rd Grade Fluency/Wilma Rudolph.html",
      "text": "Wilma Rudolph is a distinguished track star. She \nwas the first American woman to win three gold medals \nin a single Olympics. She also received many honors of \ngreat significance. One honor was the Sullivan Award \nas the country’s top amateur athlete.\nAt the age of four, Wilma was stricken with polio. \nShe survived, but doctors said she would never walk \nagain. Yet Wilma would not give up, and she worked \nintently to beat the odds. By the time she was eight, she \ncould walk with a leg brace. At the age of eleven, she \nput aside her leg brace for good. She went on to play \nbasketball and run on the track team in high school \nand college.\nAt the 1960 Olympic Games, Wilma was the star \nof the American team. She won gold medals and set \nworld records in three events—the 100-meter dash, the \n200-meter dash, and the 400-meter relay.\nWilma later became a coach and a teacher. She \nalso wrote a book about her life. In it she told of the \nobstacles she had to overcome in her life. This very \nremarkable woman should be an inspiration to all \nAmericans and to athletes everywhere.",
      "questions": [
        {
          "id": "who-1",
          "type": "who",
          "question": "Who was the first American woman to win three gold medals in one Olympics?",
          "answer": "Wilma Rudolph.",
          "evidence": "She was the first American woman to win three gold medals in a single Olympics.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "who-2",
          "type": "who",
          "question": "Who said Wilma would never walk again?",
          "answer": "Doctors.",
          "evidence": "She survived, but doctors said she would never walk again.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-1",
          "type": "what",
          "question": "What jobs did Wilma have later in life?",
          "answer": "She became a coach and a teacher.",
          "evidence": "Wilma later became a coach and a teacher.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "what-2",
          "type": "what",
          "question": "What three events did Wilma win at the 1960 Olympics?",
          "answer": "The 100-meter dash, 200-meter dash, and 400-meter relay.",
          "evidence": "She won gold medals and set world records in three events—the 100-meter dash, the 200-meter dash, and the 400-meter relay.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-1",
          "type": "when",
          "question": "When did Wilma become sick with polio?",
          "answer": "At age four.",
          "evidence": "At the age of four, Wilma was stricken with polio.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "when-2",
          "type": "when",
          "question": "When did Wilma stop using her leg brace for good?",
          "answer": "At age eleven.",
          "evidence": "At the age of eleven, she put aside her leg brace for good.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-1",
          "type": "where",
          "question": "Where did Wilma play basketball and run on a track team?",
          "answer": "In high school and college.",
          "evidence": "She went on to play basketball and run on the track team in high school and college.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "where-2",
          "type": "where",
          "question": "Where did Wilma tell about the obstacles in her life?",
          "answer": "In a book she wrote about her life.",
          "evidence": "She also wrote a book about her life. In it she told of the obstacles she had to overcome in her life.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-1",
          "type": "why",
          "question": "Why did Wilma receive the Sullivan Award?",
          "answer": "She was the country’s top amateur athlete.",
          "evidence": "One honor was the Sullivan Award as the country’s top amateur athlete.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        },
        {
          "id": "why-2",
          "type": "why",
          "question": "Why does the passage say Wilma can inspire others?",
          "answer": "She overcame serious challenges and kept working instead of giving up.",
          "evidence": "Yet Wilma would not give up, and she worked intently to beat the odds.",
          "accept": "Accept a response with the same meaning; exact wording is not required."
        }
      ]
    }
  ]
});
