(() => {
  'use strict';
  const LEVELS=Object.freeze({tens:Object.freeze({label:'Tens (2 digits)',min:10,max:99}),hundreds:Object.freeze({label:'Hundreds (3 digits)',min:100,max:999}),thousands:Object.freeze({label:'Thousands (4 digits)',min:1000,max:9999})});
  function validateLevels(values){
    if(!Array.isArray(values)||!values.length||values.some(value=>!Object.prototype.hasOwnProperty.call(LEVELS,value)))throw new Error('Choose at least one number level.');
    return Object.keys(LEVELS).filter(value=>values.includes(value));
  }
  function splitNumber(value){
    if(!Number.isInteger(value)||value<10||value>9999)throw new Error('Choose a number from 10 through 9,999.');
    const digits=String(value).split('').map(Number),terms=[];let zeroPlaces=0;
    digits.forEach((digit,index)=>{if(digit)terms.push(digit*10**(digits.length-index-1));else zeroPlaces++;});
    return{terms,zeroPlaces};
  }
  const groupedInteger=/^(?:\d{1,3}(?:,\d{3})+|\d+)$/;
  function parseInteger(text){if(!groupedInteger.test(text))return null;const value=Number(text.replaceAll(',',''));return Number.isSafeInteger(value)?value:null;}
  function parseExpanded(raw){
    const text=String(raw??'').trim();
    if(!text||text.length>160)return{valid:false,terms:[]};
    const sides=text.split('=');if(sides.length>2)return{valid:false,terms:[]};
    let left=null,right=text;
    if(sides.length===2){left=parseInteger(sides[0].trim());right=sides[1].trim();if(left===null)return{valid:false,terms:[]};}
    const pieces=right.split('+').map(part=>part.trim()),terms=pieces.map(parseInteger);
    if(!pieces.length||pieces.length>12||terms.some(value=>value===null))return{valid:false,terms:[]};
    return{valid:true,terms,left};
  }
  function gradeExpanded(value,raw){
    const parsed=parseExpanded(raw);if(!parsed.valid)return{valid:false,correct:false,terms:[]};
    const expected=splitNumber(value),positive=parsed.terms.filter(term=>term!==0).sort((a,b)=>b-a),zeros=parsed.terms.length-positive.length;
    const correct=(parsed.left===null||parsed.left===value)&&zeros<=expected.zeroPlaces&&positive.length===expected.terms.length&&positive.every((term,index)=>term===expected.terms[index]);
    return{valid:true,correct,terms:parsed.terms.slice()};
  }
  function formatExpanded(value){return splitNumber(value).terms.map(term=>term.toLocaleString('en-US')).join(' + ');}
  function shuffled(items,random){const out=items.slice();for(let i=out.length-1;i>0;i--){const fraction=Math.max(0,Math.min(.9999999999999999,Number(random())||0)),j=Math.floor(fraction*(i+1));[out[i],out[j]]=[out[j],out[i]];}return out;}
  function createGenerator(values,random=Math.random){
    const levels=validateLevels(values),numberBags=new Map();let levelBag=[],lastNumber=null;
    return Object.freeze({next(){
      if(!levelBag.length)levelBag=shuffled(levels,random);
      const level=levelBag.pop(),spec=LEVELS[level];let numbers=numberBags.get(level);
      if(!numbers?.length){numbers=shuffled(Array.from({length:spec.max-spec.min+1},(_,i)=>spec.min+i),random);if(numbers.length>1&&numbers[numbers.length-1]===lastNumber)[numbers[0],numbers[numbers.length-1]]=[numbers[numbers.length-1],numbers[0]];numberBags.set(level,numbers);}
      const number=numbers.pop();lastNumber=number;return{number,level,expected:formatExpanded(number),terms:splitNumber(number).terms};
    }});
  }
  function insertPlus(value,start,end){
    const text=String(value??''),from=Number.isInteger(start)?Math.max(0,Math.min(text.length,start)):text.length,to=Number.isInteger(end)?Math.max(from,Math.min(text.length,end)):from;
    return{text:text.slice(0,from)+' + '+text.slice(to),caret:from+3};
  }
  window.BeardExpandedForm=Object.freeze({levels:LEVELS,validateLevels,splitNumber,parseExpanded,gradeExpanded,formatExpanded,createGenerator,insertPlus});
  if(typeof document==='undefined'||!document.getElementById('placeChoices'))return;
  const $=id=>document.getElementById(id),answer=$('answer'),summary=$('summary'),feedback=$('feedback'),boxes=[...document.querySelectorAll('input[name="placeLevel"]')];
  let generator=null,current=null,active=false,locked=true,startedAt=null,questionAt=null,stoppedSeconds=0,stoppedDate=null,history=[],attempts=0,correct=0,timer=null,nextTimer=null;
  const random=()=>window.BeardRun?.random?.()??Math.random(),escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function selection(){return boxes.filter(box=>box.checked).map(box=>box.value);}
  function level(){return 'Expanded form · '+selection().map(key=>LEVELS[key].label).join(', ');}
  function elapsed(){return active?Math.max(0,(Date.now()-startedAt)/1000):stoppedSeconds;}
  function stats(){$('attempts').textContent='Attempts: '+attempts;$('attempts').dataset.beardCorrect=String(correct);$('score').textContent='Score: '+(attempts?Math.round(correct/attempts*100):0)+'%';}
  function cancelTimers(){clearTimeout(nextTimer);nextTimer=null;clearInterval(timer);timer=null;}
  function problemText(row){return 'Write '+row.number.toLocaleString('en-US')+' in expanded form.';}
  function next(){
    if(!active)return false;clearTimeout(nextTimer);nextTimer=null;current=generator.next();locked=false;questionAt=Date.now();
    $('problem').textContent=current.number.toLocaleString('en-US');$('problem').dataset.beardProblem=problemText(current);$('problem').setAttribute('aria-label',problemText(current));answer.value='';answer.disabled=false;answer.removeAttribute('aria-invalid');$('insertPlus').disabled=false;$('submitBtn').disabled=false;$('nextBtn').disabled=true;feedback.textContent='';feedback.className='';$('answerHelp').textContent='Use one value for each nonzero place. You may leave out empty (zero) places. Use the + button if you need it.';
    if(window.matchMedia?.('(pointer:fine)').matches)answer.focus({preventScroll:true});return true;
  }
  function respond(){
    if(!active||locked||!current)return false;const raw=answer.value.trim(),result=gradeExpanded(current.number,raw);
    if(!result.valid){answer.setAttribute('aria-invalid','true');$('answerHelp').textContent='Use whole numbers separated by +. Commas in thousands are optional. Do not use letters, decimals, or other signs.';return false;}
    locked=true;answer.removeAttribute('aria-invalid');attempts++;if(result.correct)correct++;
    history.push({problem:problemText(current),answer:raw,expected:current.expected,number:current.number,numberLevel:current.level,terms:result.terms,correct:result.correct,outcome:result.correct,seconds:Math.max(0,(Date.now()-questionAt)/1000),elapsedSeconds:elapsed()});
    answer.disabled=true;$('insertPlus').disabled=true;$('submitBtn').disabled=true;$('nextBtn').disabled=false;stats();feedback.textContent=result.correct?'Correct!':'Incorrect. Expanded form: '+current.expected+'.';feedback.className=result.correct?'good':'bad';nextTimer=setTimeout(next,750);return true;
  }
  function addPlus(){if(!active||locked||answer.disabled)return;const inserted=insertPlus(answer.value,answer.selectionStart,answer.selectionEnd);answer.value=inserted.text;answer.focus({preventScroll:true});answer.setSelectionRange?.(inserted.caret,inserted.caret);}
  function state(){return{assessment:document.title,skill:'Expanded form',level:level(),active,attempts,correct,errors:attempts-correct,seconds:elapsed(),date:stoppedDate?.toISOString(),scoreType:'Accuracy',score:attempts?correct/attempts:null,percentage:attempts?Math.round(correct/attempts*100):null,pending:false,selectedLevels:selection(),supports:'Number levels: '+selection().map(key=>LEVELS[key].label).join(', '),current:current?{...current,problem:problemText(current),terms:current.terms.slice()}:null,responses:history.map(row=>({...row,terms:row.terms.slice()}))};}
  function renderReport(){
    summary.innerHTML='<h2>Expanded Form Results</h2><p><strong>'+escape(stoppedDate.toLocaleDateString())+' · '+(attempts?Math.round(correct/attempts*100)+'%':'No responses')+'</strong><br>'+escape(level())+'<br>Correct: '+correct+' / '+attempts+' · Total time: '+stoppedSeconds.toFixed(1)+' seconds</p><div class="expanded-result-cards">'+history.map((row,index)=>'<article class="expanded-result-card" data-beard-response-index="'+index+'" tabindex="0" role="button" title="Right-click to switch Correct / Incorrect"><span>'+(index+1)+'. '+escape(row.problem)+'</span><strong class="'+(row.correct?'good':'bad')+'">'+escape(row.answer)+'</strong><span class="expected">Expected: '+escape(row.expected)+'</span><small>'+row.seconds.toFixed(1)+' s</small></article>').join('')+'</div><div class="controls"><button type="button" id="reportReset">Reset check</button><button type="button" id="reportPrint">Print / Save PDF</button></div>';
    summary.style.display='block';$('reportReset').addEventListener('click',requestReset);$('reportPrint').addEventListener('click',()=>window.print());
  }
  function stop(){if(!active)return false;stoppedSeconds=elapsed();stoppedDate=new Date();active=false;locked=true;cancelTimers();$('workArea').hidden=true;answer.disabled=true;$('insertPlus').disabled=true;$('submitBtn').disabled=true;$('nextBtn').disabled=true;$('stopBtn').disabled=true;feedback.textContent='';renderReport();document.dispatchEvent(new CustomEvent('beard:assessment-stop',{detail:{state:state()}}));return true;}
  function reset(){cancelTimers();generator=null;current=null;active=false;locked=true;startedAt=null;questionAt=null;stoppedSeconds=0;stoppedDate=null;history=[];attempts=0;correct=0;summary.replaceChildren();summary.style.display='none';$('workArea').hidden=false;$('problem').textContent='—';$('problem').dataset.beardProblem='';$('problem').removeAttribute('aria-label');answer.value='';answer.disabled=true;answer.removeAttribute('aria-invalid');$('insertPlus').disabled=true;$('submitBtn').disabled=true;$('nextBtn').disabled=true;$('stopBtn').disabled=true;feedback.textContent='';feedback.className='';$('timer').textContent='Time: 0s';document.body.dataset.beardLevel=level();stats();}
  function start(){reset();generator=createGenerator(selection(),random);active=true;startedAt=Date.now();$('stopBtn').disabled=false;timer=setInterval(()=>$('timer').textContent='Time: '+Math.floor(elapsed())+'s',250);next();}
  function requestReset(){reset();document.dispatchEvent(new CustomEvent('beard:settings-changed',{detail:{level:level(),skill:'Expanded form'}}));if(!document.body.dataset.beardAutoStart)start();}
  function correctResponse(index,outcome){if(active||!Number.isInteger(index)||index<0||index>=history.length||typeof outcome!=='boolean')return false;history[index].correct=outcome;history[index].outcome=outcome;correct=history.filter(row=>row.correct).length;stats();renderReport();document.dispatchEvent(new CustomEvent('beard:report-updated'));return true;}
  $('submitBtn').addEventListener('click',respond);$('insertPlus').addEventListener('click',addPlus);$('nextBtn').addEventListener('click',()=>{if(active&&locked)next();});answer.addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.repeat){event.preventDefault();respond();}});$('stopBtn').addEventListener('click',stop);$('resetBtn').addEventListener('click',requestReset);
  boxes.forEach(box=>box.addEventListener('change',()=>{if(!selection().length){box.checked=true;$('settingHelp').textContent='Keep at least one level selected. Your current assessment has not changed.';return;}$('settingHelp').textContent='Choose any combination. Keep at least one level selected. Changing a level starts a fresh assessment.';requestReset();}));
  if(window.top===window){summary.addEventListener('contextmenu',event=>{const card=event.target.closest?.('[data-beard-response-index]');if(!card||active)return;const index=Number(card.dataset.beardResponseIndex);if(correctResponse(index,!history[index]?.correct))event.preventDefault();});summary.addEventListener('keydown',event=>{if(event.repeat||!['Enter',' '].includes(event.key)||event.target.matches?.('button,a,input,select'))return;const card=event.target.closest?.('[data-beard-response-index]');if(!card||active)return;const index=Number(card.dataset.beardResponseIndex);if(correctResponse(index,!history[index]?.correct))event.preventDefault();});}
  document.addEventListener('beard:run-start',start);
  const params=new URLSearchParams(location.search||'');if(params.has('levels')){try{const levels=validateLevels(params.get('levels').split(','));boxes.forEach(box=>box.checked=levels.includes(box.value));}catch{}}
  window.BeardAssessment={start,reset,stop,getState:state,correctResponse};window.BeardAssessmentState={getReport:state,reset,stop,correctResponse};
  if(document.body.dataset.beardAutoStart)reset();else start();
})();
