(function () {
  'use strict';

  function integer(min, max, random) {
    const value = Math.max(0, Math.min(0.9999999999999999, Number(random()) || 0));
    return min + Math.floor(value * (max - min + 1));
  }
  function formatScaled(units, places) {
    const sign = units < 0 ? '−' : '';
    const value = Math.abs(units), scale = 10 ** places;
    const whole = Math.floor(value / scale).toLocaleString('en-US');
    return sign + whole + (places ? '.' + String(value % scale).padStart(places, '0') : '');
  }
  function parseScaled(raw, places) {
    const text = String(raw ?? '').trim();
    const match = text.match(/^([+-]?)(?:(\d{1,3}(?:,\d{3})+|\d+)(?:\.(\d*))?|\.(\d+))$/);
    if (!match || !Number.isInteger(places) || places < 0 || places > 3) return {valid:false,units:null,exact:false};
    const wholeText = (match[2] || '0').replaceAll(',', '');
    const fraction = match[3] ?? match[4] ?? '';
    const whole = Number(wholeText), scale = 10 ** places;
    if (!Number.isSafeInteger(whole) || !Number.isSafeInteger(whole * scale)) return {valid:false,units:null,exact:false};
    const exact = !/[1-9]/.test(fraction.slice(places));
    if (!exact) return {valid:true,units:null,exact:false};
    const units = whole * scale + Number(fraction.slice(0, places).padEnd(places, '0') || 0);
    if (!Number.isSafeInteger(units)) return {valid:false,units:null,exact:false};
    return {valid:true,units:match[1] === '-' ? -units : units,exact:true};
  }
  function generateWhole(max, operation = 'mixed', random = Math.random) {
    if (![1000,100000,1000000].includes(Number(max))) throw new Error('Choose a supported number range.');
    max = Number(max);
    const minimum = Math.floor(max / 10);
    const operator = operation === 'subtract' || operation === 'mixed' && random() < 0.5 ? '−' : '+';
    let a = integer(minimum, max, random), b;
    if (operator === '+') {
      b = integer(0, max - a, random);
      if (random() < 0.5) [a,b] = [b,a];
    } else b = integer(0, a, random);
    const expected = operator === '+' ? a + b : a - b;
    return {a,b,operator,expected,places:0,problem:formatScaled(a,0)+' '+operator+' '+formatScaled(b,0)+' = ?'};
  }
  function generateDecimal(places = 3, random = Math.random) {
    if (![1,2,3].includes(Number(places))) throw new Error('Choose tenths, hundredths, or thousandths.');
    places = Number(places);
    const scale = 10 ** places;
    const operand = () => integer(0,99,random) * scale + integer(1,scale-1,random);
    const a = operand(), b = operand(), expected = a+b;
    return {a,b,operator:'+',expected,places,problem:formatScaled(a,places)+' + '+formatScaled(b,places)+' = ?'};
  }
  window.BeardExtendedMath = Object.freeze({generateWhole,generateDecimal,parseScaled,formatScaled});

  if (typeof document === 'undefined' || !document.getElementById('extendedMathApp')) return;
  const $ = id => document.getElementById(id);
  const decimal = document.body.dataset.extendedMath === 'decimal';
  const answer = $('answer'), feedback = $('feedback'), summary = $('summary'), problem = $('problem');
  const submitButton = $('submitBtn'), nextButton = $('nextBtn'), stopButton = $('stopBtn');
  const operation = $('operation'), maximum = $('maxValue'), decimalPlaces = $('decimalPlaces');
  const random = () => window.BeardRun?.random?.() ?? Math.random();
  let active = false, locked = true, current = null, history = [];
  let startedAt = null, questionAt = null, stoppedSeconds = 0, stoppedDate = null;
  let attempts = 0, correct = 0, timer = null, advanceTimer = null, lastProblem = '';

  function escape(value) { return String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char])); }
  function places() { return decimal ? Number(decimalPlaces.value) : 0; }
  function level() {
    if (decimal) return 'Decimal addition · '+({1:'Tenths',2:'Hundredths',3:'Thousandths'}[places()])+' · addends below 100';
    const name = {add:'Addition',subtract:'Subtraction',mixed:'Addition and subtraction'}[operation.value];
    return name+' · through '+Number(maximum.value).toLocaleString('en-US');
  }
  function syncLevel() {
    document.body.dataset.beardLevel = level();
    document.body.dataset.beardSkill = decimal ? 'Adding decimals' : 'Large-number addition and subtraction';
  }
  function elapsed() { return active ? Math.max(0,(Date.now()-startedAt)/1000) : stoppedSeconds; }
  function cancelTimers() {
    clearTimeout(advanceTimer); advanceTimer = null;
    clearInterval(timer); timer = null;
  }
  function updateStats() {
    $('attempts').textContent = 'Attempts: '+attempts;
    $('attempts').dataset.beardCorrect = String(correct);
    $('score').textContent = 'Score: '+(attempts ? Math.round(correct/attempts*100) : 0)+'%';
  }
  function showQuestion() {
    if (!active) return false;
    clearTimeout(advanceTimer); advanceTimer = null;
    let candidate;
    for (let i=0;i<8;i++) {
      candidate = decimal ? generateDecimal(places(),random) : generateWhole(Number(maximum.value),operation.value,random);
      if (candidate.problem !== lastProblem) break;
    }
    current = candidate; lastProblem = current.problem; locked = false; questionAt = Date.now();
    problem.dataset.beardProblem = current.problem;
    problem.setAttribute('aria-label',current.problem.replace('−','minus').replace('+','plus').replace('= ?','equals what?'));
    problem.innerHTML = '<span class="extended-equation" aria-hidden="true"><span class="extended-first">'+formatScaled(current.a,places())+'</span><span class="extended-operator">'+current.operator+'</span><span class="extended-second">'+formatScaled(current.b,places())+'</span></span>';
    answer.value = ''; answer.disabled = false; answer.removeAttribute('aria-invalid');
    submitButton.disabled = false; nextButton.disabled = true;
    feedback.textContent = ''; feedback.className = '';
    $('answerHelp').textContent = decimal ? 'Enter the sum. Equivalent decimals such as 0.3 and 0.300 are accepted.' : 'Enter a whole number. Commas are optional.';
    if (window.matchMedia?.('(pointer:fine)').matches) answer.focus({preventScroll:true});
    return true;
  }
  function submit() {
    if (!active || locked || !current) return false;
    const raw = answer.value.trim(), parsed = parseScaled(raw,places());
    if (!parsed.valid) {
      answer.setAttribute('aria-invalid','true');
      $('answerHelp').textContent = decimal ? 'Enter a number using digits and a decimal point. Do not use letters or an exponent.' : 'Enter a number using digits. If you use commas, group digits in threes.';
      return false;
    }
    locked = true; answer.removeAttribute('aria-invalid');
    const outcome = parsed.exact && parsed.units === current.expected;
    attempts++; if (outcome) correct++;
    history.push({problem:current.problem,answer:raw,expected:formatScaled(current.expected,places()),expectedUnits:current.expected,precision:places(),correct:outcome,outcome,seconds:Math.max(0,(Date.now()-questionAt)/1000),elapsedSeconds:elapsed()});
    answer.disabled = true; submitButton.disabled = true; nextButton.disabled = false;
    updateStats(); feedback.textContent = outcome ? 'Correct!' : 'Incorrect. The answer is '+formatScaled(current.expected,places())+'.';
    feedback.className = outcome ? 'good' : 'bad';
    advanceTimer = setTimeout(showQuestion,750);
    return true;
  }
  function state() {
    return {assessment:document.title,level:level(),active,attempts,correct,errors:attempts-correct,seconds:elapsed(),date:stoppedDate?.toISOString(),scoreType:'Accuracy',score:attempts?correct/attempts:null,percentage:attempts?Math.round(correct/attempts*100):null,current:current?{...current}:null,responses:history.map(row=>({...row}))};
  }
  function stop() {
    if (!active) return false;
    stoppedSeconds = elapsed(); stoppedDate = new Date(); active = false; locked = true; cancelTimers();
    answer.disabled = true; submitButton.disabled = true; nextButton.disabled = true; stopButton.disabled = true;
    $('workArea').hidden = true; feedback.textContent = '';
    summary.innerHTML = '<h2>'+escape(decimal?'Decimal Addition Results':'Large-Number Math Results')+'</h2><p class="extended-report-meta"><strong>'+escape(stoppedDate.toLocaleDateString())+' · '+(attempts?Math.round(correct/attempts*100)+'%':'No responses')+'</strong><br>'+escape(level())+'<br>Correct: '+correct+' / '+attempts+' · Total time: '+stoppedSeconds.toFixed(1)+' seconds</p><div class="extended-response-grid">'+history.map((row,index)=>'<article class="extended-response-card"><span>'+(index+1)+'. '+escape(row.problem)+'</span><strong class="'+(row.correct?'good':'bad')+'">'+escape(row.answer)+'</strong><small>'+row.seconds.toFixed(1)+' s</small></article>').join('')+'</div><div class="controls"><button type="button" id="againBtn">New check</button><button type="button" id="printBtn">Print / Save PDF</button></div>';
    summary.style.display = 'block'; $('againBtn').addEventListener('click',requestReset); $('printBtn').addEventListener('click',()=>window.print());
    document.dispatchEvent(new CustomEvent('beard:assessment-stop',{detail:{state:state()}}));
    return true;
  }
  function reset() {
    cancelTimers(); active = false; locked = true; current = null; history = [];
    attempts = 0; correct = 0; startedAt = null; questionAt = null; stoppedSeconds = 0; stoppedDate = null; lastProblem = '';
    summary.replaceChildren(); summary.style.display = 'none'; $('workArea').hidden = false;
    answer.value = ''; answer.disabled = true; answer.removeAttribute('aria-invalid');
    submitButton.disabled = true; nextButton.disabled = true; stopButton.disabled = true;
    feedback.textContent = ''; feedback.className = ''; problem.textContent = 'A new problem will appear automatically.';
    problem.dataset.beardProblem = ''; $('timer').textContent = 'Time: 0s'; syncLevel(); updateStats();
  }
  function start() {
    reset(); active = true; startedAt = Date.now(); stopButton.disabled = false;
    timer = setInterval(() => { $('timer').textContent = 'Time: '+Math.floor(elapsed())+'s'; },250);
    showQuestion();
  }
  function requestReset() {
    reset();
    document.dispatchEvent(new CustomEvent('beard:settings-changed',{detail:{level:level(),skill:document.body.dataset.beardSkill}}));
    if (!document.body.dataset.beardAutoStart) start();
  }
  const params = new URLSearchParams(window.location?.search || '');
  if (decimal) {
    if (['1','2','3'].includes(params.get('places'))) decimalPlaces.value = params.get('places');
    decimalPlaces.addEventListener('change',requestReset);
  } else {
    if (['1000','100000','1000000'].includes(params.get('max'))) maximum.value = params.get('max');
    if (['add','subtract','mixed'].includes(params.get('operation'))) operation.value = params.get('operation');
    maximum.addEventListener('change',requestReset); operation.addEventListener('change',requestReset);
  }
  submitButton.addEventListener('click',submit); nextButton.addEventListener('click',()=>{if(active&&locked)showQuestion();});
  stopButton.addEventListener('click',stop); $('resetBtn').addEventListener('click',requestReset);
  answer.addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.repeat){event.preventDefault();submit();}});
  document.addEventListener('beard:run-start',start);
  window.BeardAssessment = {start,reset,stop,getState:state};
  if (window.top === window) start(); else reset();
}());
