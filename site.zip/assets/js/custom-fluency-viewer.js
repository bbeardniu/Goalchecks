(function () {
  'use strict';
  const doc = document, win = window;
  const $ = id => doc.getElementById(id);
  const params = new URLSearchParams(win.location.search);
  const requested = params.get('passage');
  const entries = win.BeardCustomFluencyBank?.passages;
  const picker = $('customPassageSelect');
  if(Array.isArray(entries))entries.forEach(item=>{
    const option=doc.createElement('option');option.value=item.id;
    option.textContent=item.group&&item.group!=='Teacher-added'?item.group+' · '+item.title:item.title;
    picker.appendChild(option);
  });
  picker.disabled=!Array.isArray(entries)||!entries.length;
  const entry = Array.isArray(entries) ? (params.has('passage')?entries.find(item => item.id === requested):entries[0]) : null;
  if (!entry || typeof entry.title !== 'string' || typeof entry.text !== 'string' ||
      !entry.text.trim() || !/^[a-f0-9]{16}$/i.test(entry.revision || '')) {
    doc.body.dataset.beardUnavailable = 'true';
    $('customFluencyApp').hidden = true;
    $('passageUnavailable').hidden = false;
    if(!Array.isArray(entries)||!entries.length){
      $('unavailableTitle').textContent='No custom passages yet';
      $('unavailableMessage').textContent='Add a passage text file to your site’s passages folder, publish the update, and return here.';
    }
    return;
  }
  picker.value=entry.id;
  picker.addEventListener('change',()=>{
    const chosen=entries.find(item=>item.id===picker.value);
    if(!chosen||chosen.id===entry.id)return;
    const next=new URL(win.location.href);next.searchParams.set('passage',chosen.id);
    if(win.top===win){
      const marker=next.pathname.indexOf('/HTMLs/');
      const activity=(marker>=0?next.pathname.slice(marker+1):'HTMLs/Reading Fluency/Custom_Fluency_Passage.html')+next.search;
      const launcher=new URL('../Activity_Launcher.html',next);
      launcher.searchParams.set('v','01.0022');launcher.searchParams.set('activity',activity);
      win.location.assign(launcher.href);
    }else win.location.assign(next.href);
  });

  const passage = $('passage'), studentSelect = $('studentSelect'), daySelect = $('colorSelect');
  const colors = ['red','green','blue','purple','pink'];
  const days = {red:'Monday',green:'Tuesday',blue:'Wednesday',purple:'Thursday',pink:'Friday'};
  const boxes = {red:'mondayBox',green:'tuesdayBox',blue:'wednesdayBox',purple:'thursdayBox',pink:'fridayBox'};
  const records = new Map();
  let words = [], interval = null, startedAt = null, seconds = 0, rang = false, audio = null;
  doc.title = entry.title;
  doc.body.dataset.beardRunAware = 'true';
  doc.body.dataset.beardSkill = 'Teacher-added passage fluency';
  doc.body.dataset.beardLevel = entry.group || 'Teacher-added';
  doc.body.dataset.beardPassageId = entry.id + '@' + entry.revision;
  $('passageTitle').textContent = entry.title;
  $('passageGroup').textContent = 'Reading Fluency' + (entry.group&&entry.group!=='Teacher-added'?' · '+entry.group:'');

  function blankRecord() {
    return {endpoints:Object.fromEntries(colors.map(c => [c,0])),errors:Object.fromEntries(colors.map(c => [c,new Set()]))};
  }
  function record() {
    const name = studentSelect.value || 'Current read';
    if (!records.has(name)) records.set(name,blankRecord());
    return records.get(name);
  }
  function paint() {
    const data = record(), active = daySelect.value;
    words.forEach(word => {word.style.backgroundColor='';word.style.color='';word.classList.remove('native-error');});
    [...colors.filter(c => c !== active),active].forEach(color => {
      const endpoint = data.endpoints[color];
      if (endpoint && words[endpoint-1]) {words[endpoint-1].style.backgroundColor=color;words[endpoint-1].style.color='white';}
    });
    if (win.top === win) data.errors[active].forEach(index => {if(index<data.endpoints[active])words[index]?.classList.add('native-error');});
    $('counter').textContent = 'Words read: ' + data.endpoints[active];
    colors.forEach(color => {$(boxes[color]).textContent = days[color] + ': ' + data.endpoints[color];});
  }
  function renderPassage() {
    words = [];
    const fragment = doc.createDocumentFragment();
    entry.text.split(/(\s+)/).forEach(token => {
      if (!token.trim()) {fragment.appendChild(doc.createTextNode(token));return;}
      const word = doc.createElement('span');
      word.className = 'word';word.textContent=token;word.dataset.index=String(words.length);
      word.addEventListener('click',() => {
        const data=record(),color=daySelect.value,last=Number(word.dataset.index)+1;
        data.endpoints[color]=data.endpoints[color]===last?0:last;paint();
      });
      word.addEventListener('contextmenu',event => {
        if(win.top!==win)return;
        event.preventDefault();const set=record().errors[daySelect.value],index=Number(word.dataset.index);
        if(set.has(index))set.delete(index);else set.add(index);paint();
      });
      words.push(word);fragment.appendChild(word);
    });
    passage.replaceChildren(fragment);paint();
  }
  function addStudent() {
    const input=$('newStudent'),name=input.value.trim().slice(0,80);
    if(!name)return;
    if(!Array.from(studentSelect.options).some(option=>option.value===name)){
      const option=doc.createElement('option');option.value=name;option.textContent=name;studentSelect.appendChild(option);
    }
    studentSelect.value=name;input.value='';paint();
  }
  function elapsed() {return interval===null?seconds:Math.max(0,(Date.now()-startedAt)/1000);}
  function timerText() {
    const left=Math.max(0,60-Math.floor(elapsed()));
    $('timer').textContent='Time: '+Math.floor(left/60)+':'+String(left%60).padStart(2,'0');
  }
  function ring() {
    if(win.top!==win)return;
    try{
      audio??=new(win.AudioContext||win.webkitAudioContext)();audio.resume?.();
      const oscillator=audio.createOscillator(),gain=audio.createGain(),now=audio.currentTime;
      oscillator.frequency.value=880;gain.gain.setValueAtTime(.15,now);gain.gain.exponentialRampToValueAtTime(.001,now+.7);
      oscillator.connect(gain);gain.connect(audio.destination);oscillator.start(now);oscillator.stop(now+.7);
    }catch{}
  }
  function stopTimer() {
    if(interval!==null){seconds=elapsed();clearInterval(interval);interval=null;}
    timerText();
  }
  function startTimer() {
    stopTimer();seconds=0;startedAt=Date.now();rang=false;
    interval=setInterval(()=>{timerText();if(!rang&&elapsed()>=60){rang=true;ring();}},250);timerText();
  }
  function resetTimer() {stopTimer();seconds=0;startedAt=null;rang=false;timerText();}
  function resetPassage() {records.set(studentSelect.value||'Current read',blankRecord());resetTimer();paint();}
  function resetAll() {
    records.clear();studentSelect.replaceChildren();
    const option=doc.createElement('option');option.value='Current read';option.textContent='Current read';studentSelect.appendChild(option);
    resetTimer();paint();
  }
  function getState() {
    const data=record(),color=daySelect.value,last=data.endpoints[color];
    const errors=[...data.errors[color]].filter(index=>index<last).length;
    return {assessment:doc.title,level:doc.body.dataset.beardLevel,passageId:doc.body.dataset.beardPassageId,wordsRead:last,correct:last-errors,errors,seconds:elapsed()};
  }
  Object.assign(win,{addStudent,startTimer,stopTimer,resetTimer,resetPassage,resetAll});
  win.BeardAssessment={start:startTimer,reset:resetPassage,stop:stopTimer,getState};
  studentSelect.addEventListener('change',paint);daySelect.addEventListener('change',paint);
  doc.addEventListener('beard:run-start',()=>{resetPassage();startTimer();});
  doc.addEventListener('keydown',event=>{
    if(win.top!==win||event.defaultPrevented||event.repeat||event.ctrlKey||event.altKey||event.metaKey||event.isComposing||event.target?.closest?.('input,textarea,select,[contenteditable]'))return;
    if(event.key==='1')startTimer();else if(event.key==='4')resetPassage();else if(event.key==='5')resetAll();
  });
  renderPassage();
}());
