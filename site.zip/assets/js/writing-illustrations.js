/* Picture support never changes a prompt, answer, question order, score, or clock. */
(() => {
  'use strict';
  const mounts = new WeakMap();
  const scriptUrl = document.currentScript?.src || new URL('../../assets/js/writing-illustrations.js', document.baseURI).href;
  const assetBase = new URL('../illustrations/', scriptUrl);
  const imageCache = new Map();
  let nextId = 0;
  function loadImage(url) {
    if (!imageCache.has(url)) imageCache.set(url, new Promise(resolve => {
      const image = new Image();
      image.onload = () => resolve(true);
      image.onerror = () => resolve(false);
      image.src = url;
    }));
    return imageCache.get(url);
  }
  function label(states, enabled) {
    return states.size > 1 ? 'On and off' : states.size ? (states.has(true) ? 'On' : 'Off') : (enabled ? 'On' : 'Off');
  }
  function mount({host, activity} = {}) {
    if (!host) return null;
    if (mounts.has(host)) return mounts.get(host);
    const doc = host.ownerDocument || document;
    const bank = window.BeardWritingArt || {};
    let enabled = true, finished = false, prompt = null;
    const runStates = new Set(), promptStates = new Set();
    function element(tag, className, text) {
      const node = doc.createElement(tag);
      if (className) node.className = className;
      if (text !== undefined) node.textContent = text;
      return node;
    }
    const toolbar = element('div', 'writing-illustration-toolbar');
    const button = element('button', 'writing-illustration-toggle', 'Hide illustrations');
    button.id = 'writingIllustrationsToggle';
    button.type = 'button';
    const figure = element('figure', 'writing-illustration-figure');
    figure.id = 'writingIllustrationFigure-' + (++nextId);
    button.setAttribute('aria-controls', figure.id);
    const art = element('div', 'writing-illustration-art');
    const caption = element('figcaption', 'writing-illustration-caption');
    figure.append(art, caption);
    toolbar.append(button);
    host.classList.add('writing-illustrations');
    host.replaceChildren(toolbar, figure);
    function entry() { return bank[activity]?.[prompt] || bank.fallback || {decorative:true}; }
    function note() {
      if (prompt !== null && !finished) { runStates.add(enabled); promptStates.add(enabled); }
    }
    function paint() {
      button.textContent = enabled ? 'Hide illustrations' : 'Show illustrations';
      button.setAttribute('aria-pressed', String(enabled));
      figure.hidden = !enabled || prompt === null;
      figure.setAttribute('aria-hidden', String(figure.hidden));
      if (figure.hidden) {
        art.replaceChildren();
        art.removeAttribute('aria-label');
        art.removeAttribute('role');
        art.style.backgroundImage = 'none';
        // Invalidate a late image callback after hiding or changing a prompt.
        art.dataset.storybookRender = 'hidden';
        caption.textContent = '';
        return;
      }
      const picture = entry();
      if (!picture.decorative && picture.file && Number.isInteger(picture.index)) {
        const columns = picture.columns || 4, rows = picture.rows || columns;
        const url = new URL(picture.file, assetBase);
        url.searchParams.set('v', '01.0026');
        art.replaceChildren();
        art.classList.remove('is-writing-emblem', 'is-unavailable');
        art.style.backgroundImage = 'url("' + url.href + '")';
        art.style.backgroundSize = (columns * 100) + '% ' + (rows * 100) + '%';
        art.style.backgroundPosition = (columns === 1 ? 0 : picture.index % columns / (columns - 1) * 100) + '% ' + (rows === 1 ? 0 : Math.floor(picture.index / columns) / (rows - 1) * 100) + '%';
        art.setAttribute('role', 'img');
        art.setAttribute('aria-label', picture.alt);
        caption.textContent = activity === 'independent' ? 'Picture for inspiration' : picture.kind === 'exact' ? 'Picture support' : 'Subject illustration';
        const token = String(nextId++);
        art.dataset.storybookRender = token;
        loadImage(url.href).then(loaded => {
          if (loaded || art.dataset.storybookRender !== token) return;
          art.style.backgroundImage = 'none';
          art.classList.add('is-unavailable');
          art.textContent = 'Picture unavailable.';
          art.setAttribute('aria-label', 'Picture unavailable.');
        });
      } else {
        art.replaceChildren();
        art.dataset.storybookRender = 'decoration';
        art.classList.remove('beard-storybook-art', 'is-unavailable', 'is-transparent');
        art.classList.add('is-writing-emblem');
        art.style.backgroundImage = '';
        art.style.backgroundSize = '';
        art.style.backgroundPosition = '';
        art.setAttribute('role', 'img');
        art.setAttribute('aria-label', 'A colored-pencil illustration of a notebook and pencil.');
        caption.textContent = 'Writing illustration';
      }
    }
    button.addEventListener('click', () => {
      if (finished) return;
      enabled = !enabled;
      note();
      paint();
    });
    const api = Object.freeze({
      show(key) {
        const value = String(key);
        if (value !== prompt) promptStates.clear();
        prompt = value;
        note();
        paint();
      },
      reset() {
        finished = false;
        prompt = null;
        runStates.clear();
        promptStates.clear();
        button.disabled = false;
        paint();
      },
      finish() { finished = true; button.disabled = true; },
      getReport() {
        const used = label(runStates, enabled);
        return {illustrationsUsed:used, illustrationsEnabled:enabled, supports:'Illustrations: ' + used};
      },
      getPromptReport() { return label(promptStates, enabled); }
    });
    mounts.set(host, api);
    api.reset();
    return api;
  }
  window.BeardWritingIllustrations = Object.freeze({mount});
})();
