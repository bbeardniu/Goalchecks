(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.BeardSpellingPracticeSession = api;
})(typeof window !== 'undefined' ? window : typeof globalThis !== 'undefined' ? globalThis : null, function () {
  'use strict';

  const MINUTE_MS = 60000;
  function defaultNormalize(value) {
    return String(value ?? '').normalize('NFC').replace(/[\u2018\u2019\u02bc\uff07]/g, "'").trim().toLocaleLowerCase('en-US');
  }
  function create({words, normalize = defaultNormalize, now = () => Date.now()} = {}) {
    if (!Array.isArray(words) || !words.length || words.some(word => typeof word !== 'string' || !word.trim())) {
      throw new Error('Choose a spelling list before starting an assessment.');
    }
    if (typeof normalize !== 'function' || typeof now !== 'function') throw new Error('The assessment clock or spelling comparison is unavailable.');
    const orderedWords = words.slice(), expected = orderedWords.map(word => normalize(word));
    let phase = 'ready', startedAtMs = null, stoppedAtMs = null, latestClockMs = null;
    let activeIndex = null, activeSinceMs = null, frozenMinute = null;
    const responses = new Map(), dwellMs = new Map();

    function clock() {
      const value = Number(now());
      if (!Number.isFinite(value) || !Number.isFinite(new Date(value).getTime())) throw new Error('The assessment clock is unavailable.');
      // A system-clock adjustment must not produce negative answer times.
      latestClockMs = latestClockMs === null ? value : Math.max(latestClockMs, value);
      return latestClockMs;
    }
    function validIndex(index) {
      if (!Number.isInteger(index) || index < 0 || index >= orderedWords.length) throw new Error('Choose a word from this spelling list.');
    }
    function elapsedMs(at) { return startedAtMs === null ? 0 : Math.max(0, at - startedAtMs); }
    function iso(at) { return at === null ? null : new Date(at).toISOString(); }
    function copied(row) { return {...row}; }
    function activeDwell(index, at) {
      return (dwellMs.get(index) || 0) + (activeIndex === index && activeSinceMs !== null ? Math.max(0, at - activeSinceMs) : 0);
    }
    function collectDwell(at) {
      if (activeIndex === null || activeSinceMs === null) return;
      const duration = activeDwell(activeIndex, at);
      dwellMs.set(activeIndex, duration);
      activeSinceMs = at;
      const row = responses.get(activeIndex);
      if (row) row.seconds = duration / 1000;
    }
    function totals(rows) {
      const correct = rows.filter(row => row.outcome === true).length;
      const errors = rows.filter(row => row.outcome === false).length;
      const pending = rows.length - correct - errors, scored = correct + errors;
      return {attempts:rows.length, correct, errors, pending, scored,
        percentage:pending || !scored ? null : Math.round(correct / scored * 100),
        accuracy:scored ? correct / scored : null};
    }
    function currentRows(at) {
      return [...responses.values()].sort((a, b) => a.index - b.index).map(row => ({...row,
        seconds:phase === 'running' ? activeDwell(row.index, at) / 1000 : row.seconds}));
    }
    function minuteRows() {
      return [...responses.values()].filter(row => row.elapsedSeconds <= 60).sort((a, b) => a.index - b.index).map(copied);
    }
    function captureMinute(at) {
      // An answer submitted at exactly 60.000 seconds belongs to the first minute.
      // Once overtime starts, later student edits cannot rewrite that snapshot.
      if (frozenMinute === null && startedAtMs !== null && elapsedMs(at) > MINUTE_MS) frozenMinute = minuteRows();
    }
    function snapshot(at) {
      const elapsed = phase === 'ready' ? 0 : elapsedMs(phase === 'finished' ? stoppedAtMs : at);
      const rows = currentRows(at), score = totals(rows);
      const firstMinuteResponses = (frozenMinute === null ? minuteRows() : frozenMinute).map(copied);
      const firstMinute = {...totals(firstMinuteResponses), seconds:Math.min(60, elapsed / 1000), responses:firstMinuteResponses};
      const indexed = new Map(rows.map(row => [row.index, row]));
      return {phase, date:iso(startedAtMs), startedAt:iso(startedAtMs), finishedAt:iso(stoppedAtMs),
        totalSeconds:elapsed / 1000, countdownSeconds:Math.ceil(Math.max(0, MINUTE_MS - elapsed) / 1000),
        minuteReached:elapsed >= MINUTE_MS, overtimeSeconds:Math.max(0, elapsed - MINUTE_MS) / 1000,
        ...score, hasPending:score.pending > 0, unanswered:orderedWords.length - score.attempts,
        totalWords:orderedWords.length, words:orderedWords.slice(), responses:rows,
        allResponses:orderedWords.map((word, index) => indexed.has(index)
          ? {...indexed.get(index), submitted:true}
          : {index, word, spelling:'', mode:null, outcome:null, seconds:0, elapsedSeconds:null, submitted:false}),
        firstMinute};
    }
    function getState() {
      const at = phase === 'running' ? clock() : stoppedAtMs ?? startedAtMs ?? 0;
      if (phase === 'running') captureMinute(at);
      return snapshot(at);
    }
    function begin() {
      // Reset keeps the source order. A new shuffle is the controller's responsibility.
      latestClockMs = null;
      const at = clock();
      responses.clear();dwellMs.clear();frozenMinute = null;
      startedAtMs = at;stoppedAtMs = null;phase = 'running';activeIndex = 0;activeSinceMs = at;
      return snapshot(at);
    }
    function notePrompt(index) {
      if (phase !== 'running') return false;
      validIndex(index);
      const at = clock();captureMinute(at);
      if (activeIndex !== index) {
        collectDwell(at);
        activeIndex = index;activeSinceMs = at;
      }
      return true;
    }
    function submit(index, {spelling = '', mode = 'type'} = {}) {
      if (phase !== 'running') return false;
      validIndex(index);
      if (typeof spelling !== 'string' || Array.from(spelling).length > 200) throw new Error('A spelling answer must be 200 characters or fewer.');
      if (mode !== 'type' && mode !== 'paper') throw new Error('Choose typing or writing on paper.');
      const outcome = mode === 'paper' ? null : Boolean(spelling.trim()) && normalize(spelling) === expected[index];
      const at = clock();captureMinute(at);collectDwell(at);
      const previous = responses.get(index);
      const row = {index, word:orderedWords[index], spelling, mode, outcome,
        seconds:activeDwell(index, at) / 1000,
        elapsedSeconds:previous ? previous.elapsedSeconds : elapsedMs(at) / 1000};
      responses.set(index, row);
      return copied(row);
    }
    function finish() {
      if (phase === 'finished') return getState();
      const at = clock();
      if (phase === 'ready') startedAtMs = at;
      captureMinute(at);collectDwell(at);
      stoppedAtMs = at;activeIndex = null;activeSinceMs = null;phase = 'finished';
      return snapshot(at);
    }
    function correct(index, outcome) {
      if (phase !== 'finished') return false;
      validIndex(index);
      if (outcome !== true && outcome !== false && outcome !== null) throw new Error('Mark an answer correct, incorrect, or pending.');
      const row = responses.get(index);
      if (!row) return false;
      row.outcome = outcome;
      // An explicit report correction also fixes that answer's first-minute mark.
      const minuteRow = frozenMinute?.find(item => item.index === index);
      if (minuteRow) minuteRow.outcome = outcome;
      return true;
    }

    return Object.freeze({begin, reset:begin, notePrompt, submit, finish, correct, getState,
      get phase() { return phase; }});
  }

  return Object.freeze({create});
});
