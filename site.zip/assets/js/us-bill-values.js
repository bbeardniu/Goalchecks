(() => {
  'use strict';
  const VALUES=Object.freeze([1,2,5,10,20,100]);
  function selectedValues(values) {
    if(!Array.isArray(values)||!values.length||values.some(value=>!VALUES.includes(Number(value))))throw new Error('Choose at least one supported bill.');
    return [...new Set(values.map(Number))].sort((a,b)=>a-b);
  }
  function buildPool(values,skill='total',maximum=5) {
    const selected=selectedValues(values),limit=skill==='single'?1:Number(maximum);
    if(!['single','total'].includes(skill)||![1,3,5].includes(limit))throw new Error('Choose a supported bill-count level.');
    const pool=[],counts={};
    function visit(index,number,total){
      if(index===selected.length){
        if(number){const nonzero={},bills=[];for(const value of selected)if(counts[value]){nonzero[value]=counts[value];for(let i=0;i<counts[value];i++)bills.push(value);}pool.push({counts:nonzero,bills,expected:total,key:selected.map(value=>value+':'+(counts[value]||0)).join('|')});}
        return;
      }
      const value=selected[index];
      for(let count=0;count<=limit-number;count++){counts[value]=count;visit(index+1,number+count,total+value*count);}
      delete counts[value];
    }
    visit(0,0,0);return pool;
  }
  function parseMoney(raw){
    const text=String(raw??'').trim(),match=text.match(/^\$?((?:\d{1,3}(?:,\d{3})+)|\d+)(?:\.(\d{1,2}))?$/);
    if(!match)return{valid:false,cents:null};
    const dollars=Number(match[1].replaceAll(',','')),cents=dollars*100+Number((match[2]||'').padEnd(2,'0'));
    return Number.isSafeInteger(dollars)&&Number.isSafeInteger(cents)?{valid:true,cents}:{valid:false,cents:null};
  }
  window.BeardBillMath=Object.freeze({values:VALUES,buildPool,parseMoney});
  if(typeof document==='undefined'||!document.getElementById('billChoices'))return;
  const $=id=>document.getElementById(id),skill=$('skill'),billCount=$('billCount'),answer=$('answer'),summary=$('summary'),feedback=$('feedback');
  const boxes=[...document.querySelectorAll('input[name="bill"]')],art=window.BeardBillArt;
  let pool=[],bag=[],current=null,lastKey='',active=false,locked=true,startedAt=null,questionAt=null,stoppedSeconds=0,stoppedDate=null,history=[],attempts=0,correct=0,timer=null,nextTimer=null,serial=0;
  const random=()=>window.BeardRun?.random?.()??Math.random();
  const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function shuffle(items){const out=items.slice();for(let i=out.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[out[i],out[j]]=[out[j],out[i]];}return out;}
  function selection(){return boxes.filter(box=>box.checked).map(box=>Number(box.value));}
  function level(){return(skill.value==='single'?'Value of one bill':'Bill totals, 1–'+billCount.value+' bills')+' · '+selection().map(value=>'$'+value).join(', ');}
  function syncLevel(){document.body.dataset.beardLevel=level();billCount.disabled=skill.value==='single';}
  function elapsed(){return active?Math.max(0,(Date.now()-startedAt)/1000):stoppedSeconds;}
  function stats(){$('attempts').textContent='Attempts: '+attempts;$('attempts').dataset.beardCorrect=String(correct);$('score').textContent='Score: '+(attempts?Math.round(correct/attempts*100):0)+'%';}
  function cancelTimers(){clearTimeout(nextTimer);nextTimer=null;clearInterval(timer);timer=null;}
  function describe(counts){return VALUES.filter(value=>counts[value]).map(value=>counts[value]+' '+(counts[value]===1?art.specs[value].name:art.specs[value].plural)).join(', ');}
  function promptText(row){return 'Bills: '+describe(row.counts)+'. Find the value in dollars.';}
  function next(){
    if(!active)return false;
    clearTimeout(nextTimer);nextTimer=null;
    if(!bag.length){bag=shuffle(pool);if(bag.length>1&&bag[bag.length-1].key===lastKey)[bag[0],bag[bag.length-1]]=[bag[bag.length-1],bag[0]];}
    current=bag.pop();lastKey=current.key;locked=false;questionAt=Date.now();serial++;
    $('problem').textContent=skill.value==='single'?'What is the value of this bill in dollars?':'What is the total value in dollars?';
    $('problem').dataset.beardProblem=promptText(current);
    $('visual').innerHTML=shuffle(current.bills).map((value,index)=>art.draw(value,serial+'-'+index)).join('');
    answer.value='';answer.disabled=false;answer.removeAttribute('aria-invalid');$('submitBtn').disabled=false;$('nextBtn').disabled=true;feedback.textContent='';feedback.className='';$('answerHelp').textContent='Enter dollars, such as 12 or $12.00.';
    if(window.matchMedia?.('(pointer:fine)').matches)answer.focus({preventScroll:true});return true;
  }
  function respond(){
    if(!active||locked||!current)return false;
    const raw=answer.value.trim(),parsed=parseMoney(raw);
    if(!parsed.valid){answer.setAttribute('aria-invalid','true');$('answerHelp').textContent='Enter a dollar amount using digits, optionally with $ and up to two decimal places.';return false;}
    locked=true;answer.removeAttribute('aria-invalid');const outcome=parsed.cents===current.expected*100;attempts++;if(outcome)correct++;
    history.push({problem:promptText(current),answer:raw,expected:'$'+current.expected,expectedValue:current.expected,correct:outcome,outcome,seconds:Math.max(0,(Date.now()-questionAt)/1000),elapsedSeconds:elapsed(),bills:{...current.counts}});
    answer.disabled=true;$('submitBtn').disabled=true;$('nextBtn').disabled=false;stats();feedback.textContent=outcome?'Correct!':'Incorrect. The value is $'+current.expected+'.';feedback.className=outcome?'good':'bad';nextTimer=setTimeout(next,750);return true;
  }
  function state(){return{assessment:document.title,skill:'U.S. bill values',level:level(),active,attempts,correct,errors:attempts-correct,seconds:elapsed(),date:stoppedDate?.toISOString(),scoreType:'Accuracy',score:attempts?correct/attempts:null,percentage:attempts?Math.round(correct/attempts*100):null,pending:false,selectedBills:selection(),supports:'Bills: '+selection().map(value=>'$'+value).join(', ')+'; '+(skill.value==='single'?'One bill':'Totals of 1–'+billCount.value+' bills'),current:current?{...current,problem:promptText(current),counts:{...current.counts},bills:current.bills.slice()}:null,responses:history.map(row=>({...row,bills:{...row.bills}}))};}
  function renderReport(){
    summary.innerHTML='<h2>Bill Value Results</h2><p><strong>'+escape(stoppedDate.toLocaleDateString())+' · '+(attempts?Math.round(correct/attempts*100)+'%':'No responses')+'</strong><br>'+escape(level())+'<br>Correct: '+correct+' / '+attempts+' · Total time: '+stoppedSeconds.toFixed(1)+' seconds</p><div class="result-cards">'+history.map((row,index)=>'<article class="result-card" data-beard-response-index="'+index+'" tabindex="0" role="button" title="Right-click to switch Correct / Incorrect"><span>'+(index+1)+'. '+escape(row.problem)+'</span><strong class="'+(row.correct?'good':'bad')+'">'+escape(row.answer)+'</strong><small>'+row.seconds.toFixed(1)+' s</small></article>').join('')+'</div><div class="controls"><button type="button" id="reportReset">Reset check</button><button type="button" id="reportPrint">Print / Save PDF</button></div>';
    summary.style.display='block';$('reportReset').addEventListener('click',requestReset);$('reportPrint').addEventListener('click',()=>window.print());
  }
  function stop(){
    if(!active)return false;stoppedSeconds=elapsed();stoppedDate=new Date();active=false;locked=true;cancelTimers();$('workArea').hidden=true;answer.disabled=true;$('submitBtn').disabled=true;$('nextBtn').disabled=true;$('stopBtn').disabled=true;feedback.textContent='';renderReport();
    document.dispatchEvent(new CustomEvent('beard:assessment-stop',{detail:{state:state()}}));return true;
  }
  function reset(){
    cancelTimers();pool=[];bag=[];current=null;lastKey='';active=false;locked=true;startedAt=null;questionAt=null;stoppedSeconds=0;stoppedDate=null;history=[];attempts=0;correct=0;serial=0;summary.replaceChildren();summary.style.display='none';$('workArea').hidden=false;$('visual').replaceChildren();$('problem').textContent='A new set of bills will appear automatically.';$('problem').dataset.beardProblem='';answer.value='';answer.disabled=true;$('submitBtn').disabled=true;$('nextBtn').disabled=true;$('stopBtn').disabled=true;feedback.textContent='';feedback.className='';$('timer').textContent='Time: 0s';syncLevel();stats();
  }
  function start(){reset();pool=buildPool(selection(),skill.value,Number(billCount.value));active=true;startedAt=Date.now();$('stopBtn').disabled=false;timer=setInterval(()=>$('timer').textContent='Time: '+Math.floor(elapsed())+'s',250);next();}
  function requestReset(){reset();document.dispatchEvent(new CustomEvent('beard:settings-changed',{detail:{level:level(),skill:'U.S. bill values'}}));if(!document.body.dataset.beardAutoStart)start();}
  function correctResponse(index,outcome){if(active||!Number.isInteger(index)||index<0||index>=history.length||typeof outcome!=='boolean')return false;history[index].correct=outcome;history[index].outcome=outcome;correct=history.filter(row=>row.correct).length;stats();renderReport();document.dispatchEvent(new CustomEvent('beard:report-updated'));return true;}
  $('submitBtn').addEventListener('click',respond);$('nextBtn').addEventListener('click',()=>{if(active&&locked)next();});answer.addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.repeat){event.preventDefault();respond();}});$('stopBtn').addEventListener('click',stop);$('resetBtn').addEventListener('click',requestReset);
  [skill,billCount].forEach(select=>select.addEventListener('change',requestReset));
  boxes.forEach(box=>box.addEventListener('change',()=>{if(!selection().length){box.checked=true;$('settingHelp').textContent='Keep at least one bill selected. Your current assessment has not changed.';return;}$('settingHelp').textContent='Choose any combination. Keep at least one bill selected. Changing a setting starts a fresh assessment.';requestReset();}));
  if(window.top===window){
    summary.addEventListener('contextmenu',event=>{const card=event.target.closest?.('[data-beard-response-index]');if(!card||active)return;const index=Number(card.dataset.beardResponseIndex);if(correctResponse(index,!history[index]?.correct))event.preventDefault();});
    summary.addEventListener('keydown',event=>{if(event.repeat||!['Enter',' '].includes(event.key)||event.target.matches?.('button,a,input,select'))return;const card=event.target.closest?.('[data-beard-response-index]');if(!card||active)return;const index=Number(card.dataset.beardResponseIndex);if(correctResponse(index,!history[index]?.correct))event.preventDefault();});
  }
  document.addEventListener('beard:run-start',start);
  const params=new URLSearchParams(location.search||'');
  if(['single','total'].includes(params.get('skill')))skill.value=params.get('skill');if(['3','5'].includes(params.get('maxBills')))billCount.value=params.get('maxBills');
  if(params.has('bills')){try{const values=selectedValues(params.get('bills').split(','));boxes.forEach(box=>box.checked=values.includes(Number(box.value)));}catch{}}
  window.BeardAssessment={start,reset,stop,getState:state,correctResponse};window.BeardAssessmentState={getReport:state,reset,stop,correctResponse};window.BeardBillAssessment=Object.freeze({buildPool,describe,selection});
  syncLevel();if(document.body.dataset.beardAutoStart)reset();else start();
})();
