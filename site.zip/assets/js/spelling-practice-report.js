(() => {
  'use strict';

  function render(host, {state, label = '', onCorrect, onPrint, onRestart} = {}) {
    if (!host) return null;
    host.replaceChildren();
    if (!state || state.phase !== 'finished') { host.hidden = true; return null; }
    host.hidden = false;
    const doc = host.ownerDocument || document;
    const count = value => Number.isFinite(Number(value)) ? Math.max(0, Number(value)) : 0;
    const rows = Array.isArray(state.responses)
      ? state.responses.filter(row => row && Number.isInteger(row.index) && row.index >= 0).slice().sort((a, b) => a.index - b.index)
      : [];
    const attempts = count(state.attempts), correct = count(state.correct), errors = count(state.errors);
    const pending = count(state.pending), scored = count(state.scored), unanswered = count(state.unanswered);
    const percentage = pending ? null : Number.isFinite(state.percentage) ? state.percentage : null;
    const scoreText = pending ? 'Pending' : percentage === null ? '—' : Math.round(percentage) + '%';
    const totalSeconds = count(state.totalSeconds);
    const date = new Date(state.finishedAt ?? state.date ?? state.startedAt ?? NaN);
    const dateText = Number.isFinite(date.getTime())
      ? date.toLocaleDateString(undefined, {year:'numeric', month:'long', day:'numeric'})
      : 'Date unavailable';
    function node(tag, className, text) {
      const item = doc.createElement(tag);
      if (className) item.className = className;
      if (text !== undefined) item.textContent = String(text);
      return item;
    }
    function stat(name, value) {
      const item = node('span', 'practice-report-stat');
      item.append(node('strong', '', name + ': '), node('span', '', value));
      return item;
    }
    const report = node('article', 'practice-report');
    const heading = node('header', 'practice-report-heading');
    heading.append(node('p', 'practice-report-brand', "Beard's Classroom"), node('h2', '', 'Spelling Assessment Results'));
    const details = node('p', 'practice-report-label', label);
    const meta = node('div', 'practice-report-meta');
    meta.append(stat('Date', dateText), stat('Score', scoreText));
    const totals = node('div', 'practice-report-totals');
    const minutes = Math.floor(totalSeconds / 60), seconds = Math.floor(totalSeconds % 60);
    totals.append(
      stat('Total time', minutes + ':' + String(seconds).padStart(2, '0') + ' (' + totalSeconds.toFixed(1) + ' s)'),
      stat('Correct', correct + ' / ' + scored + ' graded'),
      stat('Attempts', attempts), stat('Errors', errors), stat('Awaiting grading', pending), stat('Not reached', unanswered)
    );
    report.append(heading, details, meta, totals);
    if (state.firstMinute) {
      const minute = state.firstMinute;
      const duration = Math.min(60, count(minute.seconds));
      const minuteScore = count(minute.pending) ? 'Pending' : Number.isFinite(minute.percentage) ? Math.round(minute.percentage) + '%' : '—';
      report.append(node('p', 'practice-report-first-minute', 'First ' + (duration === 60 ? '60' : duration.toFixed(1)) + ' seconds: ' + count(minute.correct) + ' correct / ' + count(minute.attempts) + ' attempts · ' + minuteScore));
    }
    const notes = [];
    if (!attempts) notes.push('No answers were submitted.');
    if (pending) notes.push(pending + ' written-on-paper answer' + (pending === 1 ? ' is' : 's are') + ' awaiting grading. Mark them below to calculate the final percentage.');
    if (unanswered) notes.push(unanswered + ' word' + (unanswered === 1 ? ' was' : 's were') + ' not reached and ' + (unanswered === 1 ? 'is' : 'are') + ' not counted as incorrect.');
    if (!pending && attempts) notes.push('The percentage is based on submitted answers.');
    if (notes.length) report.append(node('p', 'practice-report-note', notes.join(' ')));
    if (rows.length) {
      report.append(node('h3', 'practice-report-response-heading', dateText + ' · Score: ' + scoreText));
      const grid = node('div', 'practice-report-grid');
      rows.forEach(row => {
        const outcome = row.outcome === true ? true : row.outcome === false ? false : null;
        const paper = row.mode === 'paper';
        const word = String(row.word ?? state.words?.[row.index] ?? '');
        const spelling = String(row.spelling ?? '');
        const resultText = outcome === true ? 'Correct' : outcome === false ? 'Incorrect' : 'Pending';
        const className = outcome === true ? 'is-correct' : outcome === false ? 'is-incorrect' : 'is-pending';
        const card = node('article', 'practice-report-card ' + className);
        card.id = 'practice-report-answer-' + row.index;
        const top = node('div', 'practice-report-card-top');
        top.append(node('span', 'practice-report-number', row.index + 1 + '.'), node('span', 'practice-report-result', resultText));
        const expected = node('span', 'practice-report-expected', 'Word: ' + word);
        const answerText = paper
          ? (outcome === null ? 'Written on paper — mark below' : 'Written on paper')
          : spelling || '(No answer)';
        const answer = node('strong', 'practice-report-student-answer', answerText);
        if (paper && outcome === null) answer.dataset.printText = 'Written on paper — awaiting grading';
        const timing = node('span', 'practice-report-seconds', count(row.seconds).toFixed(1) + ' s');
        timing.setAttribute('aria-label', count(row.seconds).toFixed(1) + ' seconds to answer');
        card.append(top, expected, answer, timing);
        if (typeof onCorrect === 'function') {
          function change(value) { onCorrect(row.index, value); }
          function toggle(event) {
            if (outcome === null || event.target?.closest?.('button,input,textarea,select,a')) return;
            event.preventDefault();
            change(!outcome);
          }
          if (outcome !== null) {
            card.dataset.practiceResponseIndex = String(row.index);
            card.tabIndex = 0;
            card.setAttribute('role', 'button');
            card.setAttribute('aria-label', 'Word ' + (row.index + 1) + ', ' + word + ', ' + resultText + '. Change correct or incorrect result.');
            card.title = 'Right-click to switch Correct / Incorrect';
            card.addEventListener('contextmenu', toggle);
            card.addEventListener('keydown', event => {
              if (event.repeat || event.isComposing) return;
              if ((event.key === 'F10' && event.shiftKey) || event.key === 'Enter' || event.key === ' ') toggle(event);
            });
          }
          if (paper || outcome === null) {
            const marking = node('div', 'practice-report-marking');
            [true, false].forEach(value => {
              const button = node('button', 'practice-report-mark ' + (value ? 'mark-correct' : 'mark-incorrect'), value ? 'Correct' : 'Incorrect');
              button.type = 'button';
              button.setAttribute('aria-label', 'Mark word ' + (row.index + 1) + ', ' + word + ', ' + (value ? 'correct' : 'incorrect'));
              button.setAttribute('aria-pressed', String(outcome === value));
              button.addEventListener('click', () => change(value));
              marking.append(button);
            });
            card.append(marking);
          }
        }
        grid.append(card);
      });
      report.append(grid);
      if (typeof onCorrect === 'function') report.append(node('p', 'practice-report-correction-tip', 'To correct a grading mistake, right-click a graded answer box, or focus it and press Enter.'));
    } else {
      report.append(node('p', 'practice-report-empty', 'There are no submitted answers to display.'));
    }
    const actions = node('div', 'practice-report-actions');
    if (typeof onPrint === 'function') {
      const print = node('button', 'practice-report-print', 'Print / Save PDF');
      print.type = 'button'; print.addEventListener('click', onPrint); actions.append(print);
    }
    if (typeof onRestart === 'function') {
      const restart = node('button', 'practice-report-restart', 'New assessment');
      restart.type = 'button'; restart.addEventListener('click', onRestart); actions.append(restart);
    }
    if (actions.children.length) report.append(actions);
    host.append(report);
    return report;
  }

  function makePrint(host, printHost) {
    if (!host || !printHost) return null;
    printHost.replaceChildren();
    const report = host.matches?.('.practice-report') ? host : host.querySelector('.practice-report');
    if (!report || host.hidden) return null;
    const copy = report.cloneNode(true);
    copy.querySelectorAll('.practice-report-actions,.practice-report-marking,.practice-report-correction-tip').forEach(item => item.remove());
    copy.querySelectorAll('[data-print-text]').forEach(item => { item.textContent = item.dataset.printText; });
    copy.querySelectorAll('[data-practice-response-index]').forEach(item => {
      item.removeAttribute('tabindex'); item.removeAttribute('role'); item.removeAttribute('aria-label'); item.removeAttribute('title'); item.removeAttribute('data-practice-response-index');
    });
    copy.querySelectorAll('[id]').forEach(item => item.removeAttribute('id'));
    printHost.append(copy);
    return copy;
  }

  window.BeardSpellingPracticeReport = Object.freeze({render, makePrint});
})();
