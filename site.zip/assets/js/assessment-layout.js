(function () {
  'use strict';
  function attach(doc, banner) {
    const win = doc.defaultView;
    doc.documentElement.classList.add('beard-assessment-root');
    doc.body.classList.add('beard-assessment-page');
    let frame = null, previous = 0;
    function measure() {
      frame = null;
      const bottom = Math.ceil(banner.getBoundingClientRect().bottom);
      if (!Number.isFinite(bottom) || bottom <= 0) return;
      const space = bottom + 24;
      if (space === previous) return;
      previous = space;
      doc.documentElement.style.setProperty('--beard-header-space', space + 'px');
      doc.documentElement.style.setProperty('--beard-header-height', bottom + 'px');
    }
    function schedule() {
      if (frame === null) frame = win.requestAnimationFrame(measure);
    }
    measure();
    const observer = typeof win.ResizeObserver === 'function' ? new win.ResizeObserver(schedule) : null;
    observer?.observe(banner);
    win.addEventListener('resize', schedule);
    win.visualViewport?.addEventListener('resize', schedule);
    doc.fonts?.ready?.then(schedule).catch(() => {});
    win.addEventListener('pagehide', event => {
      if (event?.persisted) return;
      observer?.disconnect();
      if (frame !== null) win.cancelAnimationFrame(frame);
      win.removeEventListener('resize', schedule);
      win.visualViewport?.removeEventListener('resize', schedule);
    });
    return {measure};
  }
  window.BeardAssessmentLayout = Object.freeze({attach});
}());
