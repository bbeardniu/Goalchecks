(function () {
  'use strict';

  const stories = window.BeardFluencyComprehension?.stories;
  const $ = id => document.getElementById(id);
  const gradeSelect = $('gradeSelect'), storySelect = $('storySelect');
  const workArea = $('workArea'), readingPanel = $('readingPanel'), questionPanel = $('questionPanel');
  const summary = $('summary'), correctButton = $('btnCorrect'), incorrectButton = $('btnIncorrect');
  const nextButton = $('nextBtn'), stopButton = $('stopBtn');
  const labels = {who:'Who',what:'What',when:'When',where:'Where',why:'Why'};
  const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const round = seconds => Math.max(0, Math.round(seconds * 10) / 10);

  document.body.dataset.beardRunAware = 'true';
  document.body.dataset.beardDeferTiming = 'true';
  document.body.dataset.beardNativeScoring = 'true';
  document.body.dataset.beardSkill = 'Listening comprehension: who, what, when, where and why';

  if (!Array.isArray(stories) || !stories.length) {
    $('storyTitle').textContent = 'The story collection could not be loaded.';
    $('storyText').textContent = 'Refresh this page to try again.';
    $('beginQuestions').disabled = true;
    stopButton.disabled = true;
    return;
  }

  let currentStory = null, questionIndex = 0, history = [], stage = 'reading';
  let questionsStarted = false, locked = true, questionAt = null, startedAt = null;
  let stoppedSeconds = 0, stoppedDate = null, timerId = null;

  function notify(type = 'beard:report-updated', detail) {
    document.dispatchEvent(new CustomEvent(type, {detail}));
  }
  function elapsed() {
    if (stage === 'finished') return stoppedSeconds;
    return startedAt === null ? 0 : Math.max(0, (Date.now() - startedAt) / 1000);
  }
  function levelLabel() {
    return 'Grade ' + currentStory.grade + ' · ' + currentStory.title;
  }
  function syncContext() {
    document.body.dataset.beardLevel = levelLabel();
    document.body.dataset.beardPassageId = currentStory.id;
    document.body.dataset.beardStage = stage;
  }
  function firstMinute() {
    if (!questionsStarted) return null;
    const rows = history.filter(row => row.elapsedSeconds <= 60);
    const correct = rows.filter(row => row.correct).length;
    return {attempts:rows.length,correct,errors:rows.length-correct,accuracy:rows.length?correct/rows.length:null,seconds:Math.min(60,elapsed())};
  }
  function reportState() {
    const correct = history.filter(row => row.correct).length;
    return {
      assessment:document.title,skill:document.body.dataset.beardSkill,level:levelLabel(),
      storyId:currentStory.id,storyTitle:currentStory.title,grade:currentStory.grade,
      attempts:history.length,correct,errors:history.length-correct,
      scoreType:'Accuracy',score:history.length?correct/history.length:null,
      percentage:history.length?Math.round(correct/history.length*100):null,pending:false,
      seconds:elapsed(),date:stoppedDate?.toISOString(),firstMinute:firstMinute(),
      questionsStarted,stage,active:stage!=='finished',
      supports:'Teacher read the passage aloud; student answered orally; passage hidden during questions',
      notes:'Response times run from question display to teacher marking, including question read-aloud time. The total timer starts with the first question and includes pauses between questions. Answer text is the expected answer, not a transcription of the student response.',
      responses:history.map(row => ({...row,outcome:row.correct}))
    };
  }
  function updateStats() {
    const state = reportState();
    $('score').textContent = state.attempts ? 'Score: ' + state.percentage + '%' : 'Score: No responses';
    $('attempts').textContent = 'Attempts: ' + state.attempts;
    $('timer').textContent = 'Questions time: ' + elapsed().toFixed(1) + ' s';
  }
  function setMarking(enabled) {
    correctButton.disabled = !enabled;
    incorrectButton.disabled = !enabled;
  }
  function selectedStory() {
    return stories.find(story => story.id === storySelect.value && String(story.grade) === gradeSelect.value) ||
      stories.find(story => String(story.grade) === gradeSelect.value);
  }
  function populateStories(preferredId) {
    const pool = stories.filter(story => String(story.grade) === gradeSelect.value);
    storySelect.replaceChildren(...pool.map(story => {
      const option = document.createElement('option');
      option.value = story.id;
      option.textContent = story.title;
      return option;
    }));
    storySelect.value = pool.some(story => story.id === preferredId) ? preferredId : pool[0].id;
  }
  function resetAssessment() {
    clearInterval(timerId); timerId = null;
    currentStory = selectedStory(); questionIndex = 0; history = [];
    stage = 'reading'; questionsStarted = false; locked = true;
    startedAt = null; questionAt = null; stoppedSeconds = 0; stoppedDate = null;
    syncContext();
    summary.replaceChildren(); summary.style.display = 'none';
    workArea.hidden = false; readingPanel.hidden = false; questionPanel.hidden = true;
    $('storyTitle').textContent = currentStory.title;
    $('storyText').textContent = currentStory.text;
    $('question').textContent = ''; $('progress').textContent = '';
    $('responseStatus').textContent = ''; $('feedback').textContent = '';
    $('teacherKey').open = false;
    $('beginQuestions').disabled = false; stopButton.disabled = false;
    nextButton.disabled = true; setMarking(false); updateStats();
    document.getElementById('beard-print-report')?.remove();
    document.body.classList.remove('beard-has-print-report');
    notify();
  }
  function showQuestion() {
    const item = currentStory.questions[questionIndex];
    locked = false; questionAt = Date.now();
    $('progress').textContent = 'Question ' + (questionIndex + 1) + ' of 10';
    $('questionType').textContent = labels[item.type];
    $('question').textContent = item.question;
    $('expectedAnswer').textContent = item.answer;
    $('acceptGuide').textContent = item.accept || 'Accept an accurate spoken answer with the same meaning; the student does not need to repeat these exact words.';
    $('answerEvidence').textContent = item.evidence;
    $('teacherKey').open = false; $('responseStatus').textContent = '';
    setMarking(true); nextButton.disabled = true;
    $('question').focus?.({preventScroll:true});
    questionPanel.scrollIntoView?.({block:'start'});
  }
  function beginQuestions() {
    if (stage !== 'reading') return false;
    stage = 'questions'; questionsStarted = true; startedAt = Date.now();
    syncContext(); readingPanel.hidden = true; questionPanel.hidden = false;
    showQuestion(); updateStats();
    timerId = setInterval(() => { $('timer').textContent = 'Questions time: ' + elapsed().toFixed(1) + ' s'; }, 250);
    notify('beard:question-phase-start', {storyId:currentStory.id});
    return true;
  }
  function markAnswer(correct) {
    if (stage !== 'questions' || locked || typeof correct !== 'boolean') return false;
    const item = currentStory.questions[questionIndex];
    locked = true;
    history.push({id:item.id,prompt:item.question,answer:item.answer,questionType:item.type,
      correct,seconds:round((Date.now()-questionAt)/1000),elapsedSeconds:elapsed()});
    setMarking(false); updateStats();
    if (questionIndex === currentStory.questions.length - 1) { finishAssessment(); return true; }
    $('responseStatus').textContent = 'Response recorded. Choose Next question when you are ready.';
    nextButton.disabled = false;
    notify();
    return true;
  }
  function nextQuestion() {
    if (stage !== 'questions' || !locked) return false;
    questionIndex += 1;
    showQuestion();
    return true;
  }
  function renderSummary() {
    const state = reportState();
    const date = stoppedDate.toLocaleDateString(undefined,{month:'long',day:'numeric',year:'numeric'});
    const score = state.attempts ? state.percentage + '%' : 'No responses';
    const cards = history.map((row,index) => '<article class="wh-response-card" data-beard-response-index="'+index+'"><div><small>'+(index+1)+'. '+escapeHtml(labels[row.questionType])+'</small><strong class="wh-report-question">'+escapeHtml(row.prompt)+'</strong><span class="wh-report-answer '+(row.correct?'good':'bad')+'"><b>'+(row.correct?'Correct':'Incorrect')+'</b> · Expected answer: '+escapeHtml(row.answer)+'</span></div><span class="wh-time">'+row.seconds.toFixed(1)+' s</span></article>').join('');
    summary.innerHTML = '<h2>Read-Aloud Comprehension Results</h2><p class="wh-report-meta"><strong>'+escapeHtml(date)+'</strong><br><strong>Passage:</strong> '+escapeHtml(levelLabel())+'<br><strong>Score:</strong> '+score+' · <strong>Correct:</strong> '+state.correct+'/'+state.attempts+' · <strong>Questions time:</strong> '+stoppedSeconds.toFixed(1)+' s</p><p class="wh-hint">Teacher read aloud · Student responded orally · Passage hidden for questions<br>Seconds include reading the question aloud. Answers shown below are the expected answers.</p>'+(cards?'<div class="wh-response-grid">'+cards+'</div>':'<p>'+(questionsStarted?'No responses were marked.':'Stopped during the read-aloud. Question timing had not started.')+'</p>')+'<div class="wh-report-actions"><button type="button" id="restartReport">Reset assessment</button><button type="button" id="printReport">Print / Save PDF</button></div>';
    summary.style.display = 'block';
    $('restartReport').addEventListener('click',resetAssessment);
    $('printReport').addEventListener('click',() => window.print());
  }
  function finishAssessment() {
    if (stage === 'finished') return false;
    stoppedSeconds = elapsed(); stoppedDate = new Date();
    stage = 'finished'; locked = true; syncContext();
    clearInterval(timerId); timerId = null;
    setMarking(false); nextButton.disabled = true; stopButton.disabled = true;
    workArea.hidden = true; updateStats(); renderSummary();
    summary.scrollIntoView?.({block:'start'});
    notify('beard:assessment-stop');
    notify();
    return true;
  }
  function correctResponse(index,correct) {
    if (stage !== 'finished' || !Number.isInteger(index) || index < 0 || index >= history.length || typeof correct !== 'boolean') return false;
    history[index].correct = correct;
    updateStats(); renderSummary(); notify();
    return true;
  }
  function changeSelection() {
    resetAssessment();
    notify('beard:settings-changed',{level:levelLabel(),skill:document.body.dataset.beardSkill});
  }

  gradeSelect.addEventListener('change',() => { populateStories(); changeSelection(); });
  storySelect.addEventListener('change',changeSelection);
  $('beginQuestions').addEventListener('click',beginQuestions);
  correctButton.addEventListener('click',() => markAnswer(true));
  incorrectButton.addEventListener('click',() => markAnswer(false));
  nextButton.addEventListener('click',nextQuestion);
  stopButton.addEventListener('click',finishAssessment);
  $('resetBtn').addEventListener('click',resetAssessment);
  document.addEventListener('beard:run-start',resetAssessment);
  document.addEventListener('keydown',event => {
    if (event.defaultPrevented || event.repeat || event.ctrlKey || event.altKey || event.metaKey || event.isComposing || event.target?.closest?.('input,textarea,select,[contenteditable]')) return;
    if (event.key === '1' || event.key === '2') {
      if (markAnswer(event.key === '1')) event.preventDefault();
    }
  });

  const requested = new URLSearchParams(window.location?.search || '');
  const grade = requested.get('grade');
  if (grade === '2' || grade === '3') gradeSelect.value = grade;
  const requestedStory = stories.find(story => story.id === requested.get('story'));
  if (requestedStory) gradeSelect.value = String(requestedStory.grade);
  populateStories(requestedStory?.id);
  window.BeardAssessmentState = {getReport:reportState,reset:resetAssessment,stop:finishAssessment,correctResponse};
  window.BeardAssessment = {start:resetAssessment,reset:resetAssessment,stop:finishAssessment,getState:reportState,correctResponse};
  resetAssessment();
}());
