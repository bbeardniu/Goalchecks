(() => {
  'use strict';
  const bank=window.BeardWordProblems,config=window.BeardWordProblemConfig||{},$=id=>document.getElementById(id);
  if(!bank||!$('wordProblemApp'))return;
  const answer=$('answer'),problem=$('problem'),summary=$('summary'),feedback=$('feedback'),maximum=$('maxValue'),stepCount=$('stepCount');
  const inputs=[...document.querySelectorAll('input[name="wordProblemOperation"]')];
  const operationNames={add:'Addition',subtract:'Subtraction',multiply:'Multiplication',divide:'Division'};
  const random=()=>window.BeardRun?.random?.()??Math.random();
  let active=false,locked=true,current=null,history=[],attempts=0,correct=0,startedAt=null,questionAt=null,stoppedSeconds=0,stoppedDate=null,timer=null,nextTimer=null,sequenceBag=[],lastQuestion='';
  const chosen=()=>inputs.filter(input=>input.checked).map(input=>input.value);
  const escape=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  function quantity(value,unit){const singular=({boxes:'box',shelves:'shelf',children:'child',paintbrushes:'paintbrush'})[unit]||unit.replace(/s$/,'');return value+' '+(Number(value)===1?singular:unit);}
  function shuffle(items){const result=items.slice();for(let i=result.length-1;i>0;i--){const j=Math.floor(Math.max(0,Math.min(.9999999999999999,Number(random())||0))*(i+1));[result[i],result[j]]=[result[j],result[i]];}return result;}
  function level(){return stepCount.value+'-step word problems · '+chosen().map(op=>operationNames[op]).join(', ')+' · numbers through '+Number(maximum.value).toLocaleString('en-US');}
  function sync(){document.body.dataset.beardLevel=level();document.body.dataset.beardSkill='Math word problems';$('wordProblemHeading').textContent=Number(stepCount.value)===2?'Two-Step Word Problems':'One-Step Word Problems';document.title=$('wordProblemHeading').textContent+' · Through '+Number(maximum.value).toLocaleString('en-US');}
  function elapsed(){return active?Math.max(0,(Date.now()-startedAt)/1000):stoppedSeconds;}
  function cancelTimers(){clearTimeout(nextTimer);clearInterval(timer);nextTimer=null;timer=null;}
  function stats(){$('attempts').textContent='Attempts: '+attempts;$('attempts').dataset.beardCorrect=String(correct);$('score').textContent='Score: '+(attempts?Math.round(correct/attempts*100):0)+'%';}
  function showQuestion(){
    if(!active)return false;
    clearTimeout(nextTimer);nextTimer=null;
    if(!sequenceBag.length)sequenceBag=shuffle(bank.sequences(chosen(),Number(stepCount.value)));
    const sequence=sequenceBag.pop();let candidate;
    for(let retry=0;retry<8;retry++){candidate=bank.generate({steps:Number(stepCount.value),max:Number(maximum.value),operations:chosen(),sequence,random});if(candidate.question!==lastQuestion)break;}
    current=candidate;lastQuestion=current.question;locked=false;questionAt=Date.now();problem.textContent=current.question;problem.dataset.beardProblem=current.question;
    answer.value='';answer.disabled=false;answer.removeAttribute('aria-invalid');$('submitBtn').disabled=false;$('nextBtn').disabled=true;feedback.textContent='';feedback.className='';$('answerHelp').textContent='Enter your answer as a number. Commas are optional.';
    if(window.matchMedia?.('(pointer:fine)').matches)answer.focus({preventScroll:true});return true;
  }
  function numeric(raw){const text=String(raw).trim();if(!/^[+-]?(?:(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d*)?|\.\d+)$/.test(text))return null;const number=Number(text.replaceAll(',',''));return Number.isFinite(number)&&Math.abs(number)<=Number.MAX_SAFE_INTEGER?number:null;}
  function submit(){
    if(!active||locked||!current)return false;const raw=answer.value.trim(),value=numeric(raw);
    if(value===null){answer.setAttribute('aria-invalid','true');$('answerHelp').textContent='Enter a number using digits. If you use commas, group digits in threes.';return false;}
    locked=true;const outcome=value===current.answer;attempts++;if(outcome)correct++;
    history.push({problem:current.question,prompt:current.question,answer:raw,expected:String(current.answer),unit:current.unit,correct:outcome,outcome,seconds:Math.max(0,(Date.now()-questionAt)/1000),elapsedSeconds:elapsed(),operations:current.operations.slice(),steps:current.steps,equation:current.equation,templateId:current.templateId});
    answer.disabled=true;$('submitBtn').disabled=true;$('nextBtn').disabled=false;stats();feedback.textContent=outcome?'Correct!':'Incorrect. The answer is '+quantity(current.answer,current.unit)+'.';feedback.className=outcome?'good':'bad';
    nextTimer=setTimeout(showQuestion,750);return true;
  }
  function state(){return{assessment:document.title,skill:'Math word problems',level:level(),active,attempts,correct,errors:attempts-correct,seconds:elapsed(),date:stoppedDate?.toISOString(),scoreType:'Accuracy',score:attempts?correct/attempts:null,percentage:attempts?Math.round(correct/attempts*100):null,supports:'Steps: '+stepCount.value+'; Operations: '+chosen().map(op=>operationNames[op]).join(', ')+'; Number range: through '+Number(maximum.value).toLocaleString('en-US'),operations:chosen(),steps:Number(stepCount.value),max:Number(maximum.value),current:current?{...current,operations:current.operations.slice(),solution:current.solution.map(step=>({...step}))}:null,responses:history.map(row=>({...row,operations:row.operations.slice()}))};}
  function renderReport(){
    summary.innerHTML='<h2>Word Problem Results</h2><p><strong>'+escape(stoppedDate.toLocaleDateString())+' · '+(attempts?Math.round(correct/attempts*100)+'%':'No responses')+'</strong><br>'+escape(level())+'<br>Correct: '+correct+' / '+attempts+' · Total time: '+stoppedSeconds.toFixed(1)+' seconds</p><div class="word-problem-results">'+history.map((row,index)=>'<article class="word-problem-result" data-beard-response-index="'+index+'"><p>'+(index+1)+'. '+escape(row.problem)+'</p><strong class="'+(row.correct?'good':'bad')+'">'+escape(row.answer)+'</strong> · '+row.seconds.toFixed(1)+' s<small>Expected: '+escape(quantity(row.expected,row.unit))+'</small></article>').join('')+'</div><div class="word-problem-controls"><button type="button" id="wordProblemAgain">Reset check</button><button type="button" id="wordProblemPrint">Print / Save PDF</button></div>';
    summary.style.display='block';$('wordProblemAgain').addEventListener('click',requestReset);$('wordProblemPrint').addEventListener('click',()=>window.print());
  }
  function stop(){if(!active)return false;stoppedSeconds=elapsed();stoppedDate=new Date();active=false;locked=true;cancelTimers();$('workArea').hidden=true;answer.disabled=true;$('submitBtn').disabled=true;$('nextBtn').disabled=true;$('stopBtn').disabled=true;feedback.textContent='';renderReport();document.dispatchEvent(new CustomEvent('beard:assessment-stop',{detail:{state:state()}}));return true;}
  function reset(){cancelTimers();active=false;locked=true;current=null;history=[];attempts=0;correct=0;startedAt=null;questionAt=null;stoppedSeconds=0;stoppedDate=null;sequenceBag=[];lastQuestion='';summary.replaceChildren();summary.style.display='none';$('workArea').hidden=false;answer.value='';answer.disabled=true;answer.removeAttribute('aria-invalid');$('submitBtn').disabled=true;$('nextBtn').disabled=true;$('stopBtn').disabled=true;feedback.textContent='';feedback.className='';problem.textContent='A new word problem will appear automatically.';problem.dataset.beardProblem='';$('timer').textContent='Time: 0s';stats();sync();}
  function start(){reset();active=true;startedAt=Date.now();$('stopBtn').disabled=false;timer=setInterval(()=>$('timer').textContent='Time: '+Math.floor(elapsed())+'s',250);showQuestion();}
  function requestReset(){reset();document.dispatchEvent(new CustomEvent('beard:settings-changed',{detail:{level:level(),skill:'Math word problems'}}));if(!document.body.dataset.beardAutoStart)start();}
  function correctResponse(index,outcome){if(active||!Number.isInteger(index)||index<0||index>=history.length||typeof outcome!=='boolean')return false;history[index].correct=outcome;history[index].outcome=outcome;correct=history.filter(row=>row.correct).length;stats();renderReport();document.dispatchEvent(new CustomEvent('beard:report-updated'));return true;}
  const params=new URLSearchParams(window.location?.search||''),initialMax=params.get('max')||String(config.max||100),initialSteps=params.get('steps')||String(config.steps||1);
  if(['20','100','1000'].includes(initialMax))maximum.value=initialMax;if(['1','2'].includes(initialSteps))stepCount.value=initialSteps;
  const requested=(params.get('operations')||params.get('operation')||'').split(',');const valid=bank.operations.filter(op=>requested.includes(op));if(valid.length)inputs.forEach(input=>input.checked=valid.includes(input.value));
  for(const input of inputs)input.addEventListener('change',()=>{if(!chosen().length){input.checked=true;$('settingsStatus').textContent='Keep at least one operation selected.';return;}$('settingsStatus').textContent='';requestReset();});
  maximum.addEventListener('change',requestReset);stepCount.addEventListener('change',requestReset);$('submitBtn').addEventListener('click',submit);$('nextBtn').addEventListener('click',()=>{if(active&&locked)showQuestion();});$('resetBtn').addEventListener('click',requestReset);$('stopBtn').addEventListener('click',stop);
  answer.addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.repeat&&!event.isComposing){event.preventDefault();submit();}});document.addEventListener('beard:run-start',start);
  window.BeardAssessmentState={getReport:state,reset,start,stop,correctResponse};window.BeardAssessment={start,reset,stop,getState:state,correctResponse};window.BeardWordProblemAssessment=Object.freeze({numeric});
  if(window.top===window)start();else reset();
})();
