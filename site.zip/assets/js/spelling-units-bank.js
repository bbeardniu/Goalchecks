/* Exact source words from the uploaded Spelling List.pdf. See sourceNotes. */
window.BeardSpellingBank = {
  "version": 1,
  "source": "Spelling List.pdf",
  "sourceSha256": "188766dfb934240d67e531ad8280fa9f99b90244213b033c5f3d26272179fde6",
  "sourceNotes": [
    "The PDF has two lists per page but does not print grade labels. The left column is assigned to Grade 2 and the right column to Grade 3, following the requested grades and the lists' relative difficulty.",
    "All numbered spelling words, their original capitalization and apostrophe forms are preserved exactly. List lengths vary; no words have been added to make lists uniform.",
    "Display skill headings are lightly normalized for whitespace and obvious heading typos. sourceSkill retains each original heading as extracted, including line breaks.",
    "Repeated words within a unit remain in their original lesson lists. A full-unit test may combine those occurrences into one spelling word while retaining all source lessons."
  ],
  "grades": {
    "2": {
      "label": "Grade 2",
      "sourceColumn": "left",
      "units": [
        {
          "id": "unit-1",
          "number": 1,
          "title": "Unit 1",
          "lessons": [
            {
              "id": "lesson-1",
              "number": 1,
              "title": "Lesson 1",
              "skill": "Short a and Short i",
              "sourceSkill": "Skill-Short a and Short i",
              "words": [
                "sad",
                "dig",
                "jam",
                "glad",
                "list",
                "win",
                "flat",
                "it",
                "rip",
                "kit",
                "mask",
                "fix"
              ],
              "wordCount": 12,
              "sourcePage": 1
            },
            {
              "id": "lesson-2",
              "number": 2,
              "title": "Lesson 2",
              "skill": "Short o, u, e",
              "sourceSkill": "Skill-Short o, u, e",
              "words": [
                "wet",
                "job",
                "hug",
                "rest",
                "spot",
                "mud",
                "left",
                "help",
                "plum",
                "nut",
                "net",
                "hot"
              ],
              "wordCount": 12,
              "sourcePage": 2
            },
            {
              "id": "lesson-3",
              "number": 3,
              "title": "Lesson 3",
              "skill": "Long a and Long i",
              "sourceSkill": "Skill-Long a and Long i",
              "words": [
                "cake",
                "mine",
                "plate",
                "size",
                "ate",
                "grape",
                "prize",
                "wipe",
                "line",
                "pile",
                "rake"
              ],
              "wordCount": 11,
              "sourcePage": 3
            },
            {
              "id": "lesson-4",
              "number": 4,
              "title": "Lesson 4",
              "skill": "Long o and Long u",
              "sourceSkill": "Skill-Long o and Long u",
              "words": [
                "doze",
                "nose",
                "use",
                "rose",
                "pole",
                "close",
                "cute",
                "woke",
                "mule",
                "rode",
                "role",
                "tune"
              ],
              "wordCount": 12,
              "sourcePage": 4
            },
            {
              "id": "lesson-5",
              "number": 5,
              "title": "Lesson 5",
              "skill": "Hard & Soft c, g",
              "sourceSkill": "Skill-Hard & Soft c, g",
              "words": [
                "spin",
                "spice",
                "nice",
                "race",
                "place",
                "twice",
                "grace",
                "grape",
                "stage",
                "cage",
                "page"
              ],
              "wordCount": 11,
              "sourcePage": 5
            }
          ],
          "wordCount": 58,
          "uniqueWordCount": 57
        },
        {
          "id": "unit-2",
          "number": 2,
          "title": "Unit 2",
          "lessons": [
            {
              "id": "lesson-6",
              "number": 6,
              "title": "Lesson 6",
              "skill": "Final Blends nd, nk, nt, ft, xt, mp",
              "sourceSkill": "Skill-Final Blends\nnd, nk, nt, ft, xt, mp",
              "words": [
                "next",
                "end",
                "camp",
                "sank",
                "sing",
                "drink",
                "hunt",
                "stand",
                "long",
                "stamp",
                "pond",
                "bring"
              ],
              "wordCount": 12,
              "sourcePage": 6
            },
            {
              "id": "lesson-7",
              "number": 7,
              "title": "Lesson 7",
              "skill": "Double Consonants & ck",
              "sourceSkill": "Skill-\nDouble Consonants & ck",
              "words": [
                "dress",
                "spell",
                "class",
                "full",
                "add",
                "neck",
                "stuck",
                "kick",
                "rock",
                "black",
                "trick",
                "doll"
              ],
              "wordCount": 12,
              "sourcePage": 7
            },
            {
              "id": "lesson-8",
              "number": 8,
              "title": "Lesson 8",
              "skill": "Digraphs th, sh, wh, ch, tch, ph",
              "sourceSkill": "Skill-\nDigraphs th, sh, wh,\nch, tch, ph",
              "words": [
                "dish",
                "than",
                "chest",
                "such",
                "thin",
                "push",
                "shine",
                "chase",
                "white",
                "while",
                "these",
                "flash"
              ],
              "wordCount": 12,
              "sourcePage": 8
            },
            {
              "id": "lesson-9",
              "number": 9,
              "title": "Lesson 9",
              "skill": "Endings ed, ing",
              "sourceSkill": "Skill-Endings ed, ing",
              "words": [
                "liked",
                "using",
                "riding",
                "chased",
                "spilled",
                "making",
                "closed",
                "hoping",
                "baked",
                "hiding",
                "standing",
                "asked"
              ],
              "wordCount": 12,
              "sourcePage": 9
            },
            {
              "id": "lesson-10",
              "number": 10,
              "title": "Lesson 10",
              "skill": "Contractions",
              "sourceSkill": "Skill-Contractions",
              "words": [
                "I’m",
                "don’t",
                "isn’t",
                "can’t",
                "we’ll",
                "it’s",
                "I’ve",
                "didn’t",
                "you’re",
                "that’s",
                "wasn’t",
                "you’ve"
              ],
              "wordCount": 12,
              "sourcePage": 10
            }
          ],
          "wordCount": 60,
          "uniqueWordCount": 60
        },
        {
          "id": "unit-3",
          "number": 3,
          "title": "Unit 3",
          "lessons": [
            {
              "id": "lesson-11",
              "number": 11,
              "title": "Lesson 11",
              "skill": "Endings -s, -es",
              "sourceSkill": "Skill-Endings –s, -es",
              "words": [
                "hens",
                "eggs",
                "ducks",
                "bikes",
                "boxes",
                "wishes",
                "dresses",
                "names",
                "bells",
                "stamps",
                "dishes",
                "grapes"
              ],
              "wordCount": 12,
              "sourcePage": 11
            },
            {
              "id": "lesson-12",
              "number": 12,
              "title": "Lesson 12",
              "skill": "Vowel Team ai and ay",
              "sourceSkill": "Skill-Vowel Team ai and ay",
              "words": [
                "wait",
                "paint",
                "train",
                "pail",
                "clay",
                "tray",
                "plain",
                "stain",
                "hay",
                "gray",
                "away"
              ],
              "wordCount": 11,
              "sourcePage": 12
            },
            {
              "id": "lesson-13",
              "number": 13,
              "title": "Lesson 13",
              "skill": "Vowel Teams ee, ea",
              "sourceSkill": "Skill-Vowel Teams ee, ea",
              "words": [
                "free",
                "teach",
                "teeth",
                "please",
                "beach",
                "wheel",
                "team",
                "speak",
                "sneeze",
                "sheep",
                "meaning",
                "weave"
              ],
              "wordCount": 12,
              "sourcePage": 13
            },
            {
              "id": "lesson-14",
              "number": 14,
              "title": "Lesson 14",
              "skill": "Long o (o, oa ow)",
              "sourceSkill": "Skill-Long o (o, oa ow)",
              "words": [
                "own",
                "most",
                "soap",
                "float",
                "both",
                "know",
                "loan",
                "goat",
                "flow",
                "loaf",
                "throw",
                "coach"
              ],
              "wordCount": 12,
              "sourcePage": 14
            },
            {
              "id": "lesson-15",
              "number": 15,
              "title": "Lesson 15",
              "skill": "Compound Words; Additional skill: Schwa",
              "sourceSkill": "Skill-Compound Words\nAdditional Skill: Schwa",
              "words": [
                "cannot",
                "pancake",
                "maybe",
                "baseball",
                "playground",
                "someone",
                "myself",
                "classroom",
                "sunshine",
                "outside",
                "upon",
                "nothing"
              ],
              "wordCount": 12,
              "sourcePage": 15
            }
          ],
          "wordCount": 59,
          "uniqueWordCount": 59
        },
        {
          "id": "unit-4",
          "number": 4,
          "title": "Unit 4",
          "lessons": [
            {
              "id": "lesson-16",
              "number": 16,
              "title": "Lesson 16",
              "skill": "Endings-ed and -ing",
              "sourceSkill": "Skill-Endings-ed and -ing",
              "words": [
                "running",
                "clapped",
                "stopped",
                "hopping",
                "batted",
                "selling",
                "pinned",
                "cutting",
                "sitting",
                "rubbed",
                "missed",
                "grabbed"
              ],
              "wordCount": 12,
              "sourcePage": 16
            },
            {
              "id": "lesson-17",
              "number": 17,
              "title": "Lesson 17",
              "skill": "Long i (i, igh, ie, y)",
              "sourceSkill": "Skill-Long i (i, igh, ie, y)",
              "words": [
                "night",
                "kind",
                "spy",
                "child",
                "light",
                "find",
                "right",
                "high",
                "wild",
                "July",
                "fry",
                "sigh"
              ],
              "wordCount": 12,
              "sourcePage": 17
            },
            {
              "id": "lesson-18",
              "number": 18,
              "title": "Lesson 18",
              "skill": "Long e sound for y",
              "sourceSkill": "Skill-Long e sound for y",
              "words": [
                "happy",
                "pretty",
                "baby",
                "very",
                "puppy",
                "funny",
                "carry",
                "lucky",
                "only",
                "sunny",
                "penny",
                "city",
                "cities",
                "puppies",
                "babies"
              ],
              "wordCount": 15,
              "sourcePage": 18
            },
            {
              "id": "lesson-19",
              "number": 19,
              "title": "Lesson 19",
              "skill": "Vowel -r:ar",
              "sourceSkill": "Skill-Vowel –r:ar",
              "words": [
                "car",
                "dark",
                "arm",
                "star",
                "park",
                "yard",
                "party",
                "hard",
                "farm",
                "start",
                "part",
                "spark"
              ],
              "wordCount": 12,
              "sourcePage": 19
            },
            {
              "id": "lesson-20",
              "number": 20,
              "title": "Lesson 20",
              "skill": "Vowel -r: or, ore",
              "sourceSkill": "Skill-Vowel –r: or, ore",
              "words": [
                "horn",
                "story",
                "fork",
                "store",
                "score",
                "corn",
                "morning",
                "shore",
                "short",
                "born",
                "torn",
                "forget"
              ],
              "wordCount": 12,
              "sourcePage": 20
            }
          ],
          "wordCount": 63,
          "uniqueWordCount": 63
        },
        {
          "id": "unit-5",
          "number": 5,
          "title": "Unit 5",
          "lessons": [
            {
              "id": "lesson-21",
              "number": 21,
              "title": "Lesson 21",
              "skill": "Vowel -r er, ir, ur",
              "sourceSkill": "Skill-Vowel –r\ner, ir, ur",
              "words": [
                "father",
                "over",
                "under",
                "herd",
                "water",
                "verb",
                "paper",
                "cracker",
                "offer",
                "cover",
                "germ",
                "master",
                "firm",
                "girl",
                "turn",
                "curl"
              ],
              "wordCount": 16,
              "sourcePage": 21
            },
            {
              "id": "lesson-22",
              "number": 22,
              "title": "Lesson 22",
              "skill": "Homophones; Additional skill: endings -er, -est",
              "sourceSkill": "Skill-Homophones\nAdditional Skill-\nendings\n-er, -est",
              "words": [
                "meet",
                "meat",
                "week",
                "weak",
                "mane",
                "main",
                "tail",
                "tale",
                "be",
                "bee",
                "too",
                "two",
                "there",
                "their",
                "here",
                "hear",
                "larger",
                "largest"
              ],
              "wordCount": 18,
              "sourcePage": 22
            },
            {
              "id": "lesson-23",
              "number": 23,
              "title": "Lesson 23",
              "skill": "Suffixes -y, -ly, -ful; Additional skill: Suffixes -ture, -tion",
              "sourceSkill": "Skill-Suffixes\n–y, -ly, -ful\nAdditional Skill-\nSufffixes\n–ture, -tion",
              "words": [
                "helpful",
                "sadly",
                "hopeful",
                "thankful",
                "slowly",
                "wishful",
                "kindly",
                "useful",
                "safely",
                "painful",
                "mouthful",
                "weakly",
                "nation",
                "adventure"
              ],
              "wordCount": 14,
              "sourcePage": 23
            },
            {
              "id": "lesson-24",
              "number": 24,
              "title": "Lesson 24",
              "skill": "Prefixes un-, re-, over-, pre-, mis-; Additional skill: Silent Consonants",
              "sourceSkill": "Skill-Prefixes un-, re-, over-\n,pre-, mis-\nAdditional Skill-\nSilent Consonants",
              "words": [
                "unhappy",
                "unkind",
                "overlook",
                "mislead",
                "repaint",
                "prepaid",
                "refill",
                "unlike",
                "reread",
                "replay",
                "knew",
                "write",
                "numb",
                "gnat"
              ],
              "wordCount": 14,
              "sourcePage": 24
            },
            {
              "id": "lesson-25",
              "number": 25,
              "title": "Lesson 25",
              "skill": "Words with au, aw, al, o, a",
              "sourceSkill": "Skill-Words with au,\naw, al, o, a",
              "words": [
                "tall",
                "saw",
                "draw",
                "call",
                "soft",
                "paw",
                "yawn",
                "log",
                "small",
                "water",
                "wash",
                "August",
                "fault"
              ],
              "wordCount": 13,
              "sourcePage": 25
            }
          ],
          "wordCount": 75,
          "uniqueWordCount": 74
        },
        {
          "id": "unit-6",
          "number": 6,
          "title": "Unit 6",
          "lessons": [
            {
              "id": "lesson-26",
              "number": 26,
              "title": "Lesson 26",
              "skill": "Vowel Teams oo, ew, ue, ou",
              "sourceSkill": "Skill-Vowel Teams\noo, ew, ue, ou",
              "words": [
                "root",
                "crew",
                "spoon",
                "bloom",
                "grew",
                "room",
                "you",
                "stew",
                "boost",
                "scoop",
                "flew"
              ],
              "wordCount": 11,
              "sourcePage": 26
            },
            {
              "id": "lesson-27",
              "number": 27,
              "title": "Lesson 27",
              "skill": "Vowel Team oo",
              "sourceSkill": "Skill-Vowel Team oo",
              "words": [
                "took",
                "books",
                "foot",
                "hoof",
                "cook",
                "nook",
                "hood",
                "wood",
                "stood",
                "shook",
                "crook",
                "cookbook"
              ],
              "wordCount": 12,
              "sourcePage": 27
            },
            {
              "id": "lesson-28",
              "number": 28,
              "title": "Lesson 28",
              "skill": "Vowel Diphthongs ou, ow",
              "sourceSkill": "Skill-Vowel Diphthongs\nou, ow",
              "words": [
                "cow",
                "house",
                "town",
                "shout",
                "down",
                "mouse",
                "found",
                "loud",
                "brown",
                "ground",
                "pound",
                "flower"
              ],
              "wordCount": 12,
              "sourcePage": 28
            },
            {
              "id": "lesson-29",
              "number": 29,
              "title": "Lesson 29",
              "skill": "Vowel Teams Long a (ai, ay), Long i (igh, -y); Additional skill: Vowel Diphthongs oy, oi",
              "sourceSkill": "Skill- Vowel Teams\nLong a (ai, ay),\nLong i (igh, -y)\nAdditional Skill –\nVowel Diphthongs oy, oi",
              "words": [
                "aim",
                "snail",
                "bay",
                "braid",
                "ray",
                "always",
                "gain",
                "sly",
                "chain",
                "shy",
                "bright",
                "fright",
                "coin",
                "foil",
                "boy",
                "ploy"
              ],
              "wordCount": 16,
              "sourcePage": 29
            },
            {
              "id": "lesson-30",
              "number": 30,
              "title": "Lesson 30",
              "skill": "Vowel Teams Long e (ea, ee) Long o (oa, ow); Additional skill: Final Syllable -le",
              "sourceSkill": "Skill-Vowel Teams\nLong e (ea, ee)\nLong o (oa, ow)\nAdditional Skill-\nFinal Syllable -le",
              "words": [
                "seated",
                "keeps",
                "speed",
                "seen",
                "means",
                "clean",
                "groan",
                "roast",
                "bowls",
                "crow",
                "owe",
                "grown",
                "table",
                "buckle",
                "ruffle"
              ],
              "wordCount": 15,
              "sourcePage": 30
            }
          ],
          "wordCount": 66,
          "uniqueWordCount": 66
        }
      ],
      "wordCount": 381,
      "lessonCount": 30
    },
    "3": {
      "label": "Grade 3",
      "sourceColumn": "right",
      "units": [
        {
          "id": "unit-1",
          "number": 1,
          "title": "Unit 1",
          "lessons": [
            {
              "id": "lesson-1",
              "number": 1,
              "title": "Lesson 1",
              "skill": "Short Vowels, Closed Syllables",
              "sourceSkill": "Short Vowels, Closed Syllables",
              "words": [
                "cosmic",
                "frantic",
                "mascot",
                "suspect",
                "talent",
                "disrupt"
              ],
              "wordCount": 6,
              "sourcePage": 1
            },
            {
              "id": "lesson-2",
              "number": 2,
              "title": "Lesson 2",
              "skill": "VCe Syllables",
              "sourceSkill": "VCe Syllables",
              "words": [
                "milestone",
                "campfire",
                "likewise",
                "invite",
                "manipulate"
              ],
              "wordCount": 5,
              "sourcePage": 2
            },
            {
              "id": "lesson-3",
              "number": 3,
              "title": "Lesson 3",
              "skill": "Long a and Long e",
              "sourceSkill": "Skill-Long a and Long e",
              "words": [
                "entertain",
                "payday",
                "sixteen",
                "teapot",
                "between",
                "mainstream"
              ],
              "wordCount": 6,
              "sourcePage": 3
            },
            {
              "id": "lesson-4",
              "number": 4,
              "title": "Lesson 4",
              "skill": "Long o: oa, ow",
              "sourceSkill": "Long o: oa, ow",
              "words": [
                "shadow",
                "window",
                "roadway",
                "raincoat",
                "showtime",
                "coaching"
              ],
              "wordCount": 6,
              "sourcePage": 4
            },
            {
              "id": "lesson-5",
              "number": 5,
              "title": "Lesson 5",
              "skill": "Long i: ie, igh",
              "sourceSkill": "Skill-Long i: ie, igh",
              "words": [
                "brighten",
                "tied",
                "untie",
                "cried",
                "moonlight",
                "sightseeing"
              ],
              "wordCount": 6,
              "sourcePage": 5
            }
          ],
          "wordCount": 29,
          "uniqueWordCount": 29
        },
        {
          "id": "unit-2",
          "number": 2,
          "title": "Unit 2",
          "lessons": [
            {
              "id": "lesson-6",
              "number": 6,
              "title": "Lesson 6",
              "skill": "Consonant -le syllables",
              "sourceSkill": "Skill-Consonant –le syllables",
              "words": [
                "noodle",
                "grapple",
                "gentle",
                "mixable",
                "guzzle",
                "baffle"
              ],
              "wordCount": 6,
              "sourcePage": 6
            },
            {
              "id": "lesson-7",
              "number": 7,
              "title": "Lesson 7",
              "skill": "Three-letter Consonant Clusters (scr, spr, str, thr)",
              "sourceSkill": "Skill-\nThree-letter Constant\nClusters (scr, spr, str, thr)",
              "words": [
                "scramble",
                "thrasher",
                "struggle",
                "throttle",
                "scribble",
                "screeching"
              ],
              "wordCount": 6,
              "sourcePage": 7
            },
            {
              "id": "lesson-8",
              "number": 8,
              "title": "Lesson 8",
              "skill": "Silent Letters (wr, kn, gn)",
              "sourceSkill": "Skill-\nSilent Letters (wr, kn, gn)",
              "words": [
                "wrath",
                "gnat",
                "gnome",
                "written",
                "knew",
                "knead"
              ],
              "wordCount": 6,
              "sourcePage": 8
            },
            {
              "id": "lesson-9",
              "number": 9,
              "title": "Lesson 9",
              "skill": "Vowel Diphthongs ow and ou",
              "sourceSkill": "Skill-Vowel Dipthongs ow and\nou",
              "words": [
                "vowel",
                "scoundrel",
                "wraparound",
                "outside",
                "powder",
                "powerful"
              ],
              "wordCount": 6,
              "sourcePage": 9
            },
            {
              "id": "lesson-10",
              "number": 10,
              "title": "Lesson 10",
              "skill": "Vowel Teams au, aw, a(l)",
              "sourceSkill": "Skill-Vowel Teams au, aw, a(l)",
              "words": [
                "launchpad",
                "automatic",
                "crawlspace",
                "drawstring",
                "outlaw",
                "August"
              ],
              "wordCount": 6,
              "sourcePage": 10
            }
          ],
          "wordCount": 30,
          "uniqueWordCount": 30
        },
        {
          "id": "unit-3",
          "number": 3,
          "title": "Unit 3",
          "lessons": [
            {
              "id": "lesson-11",
              "number": 11,
              "title": "Lesson 11",
              "skill": "Vowel Diphthongs oi and oy",
              "sourceSkill": "Skill-Vowel Dipthongs oi and\noy",
              "words": [
                "enjoy",
                "royal",
                "spoil",
                "poison",
                "voice",
                "toybox"
              ],
              "wordCount": 6,
              "sourcePage": 11
            },
            {
              "id": "lesson-12",
              "number": 12,
              "title": "Lesson 12",
              "skill": "Final Syllable al, el, le",
              "sourceSkill": "Skill-Final Syllable al, el, le",
              "words": [
                "apple",
                "wiggle",
                "global",
                "fuel",
                "rebel"
              ],
              "wordCount": 5,
              "sourcePage": 12
            },
            {
              "id": "lesson-13",
              "number": 13,
              "title": "Lesson 13",
              "skill": "Contractions",
              "sourceSkill": "Skill-Contractions",
              "words": [
                "we've",
                "they'll",
                "she'd",
                "can't",
                "you're",
                "must've"
              ],
              "wordCount": 6,
              "sourcePage": 13
            },
            {
              "id": "lesson-14",
              "number": 14,
              "title": "Lesson 14",
              "skill": "Vowel-r ar, or",
              "sourceSkill": "Skill-Vowel-r ar, or",
              "words": [
                "harmful",
                "darkness",
                "transform",
                "porthole",
                "scorching",
                "afford"
              ],
              "wordCount": 6,
              "sourcePage": 14
            },
            {
              "id": "lesson-15",
              "number": 15,
              "title": "Lesson 15",
              "skill": "Vowel-r er, ir, ur",
              "sourceSkill": "Skill- Vowel-r er, ir, ur",
              "words": [
                "Thursday",
                "return",
                "hurtful",
                "lantern",
                "turtle"
              ],
              "wordCount": 5,
              "sourcePage": 15
            }
          ],
          "wordCount": 28,
          "uniqueWordCount": 28
        },
        {
          "id": "unit-4",
          "number": 4,
          "title": "Unit 4",
          "lessons": [
            {
              "id": "lesson-16",
              "number": 16,
              "title": "Lesson 16",
              "skill": "Vowel + r: air, ear, are",
              "sourceSkill": "Skill-Vowel + r: air, ear, are",
              "words": [
                "airstream",
                "share",
                "hairpin",
                "silverware",
                "threadbare",
                "forbear"
              ],
              "wordCount": 6,
              "sourcePage": 16
            },
            {
              "id": "lesson-17",
              "number": 17,
              "title": "Lesson 17",
              "skill": "Soft c, Soft g",
              "sourceSkill": "Skill- Soft c, Soft g",
              "words": [
                "logic",
                "rigid",
                "spacecraft",
                "germination",
                "energy",
                "concert"
              ],
              "wordCount": 6,
              "sourcePage": 17
            },
            {
              "id": "lesson-18",
              "number": 18,
              "title": "Lesson 18",
              "skill": "Advanced Consonant Sounds",
              "sourceSkill": "Skill-Advance Consonant\nSounds",
              "words": [
                "bucket",
                "docking",
                "circus",
                "correct",
                "quilting",
                "quarters"
              ],
              "wordCount": 6,
              "sourcePage": 18
            },
            {
              "id": "lesson-19",
              "number": 19,
              "title": "Lesson 19",
              "skill": "Vowel Sounds in moon and cook",
              "sourceSkill": "Skill-Vowel Sounds in moon\nand cook",
              "words": [
                "wooden",
                "loosen",
                "chewing",
                "glue",
                "shoe",
                "hoodie"
              ],
              "wordCount": 6,
              "sourcePage": 19
            },
            {
              "id": "lesson-20",
              "number": 20,
              "title": "Lesson 20",
              "skill": "Compound Words",
              "sourceSkill": "Skill-Compound Words",
              "words": [
                "moonlight",
                "sunshade",
                "gearshift",
                "sweatshirt",
                "rainbow",
                "cupcake"
              ],
              "wordCount": 6,
              "sourcePage": 20
            }
          ],
          "wordCount": 30,
          "uniqueWordCount": 30
        },
        {
          "id": "unit-5",
          "number": 5,
          "title": "Unit 5",
          "lessons": [
            {
              "id": "lesson-21",
              "number": 21,
              "title": "Lesson 21",
              "skill": "ending ed and ing",
              "sourceSkill": "Skill-ending ed and ing",
              "words": [
                "amusing",
                "invited",
                "shrugged",
                "kissed",
                "dancing",
                "dipping"
              ],
              "wordCount": 6,
              "sourcePage": 21
            },
            {
              "id": "lesson-22",
              "number": 22,
              "title": "Lesson 22",
              "skill": "Changing Final y to i",
              "sourceSkill": "Skill-Changing Final y to i",
              "words": [
                "hurried",
                "carried",
                "dried",
                "stories",
                "puppies",
                "babies",
                "flies"
              ],
              "wordCount": 7,
              "sourcePage": 22
            },
            {
              "id": "lesson-23",
              "number": 23,
              "title": "Lesson 23",
              "skill": "Suffixes -ful, -ly, and -er",
              "sourceSkill": "Skill-Suffixes\n-ful, -ly, and -er",
              "words": [
                "painter",
                "peaceful",
                "loudly",
                "closely",
                "joyful",
                "shopkeeper"
              ],
              "wordCount": 6,
              "sourcePage": 23
            },
            {
              "id": "lesson-24",
              "number": 24,
              "title": "Lesson 24",
              "skill": "Prefixes un-, re-,",
              "sourceSkill": "Skill-Prefixes un-, re-,",
              "words": [
                "recall",
                "unload",
                "repaid",
                "unaware",
                "recycle",
                "uncover"
              ],
              "wordCount": 6,
              "sourcePage": 24
            },
            {
              "id": "lesson-25",
              "number": 25,
              "title": "Lesson 25",
              "skill": "Suffixes -less and -ness",
              "sourceSkill": "Skill-Suffixes –less\nand -ness",
              "words": [
                "toothless",
                "stillness",
                "paperless",
                "kindness",
                "countless",
                "thickness"
              ],
              "wordCount": 6,
              "sourcePage": 25
            }
          ],
          "wordCount": 31,
          "uniqueWordCount": 31
        },
        {
          "id": "unit-6",
          "number": 6,
          "title": "Unit 6",
          "lessons": [
            {
              "id": "lesson-26",
              "number": 26,
              "title": "Lesson 26",
              "skill": "Suffixes -tion, -sion, and -ure",
              "sourceSkill": "Skill-Suffixes –tion, -\nsion, and -ure",
              "words": [
                "impression",
                "picture",
                "lecture",
                "explosion",
                "scripture",
                "nation"
              ],
              "wordCount": 6,
              "sourcePage": 26
            },
            {
              "id": "lesson-27",
              "number": 27,
              "title": "Lesson 27",
              "skill": "Double Consonants",
              "sourceSkill": "Skill-Double\nConsonants",
              "words": [
                "bottle",
                "button",
                "pollen",
                "challenge",
                "dollar",
                "skillet"
              ],
              "wordCount": 6,
              "sourcePage": 27
            },
            {
              "id": "lesson-28",
              "number": 28,
              "title": "Lesson 28",
              "skill": "Ough and Augh",
              "sourceSkill": "Skill-Ough and Augh",
              "words": [
                "furlough",
                "naughty",
                "thoughtful",
                "laughed",
                "coughing",
                "enough"
              ],
              "wordCount": 6,
              "sourcePage": 28
            },
            {
              "id": "lesson-29",
              "number": 29,
              "title": "Lesson 29",
              "skill": "Endings -er or -le",
              "sourceSkill": "Skill- Endings –er or -le",
              "words": [
                "whistle",
                "later",
                "river",
                "trouble",
                "rubble",
                "gaggle"
              ],
              "wordCount": 6,
              "sourcePage": 29
            },
            {
              "id": "lesson-30",
              "number": 30,
              "title": "Lesson 30",
              "skill": "Schwa Sound",
              "sourceSkill": "Skill-Schwa Sound",
              "words": [
                "dozen",
                "open",
                "attack",
                "soda",
                "final",
                "giant"
              ],
              "wordCount": 6,
              "sourcePage": 30
            }
          ],
          "wordCount": 30,
          "uniqueWordCount": 30
        }
      ],
      "wordCount": 178,
      "lessonCount": 30
    }
  }
};
