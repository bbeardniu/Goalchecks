/* Whole-number generators keep operation choices separate from numerical bounds. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.BeardArithmeticCore = api;
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';
  const operations = Object.freeze({add:{name:'Addition',symbol:'+'},subtract:{name:'Subtraction',symbol:'−'},multiply:{name:'Multiplication',symbol:'×'},divide:{name:'Division',symbol:'÷'}});
  function integer(min, max, random) {
    if (!Number.isSafeInteger(min) || !Number.isSafeInteger(max) || max < min) throw new Error('Invalid arithmetic range.');
    const value = Math.max(0, Math.min(1 - Number.EPSILON, Number(random()) || 0));
    return min + Math.floor(value * (max - min + 1));
  }
  function regrouping(a, b, op) {
    while (a || b) {
      if (op === 'add' ? a % 10 + b % 10 >= 10 : a % 10 < b % 10) return true;
      a = Math.floor(a / 10); b = Math.floor(b / 10);
    }
    return false;
  }
  function withoutRegrouping(max, op, random) {
    const a = integer(0, max, random); let rest = a, place = 1, b = 0;
    do { const digit = rest % 10; b += place * integer(0, op === 'add' ? 9 - digit : digit, random); rest = Math.floor(rest / 10); place *= 10; } while (rest);
    if (op === 'add' && a + b > max) b = 0;
    return [a, b];
  }
  function twoDigit(op, random) {
    if (op === 'add') {
      const tensA = integer(1, 8, random), onesA = integer(0, 9, random);
      return [tensA * 10 + onesA, integer(1, 9 - tensA, random) * 10 + integer(0, 9 - onesA, random)];
    }
    const tensA = integer(1, 9, random), onesA = integer(0, 9, random);
    return [tensA * 10 + onesA, integer(1, tensA, random) * 10 + integer(0, onesA, random)];
  }
  function generate(settings = {}, random = Math.random, forcedOperation) {
    const selected = Array.isArray(settings.operations) ? settings.operations : ['add', 'subtract'];
    if (!selected.length || selected.some(op => !Object.hasOwn(operations, op))) throw new Error('Select at least one supported operation.');
    const op = forcedOperation || selected[integer(0, selected.length - 1, random)];
    if (!selected.includes(op)) throw new Error('The operation is not selected.');
    const mode = settings.mode || 'whole', max = Number(settings.max ?? 100), factMax = Number(settings.factMax ?? 9), family = Number(settings.family || 0);
    if (!Number.isSafeInteger(max) || max < 2 || max > 1000000 || !Number.isInteger(factMax) || factMax < 2 || factMax > 12) throw new Error('Choose a supported number range.');
    if (family && (!Number.isInteger(family) || family < 2 || family > factMax)) throw new Error('Choose a fact family in the selected range.');
    if (mode === 'no-regroup' && !['add', 'subtract'].includes(op)) throw new Error('The no-regrouping check uses addition or subtraction.');
    let a, b;
    if (mode === 'no-regroup') [a, b] = twoDigit(op, random);
    else if (mode === 'facts') {
      if (op === 'add') { a = family || integer(0, factMax, random); b = integer(0, factMax, random); }
      else if (op === 'subtract') { a = family ? integer(family, factMax, random) : integer(0, factMax, random); b = family || integer(0, a, random); }
      else if (op === 'multiply') { a = family || integer(0, factMax, random); b = integer(0, factMax, random); }
      else { b = family || integer(1, factMax, random); a = b * integer(0, factMax, random); }
    } else if (op === 'multiply') {
      a = integer(1, Math.min(factMax, max), random); b = integer(0, Math.min(factMax, Math.floor(max / a)), random);
    } else if (op === 'divide') {
      b = integer(1, Math.min(factMax, max), random); a = b * integer(0, Math.min(factMax, Math.floor(max / b)), random);
    } else {
      const minimum = settings.large ? Math.floor(max / 10) : 0;
      for (let trial = 0; trial < 128; trial++) {
        a = integer(minimum, max, random); b = integer(0, op === 'add' ? max - a : a, random);
        if (settings.regrouping !== 'with' && settings.regrouping !== 'without' || regrouping(a,b,op) === (settings.regrouping === 'with')) break;
        if (trial === 127) {
          if (settings.regrouping === 'with') { if (max < 10) throw new Error('Regrouping needs a range of at least 10.'); const base = settings.large ? minimum : 0; [a,b] = op === 'add' ? [base+9,1] : [base+10,1]; }
          else [a,b] = withoutRegrouping(max,op,random);
        }
      }
    }
    const expected = op === 'add' ? a+b : op === 'subtract' ? a-b : op === 'multiply' ? a*b : a/b;
    if (![a,b,expected].every(Number.isSafeInteger) || Math.min(a,b,expected) < 0 || op === 'divide' && !b) throw new Error('Invalid arithmetic problem.');
    if (mode === 'whole' && Math.max(a,b,expected) > max) throw new Error('The arithmetic problem exceeds its range.');
    const symbol = operations[op].symbol, problem = a.toLocaleString('en-US')+' '+symbol+' '+b.toLocaleString('en-US')+' = ?';
    return {a,b,operation:op,operator:symbol,expected,problem};
  }
  function parse(raw) {
    const value = String(raw ?? '').trim();
    if (!/^[+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.0+)?$/.test(value)) return {valid:false,value:null};
    const number = Number(value.replaceAll(',',''));
    return Number.isSafeInteger(number) ? {valid:true,value:number} : {valid:false,value:null};
  }
  return Object.freeze({operations,generate,parse,regrouping});
});
