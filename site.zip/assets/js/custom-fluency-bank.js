/* Generated from passages/*.txt. Edit the text files, not this catalog. */
window.BeardCustomFluencyBank = Object.freeze({
  "version": 1,
  "passages": []
});
