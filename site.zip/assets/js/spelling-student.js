(() => {
  'use strict';

  const mounts = new WeakMap();

  function mount({host, teacherRoot, getTest, getStudent, setResponse, onClose, getLabel, standalone = false, onChooseList, onRepeat, onPrompt, onSubmit, onFinish, onHear}) {
    if (!host || (!standalone && !teacherRoot) || typeof getTest !== 'function' || typeof getStudent !== 'function' || typeof setResponse !== 'function') {
      throw new Error('The student spelling view needs a test and student.');
    }
    if (mounts.has(host)) return mounts.get(host);

    const doc = host.ownerDocument || document;
    const win = doc.defaultView || window;
    const positions = new Map();
    const synth = win.speechSynthesis;
    const canSpeak = Boolean(synth && typeof synth.speak === 'function' && typeof win.SpeechSynthesisUtterance === 'function');
    let opened = false, suspended = false, activeKey = null, mode = 'type', utteranceToken = 0, voices = [], activeUtterance = null, finishNotified = false;

    function node(tag, className, text) {
      const element = doc.createElement(tag);
      if (className) element.className = className;
      if (text !== undefined) element.textContent = text;
      return element;
    }
    function button(className, text) {
      const element = node('button', className, text);
      element.type = 'button';
      return element;
    }

    const panel = node('section', 'spelling-student-panel');
    if (standalone) panel.classList.add('is-standalone');
    panel.setAttribute('aria-label', 'Student spelling activity');
    const top = node('div', 'spelling-student-top');
    const brand = node('p', 'spelling-student-brand', "Beard's Classroom");
    const back = button('spelling-student-back', standalone ? 'Choose another week' : 'Back to teacher');
    if (standalone) back.id = 'spellingStudentChooseWeek';
    top.append(brand, back);
    const heading = node('h1', 'spelling-student-heading', 'Listen. Think. Spell.');
    const learner = node('p', 'spelling-student-learner');
    const directions = node('p', 'spelling-student-directions', 'Listen to the word and its sentence. You can hear it again whenever you need to.');
    const modeLabel = node('label', 'spelling-student-mode-label', 'How will you answer?');
    modeLabel.htmlFor = 'spellingStudentMode';
    const modeSelect = node('select', 'spelling-student-mode');
    modeSelect.id = 'spellingStudentMode';
    const typeOption = node('option', '', 'Type my answers');
    typeOption.value = 'type';
    const paperOption = node('option', '', 'Write on paper');
    paperOption.value = 'paper';
    modeSelect.append(typeOption, paperOption);
    modeSelect.value = mode;
    const modeRow = node('div', 'spelling-student-mode-row');
    modeRow.append(modeLabel, modeSelect);

    const work = node('div', 'spelling-student-work');
    const progress = node('p', 'spelling-student-progress');
    progress.setAttribute('aria-live', 'polite');
    const hear = button('spelling-student-hear', 'Hear word');
    hear.id = 'spellingStudentHear';
    hear.setAttribute('aria-label', 'Hear the word, a sentence, and the word again');
    const answerArea = node('div', 'spelling-student-answer-area');
    const answerLabel = node('label', 'spelling-student-answer-label', 'Your spelling');
    answerLabel.htmlFor = 'spellingStudentAnswer';
    const answer = node('input', 'spelling-student-answer');
    answer.id = 'spellingStudentAnswer';
    answer.type = 'text';
    answer.maxLength = 200;
    answer.autocomplete = 'off';
    answer.spellcheck = false;
    answer.setAttribute('autocorrect', 'off');
    answer.setAttribute('autocapitalize', 'none');
    answer.setAttribute('aria-describedby', 'spellingStudentAnswerTip');
    const tip = node('p', 'spelling-student-tip', standalone && typeof onSubmit === 'function'
      ? 'Type your answer, then choose Next word. A blank submitted answer counts as incorrect.'
      : 'Type your answer, then choose Next word. Leave it blank if you need to skip.');
    tip.id = 'spellingStudentAnswerTip';
    answerArea.append(answerLabel, answer, tip);
    const paperTip = node('p', 'spelling-student-paper-tip', 'Write the numbered answer on your paper, then choose Next word.');
    const actions = node('div', 'spelling-student-actions');
    const previous = button('spelling-student-previous', 'Previous word');
    previous.id = 'spellingStudentPrevious';
    const next = button('spelling-student-next', 'Next word');
    next.id = 'spellingStudentNext';
    actions.append(previous, next);
    const status = node('p', 'spelling-student-status');
    status.id = 'spellingStudentStatus';
    status.setAttribute('role', 'status');
    status.setAttribute('aria-live', 'polite');
    work.append(progress, hear, answerArea, paperTip, actions, status);
    const finished = node('section', 'spelling-student-finished');
    const finishedHeading = node('h2', '', 'All words finished');
    finishedHeading.tabIndex = -1;
    const finishedText = node('p');
    const finishedBack = button('spelling-student-finish-back', standalone ? 'Practice again' : 'Back to teacher');
    if (standalone) finishedBack.id = 'spellingStudentRepeat';
    finished.append(finishedHeading, finishedText, finishedBack);
    const finishedChoose = standalone ? button('spelling-student-finish-choose', 'Choose another week') : null;
    if (finishedChoose) { finishedChoose.id = 'spellingStudentFinishedChooseWeek'; finished.append(finishedChoose); }
    panel.append(top, heading, learner, directions, modeRow, work, finished);
    host.replaceChildren(panel);
    host.classList.add('spelling-student-host');
    host.hidden = true;

    function normalize(value) {
      const core = win.BeardSpellingCore;
      return core && typeof core.normalizeWord === 'function'
        ? core.normalizeWord(value)
        : String(value).normalize('NFC').replace(/[\u2018\u2019\u02bc\uff07]/g, "'").trim().toLocaleLowerCase('en-US');
    }
    function identity(test, student) { return test.id + '|' + student.id; }
    function current() {
      const test = getTest(), student = getStudent();
      if (!test || !student || !Array.isArray(test.words) || !test.words.length || !Array.isArray(student.responses)) return null;
      return {test, student, key:identity(test, student)};
    }
    function indexFor(state) { return Math.min(state.test.words.length, Math.max(0, positions.get(state.key) || 0)); }
    function message(text, error = false) {
      status.textContent = text;
      status.className = 'spelling-student-status' + (error ? ' is-error' : '');
    }
    function stopSpeech() {
      utteranceToken++;
      activeUtterance = null;
      if (synth && typeof synth.cancel === 'function') {
        try { synth.cancel(); } catch {}
      }
      hear.removeAttribute('aria-busy');
    }
    function refreshVoices() {
      try { voices = canSpeak && typeof synth.getVoices === 'function' ? synth.getVoices() || [] : []; }
      catch { voices = []; }
    }
    function englishVoice() {
      return voices.find(voice => /^en[-_]US$/i.test(voice.lang) && voice.default)
        || voices.find(voice => /^en[-_]US$/i.test(voice.lang))
        || voices.find(voice => /^en(?:[-_]|$)/i.test(voice.lang));
    }
    function render() {
      const state = current();
      if (!state) return false;
      activeKey = state.key;
      const index = indexFor(state), done = index >= state.test.words.length;
      const label = typeof getLabel === 'function' ? getLabel() : '';
      learner.textContent = standalone ? label : [state.student.name, label].filter(Boolean).join(' · ');
      progress.textContent = done ? state.test.words.length + ' words finished' : 'Word ' + (index + 1) + ' of ' + state.test.words.length;
      modeSelect.value = mode;
      modeRow.hidden = done;
      work.hidden = done;
      finished.hidden = !done;
      answerArea.hidden = mode !== 'type' || done;
      paperTip.hidden = mode !== 'paper' || done;
      hear.disabled = done || suspended;
      previous.disabled = index === 0 || suspended;
      next.disabled = done || suspended;
      next.textContent = index === state.test.words.length - 1 ? 'Finish list' : 'Next word';
      answer.disabled = done || mode !== 'type' || suspended;
      modeSelect.disabled = suspended;
      answer.value = done ? '' : state.student.responses[index]?.spelling || '';
      finishedText.textContent = standalone
        ? (mode === 'paper' ? 'You have finished this list. Keep your paper if you want to check it with an adult.' : 'You have finished practicing this list.')
        : (mode === 'paper' ? 'Keep your paper for your teacher.' : 'Your answers have been kept for your teacher.');
      message(canSpeak ? 'Choose Hear word when you are ready.' : 'Read-aloud is unavailable on this device. Ask an adult to read the word to you.', !canSpeak);
      if (!done && !suspended && typeof onPrompt === 'function') onPrompt(index);
      return true;
    }
    function liveState() {
      const state = current();
      if (!opened || suspended || !state) return null;
      if (state.key !== activeKey) {
        stopSpeech();
        render();
        message(standalone ? 'The practice list changed. You are at the current word.' : 'The selected test or student changed. You are at that student’s current word.');
        return null;
      }
      return state;
    }
    function saveTyped(state) {
      const index = indexFor(state);
      if (mode !== 'type' || index >= state.test.words.length) return true;
      // Keep intentional clears, while unchanged answers preserve any teacher scoring override.
      const stored = state.student.responses[index]?.spelling || '';
      if (answer.value === stored) return true;
      try { setResponse(index, {spelling:answer.value}); return true; }
      catch (error) { message(error?.message || 'This answer could not be saved. Please ask your teacher.', true); return false; }
    }
    function hearWord() {
      const state = liveState();
      if (!state) return;
      const index = indexFor(state);
      if (index >= state.test.words.length) return;
      stopSpeech();
      if (typeof onHear === 'function') onHear(index);
      if (!canSpeak) { message('Read-aloud is unavailable on this device. Ask an adult to read the word to you.', true); return; }
      const word = state.test.words[index];
      const context = win.BeardSpellingContexts?.[normalize(word)];
      if (typeof context !== 'string' || !context.trim()) {
        message('The example sentence could not load. Please ask an adult to read this item.', true);
        return;
      }
      const token = utteranceToken;
      let utterance;
      try { utterance = new win.SpeechSynthesisUtterance(word + '. ' + context.trim() + ' ' + word + '.'); }
      catch { message('The voice could not play. Ask an adult to read this item.', true); return; }
      activeUtterance = utterance;
      refreshVoices();
      const voice = englishVoice();
      utterance.lang = voice?.lang || 'en-US';
      if (voice) utterance.voice = voice;
      utterance.rate = 0.85;
      utterance.pitch = 1;
      utterance.volume = 1;
      const stillCurrent = () => opened && token === utteranceToken && activeKey === state.key && indexFor(state) === index;
      utterance.onstart = () => { if (stillCurrent()) message('Listening…'); };
      utterance.onend = () => { if (stillCurrent()) { activeUtterance = null; hear.removeAttribute('aria-busy'); message('Ready. You can hear it again or go to the next word.'); } };
      utterance.onerror = () => { if (stillCurrent()) { activeUtterance = null; hear.removeAttribute('aria-busy'); message('The voice could not play. Try Hear word again, or ask an adult to read it.', true); } };
      message('Listening…');
      hear.setAttribute('aria-busy', 'true');
      // The button remains enabled so a stopped or delayed device voice can be retried.
      try {
        if (typeof synth.resume === 'function') synth.resume();
        synth.speak(utterance);
      } catch {
        activeUtterance = null;
        hear.removeAttribute('aria-busy');
        message('The voice could not play. Try Hear word again, or ask an adult to read it.', true);
      }
    }
    function move(direction) {
      const state = liveState();
      if (!state) return;
      const index = indexFor(state);
      if (index >= state.test.words.length) return;
      const changedTyped = mode === 'type' && answer.value !== (state.student.responses[index]?.spelling || '');
      if (!saveTyped(state)) return;
      if ((direction > 0 || changedTyped) && typeof onSubmit === 'function') {
        try {
          if (onSubmit(index, {spelling:mode === 'type' ? answer.value : '', mode, reason:direction > 0 ? 'next' : 'previous'}) === false) return;
        } catch (error) {
          message(error?.message || 'This answer could not be submitted. Please ask an adult.', true);
          return;
        }
      }
      stopSpeech();
      const nextIndex = Math.min(state.test.words.length, Math.max(0, index + direction));
      positions.set(state.key, nextIndex);
      render();
      if (nextIndex >= state.test.words.length) {
        finishedHeading.focus?.();
        if (!finishNotified && typeof onFinish === 'function') { finishNotified = true; onFinish(); }
      }
      else if (mode === 'type') answer.focus();
      else hear.focus();
    }
    function leave({save = true, notify = true} = {}) {
      if (!opened) return true;
      const state = current();
      if (save && state?.key === activeKey && !saveTyped(state)) return false;
      stopSpeech();
      opened = false;
      host.hidden = true;
      if (!standalone) teacherRoot.hidden = false;
      doc.body.classList.remove('spelling-in-student-view');
      if (notify && typeof onClose === 'function') onClose();
      return true;
    }
    function open() {
      const state = current();
      if (!state) return false;
      stopSpeech();
      opened = true;
      suspended = false;
      if (!standalone) teacherRoot.hidden = true;
      host.hidden = false;
      doc.body.classList.add('spelling-in-student-view');
      render();
      if (indexFor(state) >= state.test.words.length) finishedBack.focus();
      else hear.focus();
      return true;
    }

    hear.addEventListener('click', hearWord);
    next.addEventListener('click', event => { if (!(event.detail > 1)) move(1); });
    previous.addEventListener('click', event => { if (!(event.detail > 1)) move(-1); });
    function chooseList() {
      if (!standalone) return leave();
      const state = liveState();
      if (!state || !saveTyped(state)) return false;
      stopSpeech();
      if (typeof onChooseList === 'function') onChooseList();
      return true;
    }
    back.addEventListener('click', chooseList);
    finishedBack.addEventListener('click', () => {
      if (!standalone) { leave(); return; }
      stopSpeech();
      if (typeof onRepeat === 'function') onRepeat();
      else { const state = current(); if (state) { positions.set(state.key, 0); render(); hear.focus(); } }
    });
    if (finishedChoose) finishedChoose.addEventListener('click', chooseList);
    modeSelect.addEventListener('change', () => {
      const state = liveState();
      if (!state || !saveTyped(state)) { modeSelect.value = mode; return; }
      stopSpeech();
      mode = modeSelect.value === 'paper' ? 'paper' : 'type';
      render();
    });
    answer.addEventListener('keydown', event => {
      if (event.key === 'Enter' && !event.repeat && !event.isComposing) { event.preventDefault(); move(1); }
    });
    panel.addEventListener('keydown', event => {
      if (opened && event.key === 'Escape' && !event.isComposing) { event.preventDefault(); if (standalone) chooseList(); else leave(); }
    });
    if (canSpeak && typeof synth.addEventListener === 'function') synth.addEventListener('voiceschanged', refreshVoices);
    win.addEventListener('pagehide', stopSpeech);
    refreshVoices();

    const api = Object.freeze({
      open,
      close:() => leave(),
      getCurrent() {
        const state = current();
        if (!state) return null;
        const index = indexFor(state), done = index >= state.test.words.length;
        return {index, spelling:done ? '' : mode === 'type' ? answer.value : '', mode, done};
      },
      flush() {
        const state = current();
        if (!state || state.key !== activeKey) return null;
        if (!saveTyped(state)) return false;
        return api.getCurrent();
      },
      suspend() {
        suspended = true;
        stopSpeech();
        hear.disabled = answer.disabled = next.disabled = previous.disabled = modeSelect.disabled = true;
      },
      reset() { leave({save:false, notify:false}); positions.clear(); activeKey = null; suspended = false; finishNotified = false; },
      get isOpen() { return opened; }
    });
    mounts.set(host, api);
    return api;
  }

  window.BeardSpellingStudent = Object.freeze({mount});
})();
