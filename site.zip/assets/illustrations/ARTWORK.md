# Beard's Classroom illustrations

Revision: v01.0018

## Colored-pencil update

The math illustrations now use warm paper colors, layered pencil contours and deterministic fine hatching. This covers analog clocks, U.S. coins, base-ten blocks, counting dots, dice arrangements, ten-frames and number bonds. Their original mathematical values, unit counts, relative coin sizes and exact clock-hand positions are preserved. Drawing textures do not consume the question generator's random sequence.

The homepage has eight original colored-pencil subject pictures and a colored-pencil version of the existing Mr. Beard avatar. The avatar keeps its recognizable appearance and transparent background.

Six of the fourteen story illustration sheets have been redrawn in colored pencil: `storybook-01.webp`, `storybook-02.webp`, `storybook-05.webp`, `storybook-07.webp`, `storybook-11.webp` and `storybook-13.webp`. Each contains sixteen separate pictures: 96 converted scenes in total. The standalone harbor and transparent sea-creature/reward sheet have also been redrawn.

The remaining sheets, **03, 04, 06, 08, 09, 10, 12 and 14**, retain their original painted illustrations. The image-generation service reached the account's usage limit during this update. These assets remain usable and their assessment mappings are unchanged. This revision does not claim the entire raster collection is finished. Exact completed/pending filenames are recorded in `artwork-revision.json`.

## Art direction and prompt recipe

Professional children's picture-book artwork made with traditional dry colored pencils: visible directional strokes, gentle crosshatching, softly layered pigment, colored contours, natural friendly expressions and warm ivory paper. Avoid watercolor washes, gouache, glossy digital gradients, 3D, flat clip art, branding, watermarks and new readable text.

Raster drawings were generated or restyled with the built-in image-generation tool. They are actual replacement images, not a CSS artistic filter. Generated files were only resized and encoded for delivery. Prompt recipes and per-file status are in `colored-pencil-prompts.json`; the original scene descriptions remain in `manifest.json`.

## Files and mappings

- `storybook-01.webp` through `storybook-14.webp`: 224 story vignettes in fixed four-by-four sheets, shared by the 300 writing prompts.
- `storybook-tools.webp`: sixteen transparent sea-creature and reward illustrations, retained for compatibility with retired activities.
- `ship-harbor.webp`: one complete square scene, used by a Grade 3 writing prompt.
- `classroom-icons.webp`: eight subject pictures in a four-column, two-row homepage sprite.
- `manifest.json` and `manifest.js`: the existing prompt-to-image mappings; sentence clues and tile indices are preserved.
- `storybook-art.js`: accessible local artwork rendering with revisioned image URLs so browsers fetch the updated pictures.

Each story tile must remain in its original row and column, with clear gutters and its original subjects and actions. Do not reorder tiles, add labels or substitute an unrelated scene. An atlas may use a different square resolution without changing its equal-cell crop coordinates. The harbor is a standalone image and must retain its one-column mapping.

No assessment questions, scoring rules, timers, saved student records or answer mappings were changed for this visual update.
