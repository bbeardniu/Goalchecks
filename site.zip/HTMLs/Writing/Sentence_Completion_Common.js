(() => {
  const config = window.SentenceCompletionConfig;
  if (!config || !Array.isArray(config.questions) || !config.questions.length) return;
  document.body.dataset.beardRunAware = 'true';
  document.body.dataset.beardNativeScoring = 'true';
  document.body.dataset.beardLevel = config.grade + ' sentence completion';

  const ANSWER_READ_DELAY_MS = 3000;
  const $ = selector => document.querySelector(selector);
  const app = $('#sentence-completion-app');
  if (!app) return;

  function addStyles() {
    if ($('#sentence-completion-style')) return;
    const style = document.createElement('style');
    style.id = 'sentence-completion-style';
    style.textContent = `
      :root{--sc-navy:#1e4767;--sc-blue:#2878a9;--sc-cream:#fffdf7;--sc-ink:#26394b;--sc-line:#cfe2ed;--sc-green:#237f4e;--sc-red:#bd4141;--sc-gold:#e7b840}
      *{box-sizing:border-box}
      body[data-beard-compact-report="sentence-completion"]{margin:0;min-height:100vh;background:linear-gradient(135deg,#e8f6ff,#fff9e9);color:var(--sc-ink);font-family:"Avenir Next",Avenir,"Segoe UI",sans-serif}
      .sentence-completion-shell{width:min(960px,calc(100% - 2rem));margin:0 auto 2rem;padding:clamp(1rem,3vw,2rem);border:3px solid #fff;border-radius:24px;background:rgba(255,253,247,.97);box-shadow:0 12px 32px rgba(30,71,103,.16)}
      .sentence-completion-heading{display:grid;grid-template-columns:auto 1fr;gap:1rem;align-items:center;padding-bottom:1rem;border-bottom:2px dashed #c8dfe9}
      .sentence-completion-badge{display:grid;place-items:center;width:62px;height:62px;border:2px solid #b9ddeb;border-radius:18px;background:#eaf7fb;color:var(--sc-navy);font-size:2rem;font-weight:900;transform:rotate(-3deg)}
      .sentence-completion-eyebrow{margin:0 0 .2rem;color:#537187;font-size:.78rem;font-weight:900;letter-spacing:.11em;text-transform:uppercase}
      .sentence-completion-heading h1{margin:0;color:var(--sc-navy);font-family:"Comic Sans MS","Chalkboard SE",cursive;font-size:clamp(1.7rem,5vw,2.45rem);line-height:1.06}
      .sentence-completion-directions{margin:1rem 0 0;color:#456276;font-size:1.03rem;line-height:1.5}
      .sentence-completion-art-controls{display:flex;justify-content:flex-end;margin-top:1rem}
      .sentence-completion-art-toggle{min-height:46px;max-width:100%;padding:.65rem .9rem;border:2px solid #a8c9cb;border-radius:10px;background:#f2f9f5;color:#315f59;font:800 .95rem/1.2 "Avenir Next",Avenir,"Segoe UI",sans-serif;cursor:pointer;touch-action:manipulation}
      .sentence-completion-art-toggle:focus-visible{outline:3px solid #e2b74a;outline-offset:3px}
      .sentence-completion-card{display:grid;grid-template-columns:minmax(220px,.9fr) minmax(0,1.45fr);gap:clamp(.8rem,2vw,1.25rem);align-items:center;margin:1rem 0;padding:clamp(.85rem,2.4vw,1.25rem);border:2px solid #dedac9;border-radius:20px;background:#fffdf7}
      .sentence-completion-card.is-text-only{grid-template-columns:minmax(0,1fr)}
      .sentence-completion-art{width:100%;max-width:300px;aspect-ratio:1;border:1px solid #e5dfcc;border-radius:16px;overflow:hidden;background:#fffdf7;box-shadow:0 3px 9px rgba(103,83,54,.07)}
      .sentence-completion-art[hidden]{display:none!important}
      .sentence-completion-prompt-label{margin:0 0 .5rem;color:#587489;font-size:.78rem;font-weight:900;letter-spacing:.1em;text-transform:uppercase}
      #sentence{margin:0;color:var(--sc-navy);font-size:clamp(1.35rem,3.5vw,2rem);font-weight:900;line-height:1.34;overflow-wrap:anywhere}
      .sentence-completion-progress{display:flex;justify-content:space-between;gap:.75rem;align-items:center;flex-wrap:wrap;margin:1rem 0 .65rem}
      #progress{margin:0;color:var(--sc-navy);font-weight:900}
      .sentence-completion-tip{margin:0;padding:.4rem .65rem;border-radius:999px;background:#edf7fb;color:#547084;font-size:.88rem;font-weight:800}
      .sentence-completion-options{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.7rem}
      .sentence-completion-option{min-height:62px;padding:.7rem .85rem!important;border:2px solid #b7d7e7!important;border-radius:13px!important;background:#fff!important;color:var(--sc-navy)!important;font:900 clamp(1rem,3.5vw,1.18rem)/1.2 "Avenir Next",Avenir,"Segoe UI",sans-serif!important;box-shadow:0 3px 0 rgba(30,71,103,.12)!important;cursor:pointer;touch-action:manipulation}
      .sentence-completion-option:nth-child(4n+1){border-color:#9fcde1!important;background:#f2fbff!important}
      .sentence-completion-option:nth-child(4n+2){border-color:#f0cf8e!important;background:#fff9e6!important}
      .sentence-completion-option:nth-child(4n+3){border-color:#a8d6b6!important;background:#f1fbf4!important}
      .sentence-completion-option:nth-child(4n){border-color:#e7b4bd!important;background:#fff3f5!important}
      .sentence-completion-option:hover,.sentence-completion-option:focus-visible{filter:brightness(.97);transform:translateY(-2px);outline:3px solid #9bd7f4!important;outline-offset:2px}
      .sentence-completion-option.is-selected{outline:3px solid #e4bb58;outline-offset:2px}
      .sentence-completion-option.is-correct{border-color:#5daf78!important;background:#eaf8ef!important;color:#17653a!important}
      .sentence-completion-option.is-incorrect{border-color:#d87572!important;background:#fff0ee!important;color:#a73333!important}
      .sentence-completion-option:disabled{cursor:default;opacity:.78}
      .sentence-completion-controls{display:flex;justify-content:center;gap:.65rem;flex-wrap:wrap;margin-top:1rem}
      .sentence-completion-controls button{min-height:46px;margin:0!important;padding:.68rem 1rem!important;border:0!important;border-radius:10px!important;background:var(--sc-blue)!important;color:#fff!important;font:850 1rem/1.1 "Avenir Next",Avenir,"Segoe UI",sans-serif!important;box-shadow:0 3px 0 rgba(20,73,111,.18)!important;cursor:pointer;touch-action:manipulation}
      .sentence-completion-navigation{display:flex;justify-content:space-between;gap:.7rem;margin:.9rem 0 .35rem}
      .sentence-completion-navigation button{min-height:46px;padding:.65rem 1rem;border:2px solid #b7d7e7;border-radius:10px;background:#edf7fb;color:var(--sc-navy);font:800 .95rem/1.2 "Avenir Next",Avenir,"Segoe UI",sans-serif;cursor:pointer}
      .sentence-completion-navigation button:disabled{opacity:.45;cursor:default}
      .sentence-completion-navigation-status{margin:.35rem 0;color:#547084;font-size:.85rem;line-height:1.4}
      .sentence-completion-report-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:.5rem;margin-top:.75rem}
      .sentence-completion-result-card{min-width:0;padding:.65rem;border:1px solid var(--sc-line);border-radius:10px;background:#fffdf7;overflow-wrap:anywhere;break-inside:avoid}
      .sentence-completion-result-card .question{display:block;color:#47667e;font-size:.77rem;line-height:1.35}
      .sentence-completion-result-card .student-choice{display:block;margin:.35rem 0;font-size:1rem;font-weight:850}
      .sentence-completion-result-card .result-good{color:var(--sc-green)}
      .sentence-completion-result-card .result-bad{color:var(--sc-red)}
      .sentence-completion-result-card .response-seconds{display:block;color:#547084;font-size:.8rem}
      .sentence-completion-result-card .expected-choice{display:block;margin-top:.2rem;color:#547084;font-size:.7rem}
      .sentence-completion-report-note{font-size:.8rem;line-height:1.4;color:#547084}
      @media(max-width:620px){.sentence-completion-report-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
      .sentence-completion-controls #stopBtn{background:#c85b56!important}
      .sentence-completion-controls #resetBtn{background:#8b6a42!important}
      #feedback{min-height:2.6rem;margin:1rem 0 0;padding:.7rem .85rem;border-radius:10px;background:rgba(255,255,255,.82);font-size:1.08rem;font-weight:900;text-align:center}
      #feedback.feedback-correct{color:var(--sc-green)}
      #feedback.feedback-incorrect{color:var(--sc-red)}
      .sentence-completion-stats{display:flex;justify-content:center;gap:.5rem;flex-wrap:wrap;margin-top:1rem}
      .sentence-completion-stats span{padding:.4rem .6rem;border-radius:999px;background:#edf7fb;color:#47667e;font-size:.86rem;font-weight:850}
      #summary{display:none;margin-top:1.25rem;padding:1rem;border:2px solid var(--sc-line);border-radius:16px;background:#fff}
      #summary h2{margin:0;color:var(--sc-navy);font-family:"Comic Sans MS","Chalkboard SE",cursive}
      .sentence-completion-direct-list{margin:.85rem 0 0;padding-left:1.25rem;line-height:1.5}
      .sentence-completion-direct-list .correct{color:var(--sc-green);font-weight:850}
      .sentence-completion-direct-list .incorrect{color:var(--sc-red);font-weight:850}
      @media(max-width:620px){body[data-beard-compact-report="sentence-completion"]{padding:.7rem}.sentence-completion-shell{width:100%;padding:1rem;border-radius:18px}.sentence-completion-heading,.sentence-completion-card{grid-template-columns:1fr;text-align:center}.sentence-completion-badge{margin:auto}.sentence-completion-art{max-width:220px;margin:auto;width:100%}.sentence-completion-options{grid-template-columns:1fr}.sentence-completion-option{min-height:58px}}
      @media print{.sentence-completion-workspace,.sentence-completion-controls,.sentence-completion-stats{display:none!important}}
    `;
    document.head.append(style);
  }

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>'"]/g, character => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[character]));
  }

  function shuffle(items) {
    const copy = [...items];
    for (let index = copy.length - 1; index > 0; index--) {
      const random = window.BeardRun && typeof window.BeardRun.random === 'function' ? window.BeardRun.random : Math.random;
      const swapIndex = Math.floor(random() * (index + 1));
      [copy[index], copy[swapIndex]] = [copy[swapIndex], copy[index]];
    }
    return copy;
  }

  addStyles();
  app.innerHTML = `<main class="sentence-completion-shell" aria-labelledby="activity-title"><header class="sentence-completion-heading"><div class="sentence-completion-badge" aria-hidden="true">✎</div><div><p class="sentence-completion-eyebrow">${escapeHtml(config.grade)} writing goal check</p><h1 id="activity-title">${escapeHtml(config.title)}</h1></div></header><section class="sentence-completion-workspace" id="workArea" aria-label="Sentence completion activity"><div class="sentence-completion-art-controls"><button id="sentenceCompletionIllustrations" class="sentence-completion-art-toggle" type="button" aria-pressed="true" aria-controls="scene">Hide illustrations</button></div><p id="sentenceCompletionDirections" class="sentence-completion-directions">Read the sentence and picture clue. Choose the one word or phrase that makes the sentence correct.</p><section class="sentence-completion-card" aria-label="Sentence question"><div id="scene" class="sentence-completion-art"></div><div><p class="sentence-completion-prompt-label">Choose the best answer</p><p id="sentence" data-beard-prompt aria-live="polite"></p></div></section><div class="sentence-completion-progress"><p id="progress"></p><p class="sentence-completion-tip">Four choices • one best answer</p></div><div id="options" class="sentence-completion-options" aria-label="Answer choices"></div><nav class="sentence-completion-navigation" aria-label="Sentence navigation"><button id="sentenceCompletionPrevious" type="button" disabled>Previous sentence</button><button id="sentenceCompletionNext" type="button" disabled>Next sentence</button></nav><p id="sentenceCompletionNavigationStatus" class="sentence-completion-navigation-status" role="status" aria-live="polite"></p><div class="sentence-completion-controls" aria-label="Assessment controls"><button type="button" id="stopBtn">Stop assessment</button><button type="button" id="resetBtn">Reset check</button></div></section><input id="answer" type="hidden" value=""><p id="feedback" aria-live="polite"></p><div class="sentence-completion-stats" aria-live="polite"><span id="score">Score: 0%</span><span id="attempts">Attempts: 0</span><span id="timer">Time: 0s</span></div><section id="summary" data-beard-hide-auto-history aria-live="polite"></section></main>`;

  const sentence = $('#sentence');
  const scene = $('#scene');
  const illustrationToggle = $('#sentenceCompletionIllustrations');
  const directions = $('#sentenceCompletionDirections');
  const options = $('#options');
  const progress = $('#progress');
  const answer = $('#answer');
  const feedback = $('#feedback');
  const summary = $('#summary');
  const score = $('#score');
  const attempts = $('#attempts');
  const timer = $('#timer');
  const workArea = $('#workArea');
  const stopButton = $('#stopBtn');
  const resetButton = $('#resetBtn');
  const previousButton = $('#sentenceCompletionPrevious');
  const nextButton = $('#sentenceCompletionNext');
  const navigationStatus = $('#sentenceCompletionNavigationStatus');
  let questions = [], questionIndex = 0, history = [], currentQuestion = null, locked = false, ended = false, startedAt = 0, stoppedSeconds = 0, timerId = null, nextQuestionId = null, releaseChoiceId = null, settings = {};
  let activeSince = null, renderToken = 0, advanceToken = 0, guardedUntil = 0;
  let illustrationsEnabled = true, illustrationStates = new Set(), questionIllustrationStates = new Set();
  function illustrationsUsed(states = illustrationStates) { return states.size > 1 ? 'On and off' : (states.size ? states.has(true) : illustrationsEnabled) ? 'On' : 'Off'; }
  function applyIllustrationVisibility(record = false) {
    scene.hidden = !illustrationsEnabled;
    scene.setAttribute('aria-hidden', String(!illustrationsEnabled));
    scene.parentElement.classList.toggle('is-text-only', !illustrationsEnabled);
    illustrationToggle.textContent = illustrationsEnabled ? 'Hide illustrations' : 'Show illustrations';
    illustrationToggle.setAttribute('aria-pressed', String(illustrationsEnabled));
    directions.textContent = illustrationsEnabled ? 'Read the sentence and picture clue. Choose the one word or phrase that makes the sentence correct.' : 'Read the sentence. Choose the one word or phrase that makes the sentence correct.';
    if (record) { illustrationStates.add(illustrationsEnabled); questionIllustrationStates.add(illustrationsEnabled); }
  }
  function elapsedSeconds() { return ended ? stoppedSeconds : Math.max(0, (Date.now() - startedAt) / 1000); }
  function currentResponse() { return history.find(item => item.questionId === questionIndex); }
  function reportState() {
    const correct = history.filter(item => item.correct).length;
    return {assessment:document.title,skill:'Sentence completion',level:document.body.dataset.beardLevel,mode:settings.mode||'practice',formId:settings.formId||'',date:new Date(startedAt).toISOString(),scoreType:'Accuracy',score:history.length?correct/history.length:null,attempts:history.length,correct,errors:history.length-correct,percentage:history.length?Math.round(correct/history.length*100):null,pending:false,seconds:elapsedSeconds(),illustrationsUsed:illustrationsUsed(),illustrationsEnabled,supports:'Illustrations: '+illustrationsUsed(),notes:'Response seconds include time on the original choice and later answer revisions; feedback delays and time on other questions are excluded.',responses:history.map(item=>({...item,prompt:item.question,outcome:item.correct}))};
  }
  function notify() { document.dispatchEvent(new CustomEvent('beard:report-updated')); }
  function updateStats() {
    const total = history.length, correct = history.filter(item => item.correct).length;
    score.textContent = `Score: ${total ? Math.round(correct / total * 100) : 0}%`;
    attempts.textContent = `Attempts: ${total}`;
  }
  function updateNavigation() {
    previousButton.disabled = ended || questionIndex === 0;
    nextButton.disabled = ended || !currentResponse();
    nextButton.textContent = questionIndex === questions.length - 1 ? 'Finish assessment' : 'Next sentence';
  }
  function updateTimer() { timer.textContent = `Time: ${Math.max(0, Math.floor(elapsedSeconds()))}s`; }
  function startTimer() { clearInterval(timerId); startedAt = Date.now(); updateTimer(); timerId = setInterval(updateTimer, 1000); }
  function normalizeSentence(text) { return text.replace(/\s+([.,!?;:])/g, '$1'); }
  function cleanSentence(question) { return normalizeSentence(question.s.replace(/_{3,}/, '_____')); }
  function cancelAdvance() { clearTimeout(nextQuestionId); nextQuestionId = null; advanceToken += 1; }
  function collectDwell() {
    if (currentQuestion && activeSince !== null) currentQuestion.activeMilliseconds += Math.max(0, Date.now() - activeSince);
    activeSince = null;
  }
  function showSavedChoice(row) {
    const practice = (settings.mode || 'practice') === 'practice';
    answer.value = row ? row.answer : '';
    options.querySelectorAll('button').forEach(button => {
      const selected = Boolean(row && button.textContent === row.answer);
      button.setAttribute('aria-pressed', String(selected));
      button.classList.toggle('is-selected', selected);
      button.classList.toggle('is-correct', Boolean(practice && row && button.textContent === currentQuestion.a));
      button.classList.toggle('is-incorrect', Boolean(practice && selected && !row.correct));
    });
    feedback.textContent = row ? (row.correct ? 'Correct!' : `Incorrect. The best answer is “${currentQuestion.a}.”`) : '';
    feedback.className = row ? (row.correct ? 'feedback-correct' : 'feedback-incorrect') : '';
    feedback.hidden = !practice;
  }
  function showQuestion({fromAuto = false} = {}) {
    cancelAdvance(); clearTimeout(releaseChoiceId); collectDwell();
    if (questionIndex >= questions.length) { stopAssessment(true); return; }
    currentQuestion = questions[questionIndex]; locked = false; activeSince = Date.now();
    guardedUntil = Date.now() + ANSWER_READ_DELAY_MS;
    const token = ++renderToken;
    questionIllustrationStates = currentQuestion.illustrationStates;
    applyIllustrationVisibility(true);
    sentence.textContent = cleanSentence(currentQuestion); sentence.dataset.beardPrompt = normalizeSentence(currentQuestion.s);
    window.BeardStorybook.render(scene, currentQuestion.artKey);
    applyIllustrationVisibility();
    progress.textContent = `Sentence ${questionIndex + 1} of ${questions.length}`;
    const row = currentResponse();
    const readyMessage = row ? 'Your previous choice is selected. Choose another answer to change it.' : 'Choose one answer before moving to the next sentence.';
    navigationStatus.textContent = 'Read the sentence. Answers unlock after 3 seconds.';
    options.replaceChildren(...currentQuestion.choiceOrder.map(choice => {
      const button = document.createElement('button'); button.type = 'button'; button.className = 'sentence-completion-option'; button.textContent = choice;
      button.disabled = true;
      button.addEventListener('click', () => chooseAnswer(choice, token));
      return button;
    }));
    showSavedChoice(row); updateNavigation();
    function releaseChoices() {
      releaseChoiceId = null;
      if (ended || token !== renderToken || locked) return;
      const remaining = guardedUntil - Date.now();
      if (remaining > 0) { releaseChoiceId = setTimeout(releaseChoices, remaining); return; }
      options.querySelectorAll('button').forEach(button => { button.disabled = false; });
      navigationStatus.textContent = readyMessage;
    }
    releaseChoiceId = setTimeout(releaseChoices, ANSWER_READ_DELAY_MS);
  }
  function moveQuestion(direction, fromAuto = false) {
    if (ended || !currentQuestion || (direction > 0 && !currentResponse())) return;
    if (direction < 0 && questionIndex === 0) return;
    collectDwell(); cancelAdvance();
    questionIndex += direction;
    showQuestion({fromAuto});
  }
  function chooseAnswer(choice, token) {
    // A TTS-enabled second tap may have event.detail=2; it is still the first native answer.
    if (locked || ended || !currentQuestion || token !== renderToken || Date.now() < guardedUntil) return;
    const previous = currentResponse();
    if (previous && previous.answer === choice) return;
    cancelAdvance(); collectDwell(); locked = true; answer.value = choice;
    const correct = choice === currentQuestion.a;
    const nowElapsed = Math.max(0, Math.round((Date.now() - startedAt) / 100) / 10);
    const row = {questionId:questionIndex,questionNumber:questionIndex+1,sourceQuestionNumber:currentQuestion.sourceIndex+1,question:normalizeSentence(currentQuestion.s),answer:choice,correct,correctAnswer:currentQuestion.a,seconds:Math.max(0,Math.round(currentQuestion.activeMilliseconds/100)/10),elapsedSeconds:previous ? previous.elapsedSeconds : nowElapsed,lastAnsweredElapsedSeconds:nowElapsed,revisionCount:previous ? previous.revisionCount+1 : 0,illustrationsUsed:illustrationsUsed(questionIllustrationStates),illustrationsEnabled};
    if (previous) history[history.indexOf(previous)] = row;
    else { history.push(row); history.sort((a,b) => a.questionId - b.questionId); }
    options.querySelectorAll('button').forEach(button => { button.disabled = true; });
    showSavedChoice(row); updateStats(); updateNavigation();
    navigationStatus.textContent = previous ? 'Answer updated. The number of attempts has not changed.' : 'Answer saved. You can use Previous sentence to review a response.';
    notify();
    const scheduledToken = advanceToken, answeredIndex = questionIndex;
    nextQuestionId = setTimeout(() => {
      if (ended || scheduledToken !== advanceToken || questionIndex !== answeredIndex) return;
      moveQuestion(1, true);
    }, 950);
  }
  function directSummary() {
    const state = reportState();
    const date = new Date(startedAt).toLocaleDateString(undefined, {month:'long',day:'numeric',year:'numeric'});
    const rows = history.map((item,index) => `<article class="sentence-completion-result-card" data-beard-response-index="${index}" tabindex="0" role="button" title="Right-click to switch Correct / Incorrect" aria-label="Sentence ${item.questionNumber}: ${escapeHtml(item.answer)}, ${item.correct?'Correct':'Incorrect'}, ${item.seconds.toFixed(1)} seconds"><span class="question">${item.questionNumber}. ${escapeHtml(item.question.replace(/_{3,}/, '_____'))}</span><strong class="student-choice ${item.correct?'result-good':'result-bad'}">${escapeHtml(item.answer)}</strong><span class="response-seconds">${item.seconds.toFixed(1)} s${item.revisionCount?' · revised':''}</span>${item.correct?'':`<span class="expected-choice">Expected: ${escapeHtml(item.correctAnswer)}</span>`}</article>`).join('');
    summary.innerHTML = `<h2>Assessment Results</h2><p><strong>Date:</strong> ${date} · <strong>Score:</strong> ${state.percentage===null?'—':state.percentage+'%'}<br><strong>Total time:</strong> ${stoppedSeconds.toFixed(1)} s · <strong>Attempts:</strong> ${state.attempts} · <strong>Errors:</strong> ${state.errors}<br><strong>Illustrations:</strong> ${illustrationsUsed()}</p><div class="sentence-completion-report-grid">${rows || '<p>No responses recorded.</p>'}</div><p class="sentence-completion-report-note">${escapeHtml(state.notes)}</p><div class="sentence-completion-controls"><button type="button" id="playAgain">Start a New Check</button></div>`;
    summary.style.display = 'block'; $('#playAgain').addEventListener('click', () => resetAssessment());
  }
  function stopAssessment(autoFinished = false) {
    if (ended) return;
    collectDwell(); stoppedSeconds = Math.max(0, (Date.now() - startedAt) / 1000); ended = true; locked = true;
    cancelAdvance(); clearTimeout(releaseChoiceId); clearInterval(timerId); renderToken += 1;
    feedback.textContent = ''; feedback.className = ''; workArea.hidden = true; illustrationToggle.disabled = true;
    updateNavigation(); updateTimer(); directSummary(); notify();
  }
  function correctResponse(index, outcome) {
    if (!ended || !Number.isInteger(index) || index < 0 || index >= history.length || typeof outcome !== 'boolean') return false;
    history[index].correct = outcome; history[index].teacherCorrected = true;
    updateStats(); directSummary(); notify(); return true;
  }
  function resetAssessment(runSettings) {
    settings = runSettings && runSettings.mode ? {...runSettings} : {...(window.BeardRunSettings || settings)};
    cancelAdvance(); clearTimeout(releaseChoiceId); clearInterval(timerId); renderToken += 1; activeSince = null;
    questions = shuffle(config.questions.map((question, index) => ({...question,sourceIndex:index,artKey:`${config.artGroup}:${index + 1}`,choiceOrder:shuffle(question.o),activeMilliseconds:0,illustrationStates:new Set()})));
    questionIndex = 0; history = []; currentQuestion = null; locked = false; ended = false; stoppedSeconds = 0; guardedUntil = 0;
    illustrationStates = new Set([illustrationsEnabled]); illustrationToggle.disabled = false;
    summary.replaceChildren(); summary.style.display = 'none'; workArea.hidden = false;
    updateStats(); startTimer(); showQuestion(); notify();
  }
  stopButton.addEventListener('click', () => stopAssessment());
  illustrationToggle.addEventListener('click', () => { if (ended) return; illustrationsEnabled = !illustrationsEnabled; applyIllustrationVisibility(true); });
  resetButton.addEventListener('click', () => resetAssessment());
  previousButton.addEventListener('click', event => { if (!(event.detail > 1)) moveQuestion(-1); });
  nextButton.addEventListener('click', event => { if (!(event.detail > 1)) moveQuestion(1); });
  document.addEventListener('beard:run-start', event => resetAssessment(event.detail && event.detail.settings));
  window.BeardAssessmentState = {getReport:reportState,reset:()=>resetAssessment(),stop:stopAssessment,correctResponse};
  window.BeardAssessment = {getState:reportState,start:resetAssessment,reset:resetAssessment,stop:stopAssessment,correctResponse};
  resetAssessment();
})();
